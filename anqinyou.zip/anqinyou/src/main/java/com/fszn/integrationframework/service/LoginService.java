package com.fszn.integrationframework.service;

import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface LoginService {

    void token(String[] str);

    boolean hasStepChild(String s);
}
