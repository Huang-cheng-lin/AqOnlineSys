package com.fszn.integrationframework.domain;

import java.util.Date;

public class UserRoll {
    private String wid;

    private Integer asn;

    private String realname;

    private String sex;

    private Date dt;

    private String id;

    private String phone;

    private String duohai;

    private String isyh;

    private Integer sbtflag;

    public String getWid() {
        return wid;
    }

    public void setWid(String wid) {
        this.wid = wid == null ? null : wid.trim();
    }

    public Integer getAsn() {
        return asn;
    }

    public void setAsn(Integer asn) {
        this.asn = asn;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname == null ? null : realname.trim();
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex == null ? null : sex.trim();
    }

    public Date getDt() {
        return dt;
    }

    public void setDt(Date dt) {
        this.dt = dt;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public String getDuohai() {
        return duohai;
    }

    public void setDuohai(String duohai) {
        this.duohai = duohai == null ? null : duohai.trim();
    }

    public String getIsyh() {
        return isyh;
    }

    public void setIsyh(String isyh) {
        this.isyh = isyh == null ? null : isyh.trim();
    }

    public Integer getSbtflag() {
        return sbtflag;
    }

    public void setSbtflag(Integer sbtflag) {
        this.sbtflag = sbtflag;
    }
}