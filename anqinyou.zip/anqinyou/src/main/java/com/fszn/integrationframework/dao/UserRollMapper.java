package com.fszn.integrationframework.dao;

import com.fszn.integrationframework.domain.UserRoll;
import com.fszn.integrationframework.domain.UserRollExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UserRollMapper {
    long countByExample(UserRollExample example);

    int deleteByExample(UserRollExample example);

    int deleteByPrimaryKey(String wid);

    int insert(UserRoll record);

    int insertSelective(UserRoll record);

    List<UserRoll> selectByExample(UserRollExample example);

    UserRoll selectByPrimaryKey(String wid);

    int updateByExampleSelective(@Param("record") UserRoll record, @Param("example") UserRollExample example);

    int updateByExample(@Param("record") UserRoll record, @Param("example") UserRollExample example);

    int updateByPrimaryKeySelective(UserRoll record);

    int updateByPrimaryKey(UserRoll record);
}