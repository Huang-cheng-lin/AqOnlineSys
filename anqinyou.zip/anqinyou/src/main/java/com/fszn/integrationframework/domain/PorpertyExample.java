package com.fszn.integrationframework.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class PorpertyExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public PorpertyExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andPsnIsNull() {
            addCriterion("psn is null");
            return (Criteria) this;
        }

        public Criteria andPsnIsNotNull() {
            addCriterion("psn is not null");
            return (Criteria) this;
        }

        public Criteria andPsnEqualTo(Long value) {
            addCriterion("psn =", value, "psn");
            return (Criteria) this;
        }

        public Criteria andPsnNotEqualTo(Long value) {
            addCriterion("psn <>", value, "psn");
            return (Criteria) this;
        }

        public Criteria andPsnGreaterThan(Long value) {
            addCriterion("psn >", value, "psn");
            return (Criteria) this;
        }

        public Criteria andPsnGreaterThanOrEqualTo(Long value) {
            addCriterion("psn >=", value, "psn");
            return (Criteria) this;
        }

        public Criteria andPsnLessThan(Long value) {
            addCriterion("psn <", value, "psn");
            return (Criteria) this;
        }

        public Criteria andPsnLessThanOrEqualTo(Long value) {
            addCriterion("psn <=", value, "psn");
            return (Criteria) this;
        }

        public Criteria andPsnIn(List<Long> values) {
            addCriterion("psn in", values, "psn");
            return (Criteria) this;
        }

        public Criteria andPsnNotIn(List<Long> values) {
            addCriterion("psn not in", values, "psn");
            return (Criteria) this;
        }

        public Criteria andPsnBetween(Long value1, Long value2) {
            addCriterion("psn between", value1, value2, "psn");
            return (Criteria) this;
        }

        public Criteria andPsnNotBetween(Long value1, Long value2) {
            addCriterion("psn not between", value1, value2, "psn");
            return (Criteria) this;
        }

        public Criteria andEsnIsNull() {
            addCriterion("esn is null");
            return (Criteria) this;
        }

        public Criteria andEsnIsNotNull() {
            addCriterion("esn is not null");
            return (Criteria) this;
        }

        public Criteria andEsnEqualTo(Long value) {
            addCriterion("esn =", value, "esn");
            return (Criteria) this;
        }

        public Criteria andEsnNotEqualTo(Long value) {
            addCriterion("esn <>", value, "esn");
            return (Criteria) this;
        }

        public Criteria andEsnGreaterThan(Long value) {
            addCriterion("esn >", value, "esn");
            return (Criteria) this;
        }

        public Criteria andEsnGreaterThanOrEqualTo(Long value) {
            addCriterion("esn >=", value, "esn");
            return (Criteria) this;
        }

        public Criteria andEsnLessThan(Long value) {
            addCriterion("esn <", value, "esn");
            return (Criteria) this;
        }

        public Criteria andEsnLessThanOrEqualTo(Long value) {
            addCriterion("esn <=", value, "esn");
            return (Criteria) this;
        }

        public Criteria andEsnIn(List<Long> values) {
            addCriterion("esn in", values, "esn");
            return (Criteria) this;
        }

        public Criteria andEsnNotIn(List<Long> values) {
            addCriterion("esn not in", values, "esn");
            return (Criteria) this;
        }

        public Criteria andEsnBetween(Long value1, Long value2) {
            addCriterion("esn between", value1, value2, "esn");
            return (Criteria) this;
        }

        public Criteria andEsnNotBetween(Long value1, Long value2) {
            addCriterion("esn not between", value1, value2, "esn");
            return (Criteria) this;
        }

        public Criteria andPnoIsNull() {
            addCriterion("pno is null");
            return (Criteria) this;
        }

        public Criteria andPnoIsNotNull() {
            addCriterion("pno is not null");
            return (Criteria) this;
        }

        public Criteria andPnoEqualTo(String value) {
            addCriterion("pno =", value, "pno");
            return (Criteria) this;
        }

        public Criteria andPnoNotEqualTo(String value) {
            addCriterion("pno <>", value, "pno");
            return (Criteria) this;
        }

        public Criteria andPnoGreaterThan(String value) {
            addCriterion("pno >", value, "pno");
            return (Criteria) this;
        }

        public Criteria andPnoGreaterThanOrEqualTo(String value) {
            addCriterion("pno >=", value, "pno");
            return (Criteria) this;
        }

        public Criteria andPnoLessThan(String value) {
            addCriterion("pno <", value, "pno");
            return (Criteria) this;
        }

        public Criteria andPnoLessThanOrEqualTo(String value) {
            addCriterion("pno <=", value, "pno");
            return (Criteria) this;
        }

        public Criteria andPnoLike(String value) {
            addCriterion("pno like", value, "pno");
            return (Criteria) this;
        }

        public Criteria andPnoNotLike(String value) {
            addCriterion("pno not like", value, "pno");
            return (Criteria) this;
        }

        public Criteria andPnoIn(List<String> values) {
            addCriterion("pno in", values, "pno");
            return (Criteria) this;
        }

        public Criteria andPnoNotIn(List<String> values) {
            addCriterion("pno not in", values, "pno");
            return (Criteria) this;
        }

        public Criteria andPnoBetween(String value1, String value2) {
            addCriterion("pno between", value1, value2, "pno");
            return (Criteria) this;
        }

        public Criteria andPnoNotBetween(String value1, String value2) {
            addCriterion("pno not between", value1, value2, "pno");
            return (Criteria) this;
        }

        public Criteria andOwnersIsNull() {
            addCriterion("owners is null");
            return (Criteria) this;
        }

        public Criteria andOwnersIsNotNull() {
            addCriterion("owners is not null");
            return (Criteria) this;
        }

        public Criteria andOwnersEqualTo(String value) {
            addCriterion("owners =", value, "owners");
            return (Criteria) this;
        }

        public Criteria andOwnersNotEqualTo(String value) {
            addCriterion("owners <>", value, "owners");
            return (Criteria) this;
        }

        public Criteria andOwnersGreaterThan(String value) {
            addCriterion("owners >", value, "owners");
            return (Criteria) this;
        }

        public Criteria andOwnersGreaterThanOrEqualTo(String value) {
            addCriterion("owners >=", value, "owners");
            return (Criteria) this;
        }

        public Criteria andOwnersLessThan(String value) {
            addCriterion("owners <", value, "owners");
            return (Criteria) this;
        }

        public Criteria andOwnersLessThanOrEqualTo(String value) {
            addCriterion("owners <=", value, "owners");
            return (Criteria) this;
        }

        public Criteria andOwnersLike(String value) {
            addCriterion("owners like", value, "owners");
            return (Criteria) this;
        }

        public Criteria andOwnersNotLike(String value) {
            addCriterion("owners not like", value, "owners");
            return (Criteria) this;
        }

        public Criteria andOwnersIn(List<String> values) {
            addCriterion("owners in", values, "owners");
            return (Criteria) this;
        }

        public Criteria andOwnersNotIn(List<String> values) {
            addCriterion("owners not in", values, "owners");
            return (Criteria) this;
        }

        public Criteria andOwnersBetween(String value1, String value2) {
            addCriterion("owners between", value1, value2, "owners");
            return (Criteria) this;
        }

        public Criteria andOwnersNotBetween(String value1, String value2) {
            addCriterion("owners not between", value1, value2, "owners");
            return (Criteria) this;
        }

        public Criteria andPaddressIsNull() {
            addCriterion("paddress is null");
            return (Criteria) this;
        }

        public Criteria andPaddressIsNotNull() {
            addCriterion("paddress is not null");
            return (Criteria) this;
        }

        public Criteria andPaddressEqualTo(String value) {
            addCriterion("paddress =", value, "paddress");
            return (Criteria) this;
        }

        public Criteria andPaddressNotEqualTo(String value) {
            addCriterion("paddress <>", value, "paddress");
            return (Criteria) this;
        }

        public Criteria andPaddressGreaterThan(String value) {
            addCriterion("paddress >", value, "paddress");
            return (Criteria) this;
        }

        public Criteria andPaddressGreaterThanOrEqualTo(String value) {
            addCriterion("paddress >=", value, "paddress");
            return (Criteria) this;
        }

        public Criteria andPaddressLessThan(String value) {
            addCriterion("paddress <", value, "paddress");
            return (Criteria) this;
        }

        public Criteria andPaddressLessThanOrEqualTo(String value) {
            addCriterion("paddress <=", value, "paddress");
            return (Criteria) this;
        }

        public Criteria andPaddressLike(String value) {
            addCriterion("paddress like", value, "paddress");
            return (Criteria) this;
        }

        public Criteria andPaddressNotLike(String value) {
            addCriterion("paddress not like", value, "paddress");
            return (Criteria) this;
        }

        public Criteria andPaddressIn(List<String> values) {
            addCriterion("paddress in", values, "paddress");
            return (Criteria) this;
        }

        public Criteria andPaddressNotIn(List<String> values) {
            addCriterion("paddress not in", values, "paddress");
            return (Criteria) this;
        }

        public Criteria andPaddressBetween(String value1, String value2) {
            addCriterion("paddress between", value1, value2, "paddress");
            return (Criteria) this;
        }

        public Criteria andPaddressNotBetween(String value1, String value2) {
            addCriterion("paddress not between", value1, value2, "paddress");
            return (Criteria) this;
        }

        public Criteria andPdtIsNull() {
            addCriterion("pdt is null");
            return (Criteria) this;
        }

        public Criteria andPdtIsNotNull() {
            addCriterion("pdt is not null");
            return (Criteria) this;
        }

        public Criteria andPdtEqualTo(Date value) {
            addCriterionForJDBCDate("pdt =", value, "pdt");
            return (Criteria) this;
        }

        public Criteria andPdtNotEqualTo(Date value) {
            addCriterionForJDBCDate("pdt <>", value, "pdt");
            return (Criteria) this;
        }

        public Criteria andPdtGreaterThan(Date value) {
            addCriterionForJDBCDate("pdt >", value, "pdt");
            return (Criteria) this;
        }

        public Criteria andPdtGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("pdt >=", value, "pdt");
            return (Criteria) this;
        }

        public Criteria andPdtLessThan(Date value) {
            addCriterionForJDBCDate("pdt <", value, "pdt");
            return (Criteria) this;
        }

        public Criteria andPdtLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("pdt <=", value, "pdt");
            return (Criteria) this;
        }

        public Criteria andPdtIn(List<Date> values) {
            addCriterionForJDBCDate("pdt in", values, "pdt");
            return (Criteria) this;
        }

        public Criteria andPdtNotIn(List<Date> values) {
            addCriterionForJDBCDate("pdt not in", values, "pdt");
            return (Criteria) this;
        }

        public Criteria andPdtBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("pdt between", value1, value2, "pdt");
            return (Criteria) this;
        }

        public Criteria andPdtNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("pdt not between", value1, value2, "pdt");
            return (Criteria) this;
        }

        public Criteria andIcdIsNull() {
            addCriterion("icd is null");
            return (Criteria) this;
        }

        public Criteria andIcdIsNotNull() {
            addCriterion("icd is not null");
            return (Criteria) this;
        }

        public Criteria andIcdEqualTo(String value) {
            addCriterion("icd =", value, "icd");
            return (Criteria) this;
        }

        public Criteria andIcdNotEqualTo(String value) {
            addCriterion("icd <>", value, "icd");
            return (Criteria) this;
        }

        public Criteria andIcdGreaterThan(String value) {
            addCriterion("icd >", value, "icd");
            return (Criteria) this;
        }

        public Criteria andIcdGreaterThanOrEqualTo(String value) {
            addCriterion("icd >=", value, "icd");
            return (Criteria) this;
        }

        public Criteria andIcdLessThan(String value) {
            addCriterion("icd <", value, "icd");
            return (Criteria) this;
        }

        public Criteria andIcdLessThanOrEqualTo(String value) {
            addCriterion("icd <=", value, "icd");
            return (Criteria) this;
        }

        public Criteria andIcdLike(String value) {
            addCriterion("icd like", value, "icd");
            return (Criteria) this;
        }

        public Criteria andIcdNotLike(String value) {
            addCriterion("icd not like", value, "icd");
            return (Criteria) this;
        }

        public Criteria andIcdIn(List<String> values) {
            addCriterion("icd in", values, "icd");
            return (Criteria) this;
        }

        public Criteria andIcdNotIn(List<String> values) {
            addCriterion("icd not in", values, "icd");
            return (Criteria) this;
        }

        public Criteria andIcdBetween(String value1, String value2) {
            addCriterion("icd between", value1, value2, "icd");
            return (Criteria) this;
        }

        public Criteria andIcdNotBetween(String value1, String value2) {
            addCriterion("icd not between", value1, value2, "icd");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}