package com.fszn.integrationframework.utils;

import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 时间转换类
 */
@Component
public class StringToTimestamp {
    /**
     * 把固定时间格式成Timestamp格式
     * @param csdt Timestamp
     * @return
     */
    public static String  StringToTimestamp(String csdt){
        if(csdt!=null){
            Timestamp csdtTime = new Timestamp(System.currentTimeMillis());
            csdtTime = Timestamp.valueOf(csdt);
            String csdtString="'"+csdtTime+"'";
            return csdtString;

        }else{
            return null;
        }

    }

    /**
     * 把当前时间格式化为Timestamp
     * @return
     */
    public static String CurrentDateToTimestamp(){
        Date date = new Date();
        String time = "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        time = "'"+sdf.format(date)+"'";
        return time;
    }
    public static Timestamp formatTime(String inputtimestamp) throws Exception{

        //部署充电桩时 部署时间的格式
        //2016-11-11T11:11  注意这里多了一个T
        //去掉多余字符
        String install_time1 = inputtimestamp.replace("T"," ")+" 00:00:00";

//      处理完后的格式："2016-11-11 11:11:00";

        //格式转换
        return Timestamp.valueOf(install_time1);
    }
}
