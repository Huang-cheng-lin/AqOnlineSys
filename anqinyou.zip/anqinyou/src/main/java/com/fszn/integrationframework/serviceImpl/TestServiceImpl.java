package com.fszn.integrationframework.serviceImpl;

import com.fszn.integrationframework.dao.*;
import com.fszn.integrationframework.domain.Enroll;
import com.fszn.integrationframework.domain.EnrollExample;
import com.fszn.integrationframework.service.TestService;
import com.fszn.integrationframework.utils.Result;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class TestServiceImpl implements TestService {
    @Autowired
    private AreaMapper areaMapper;
    @Autowired
    private EnrollTypeMapper enrollTypeMapper;
    @Autowired
    private Result result;
    @Autowired
    private EnrollMapper enrollMapper;
    @Autowired
    private UserRollMapper userRollMapper;
    @Autowired
    private StudentMapper studentMapper;
    @Autowired
    private SchoolMapper schoolMapper;
    @Autowired
    private FamilyMapper familyMapper;
    @Autowired
    private MaterialMapper materialMapper;
    @Autowired
    private PorpertyMapper porpertyMapper;
    @Autowired
    private HouseholdMapper householdMapper;
    @Autowired
    private TimecontrolMapper timecontrolMapper;
    @Autowired
    private RenderingServiceImpl renderingService;

    @Override
     public void testFlag() {
        //第一 ：拉去数据库未审核通过的数据  ESN
        EnrollExample  enrollExample = new EnrollExample();
        enrollExample.createCriteria().andStepEqualTo(1).andBcodeEqualTo("01").andMrdtypeEqualTo(1);
        //获取  wid   以及  type
        List<Enroll>  list= enrollMapper.selectByExample(enrollExample);
        for(int i=0;i<list.size();i++){
            renderingService.sureUpdate(list.get(i).getWid(),list.get(i).getBcode());
        }


    }
}
