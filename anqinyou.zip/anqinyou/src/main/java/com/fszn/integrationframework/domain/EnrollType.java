package com.fszn.integrationframework.domain;

import java.util.Date;

public class EnrollType {
    private String bcode;

    private String btype;

    private Date btime;

    private Date etime;

    private Date btime1;

    private Date etime1;

    private String luquway;

    private String note;

    public String getBcode() {
        return bcode;
    }

    public void setBcode(String bcode) {
        this.bcode = bcode == null ? null : bcode.trim();
    }

    public String getBtype() {
        return btype;
    }

    public void setBtype(String btype) {
        this.btype = btype == null ? null : btype.trim();
    }

    public Date getBtime() {
        return btime;
    }

    public void setBtime(Date btime) {
        this.btime = btime;
    }

    public Date getEtime() {
        return etime;
    }

    public void setEtime(Date etime) {
        this.etime = etime;
    }

    public Date getBtime1() {
        return btime1;
    }

    public void setBtime1(Date btime1) {
        this.btime1 = btime1;
    }

    public Date getEtime1() {
        return etime1;
    }

    public void setEtime1(Date etime1) {
        this.etime1 = etime1;
    }

    public String getLuquway() {
        return luquway;
    }

    public void setLuquway(String luquway) {
        this.luquway = luquway == null ? null : luquway.trim();
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note == null ? null : note.trim();
    }
}