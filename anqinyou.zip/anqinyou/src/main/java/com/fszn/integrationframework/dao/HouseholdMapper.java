package com.fszn.integrationframework.dao;

import com.fszn.integrationframework.domain.Household;
import com.fszn.integrationframework.domain.HouseholdExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface HouseholdMapper {
    long countByExample(HouseholdExample example);

    int deleteByExample(HouseholdExample example);

    int deleteByPrimaryKey(Long rsn);

    int insert(Household record);

    int insertSelective(Household record);

    List<Household> selectByExample(HouseholdExample example);

    Household selectByPrimaryKey(Long rsn);

    int updateByExampleSelective(@Param("record") Household record, @Param("example") HouseholdExample example);

    int updateByExample(@Param("record") Household record, @Param("example") HouseholdExample example);

    int updateByPrimaryKeySelective(Household record);

    int updateByPrimaryKey(Household record);
}