package com.fszn.integrationframework.utils;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Slf4j
public class HttpUtilsGetToken {
    //设定静态常量
    private static final String client_id = "0d2d8ab6e1f147d3b80193797ed339b5";

    private static final String client_secret = "6gugIQewQ7KqRrdL";

    /**
     * 发送GET请求
     *
     * @param url        目的地址
     * @param parameters 请求参数，Map类型。
     * @return 远程响应结果
     */
    public static String sendGet(String url, Map<String, String> parameters) {
        String result = "";
        BufferedReader in = null;// 读取响应输入流
        StringBuffer sb = new StringBuffer();// 存储参数
        String params = "";// 编码之后的参数
        String full_url="";
        try {
            // 编码请求参数
            if (parameters.size() == 1) {
                for (String name : parameters.keySet()) {
                    sb.append(name).append("=").append(
                            java.net.URLEncoder.encode(parameters.get(name),
                                    "UTF-8"));
                }
                params = sb.toString();
                 full_url = url + "?" + params;
            } else if (parameters.size() == 0) {
                 full_url = url ;
            } else {
                for (String name : parameters.keySet()) {
                    sb.append(name).append("=").append(
                            java.net.URLEncoder.encode(parameters.get(name),
                                    "UTF-8")).append("&");
                }
                String temp_params = sb.toString();
                params = temp_params.substring(0, temp_params.length() - 1);
                 full_url  = url + "?" + params;
            }

            System.out.println(full_url);
            // 创建URL对象
            java.net.URL connURL = new java.net.URL(full_url);
            // 打开URL连接
            java.net.HttpURLConnection httpConn = (java.net.HttpURLConnection) connURL
                    .openConnection();
            // 设置通用属性
            httpConn.setRequestProperty("Accept", "*/*");
            httpConn.setRequestProperty("Connection", "Keep-Alive");
            httpConn.setRequestProperty("User-Agent",
                    "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)");
            // 建立实际的连接
            httpConn.connect();
            // 响应头部获取
            Map<String, List<String>> headers = httpConn.getHeaderFields();
            // 遍历所有的响应头字段
            for (String key : headers.keySet()) {
                System.out.println(key + "\t：\t" + headers.get(key));
            }
            // 定义BufferedReader输入流来读取URL的响应,并设置编码方式
            in = new BufferedReader(new InputStreamReader(httpConn
                    .getInputStream(), "UTF-8"));
            String line;
            // 读取返回的内容
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        log.error(result);
        return result;

    }

    /**
     * 发送POST请求
     *
     * @param url        目的地址
     * @param parameters 请求参数，Map类型。
     * @return 远程响应结果
     */
    public static String sendPost(String url, Map<String, String> parameters) {
        String result = "";// 返回的结果
        BufferedReader in = null;// 读取响应输入流
        PrintWriter out = null;
        StringBuffer sb = new StringBuffer();// 处理请求参数
        String params = "";// 编码之后的参数
        try {
            // 编码请求参数
            if (parameters.size() == 1) {
                for (String name : parameters.keySet()) {
                    sb.append(name).append("=").append(
                            java.net.URLEncoder.encode(parameters.get(name),
                                    "UTF-8"));
                }
                params = sb.toString();
            } else {
                for (String name : parameters.keySet()) {
                    sb.append(name).append("=").append(
                            java.net.URLEncoder.encode(parameters.get(name),
                                    "UTF-8")).append("&");
                }
                String temp_params = sb.toString();
                params = temp_params.substring(0, temp_params.length() - 1);
            }
            // 创建URL对象
            java.net.URL connURL = new java.net.URL(url);
            // 打开URL连接
            java.net.HttpURLConnection httpConn = (java.net.HttpURLConnection) connURL
                    .openConnection();
            // 设置通用属性
            httpConn.setRequestProperty("Accept", "*/*");
            httpConn.setRequestProperty("Connection", "Keep-Alive");
            httpConn.setRequestProperty("User-Agent",
                    "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)");
            // 设置POST方式
            httpConn.setDoInput(true);
            httpConn.setDoOutput(true);
            // 获取HttpURLConnection对象对应的输出流
            out = new PrintWriter(httpConn.getOutputStream());
            // 发送请求参数
            out.write(params);
            // flush输出流的缓冲
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应，设置编码方式
            in = new BufferedReader(new InputStreamReader(httpConn
                    .getInputStream(), "UTF-8"));
            String line;
            // 读取返回的内容
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        return result;
    }

    /**
     * 主函数，测试请求
     */
    public static String getMessage() {
        Map<String, String> parameters = new HashMap<String, String>();
        //获取token
        String token = "";
        String result = sendGet("http://220.179.5.123:9090/oauth/token?client_id=" + client_id + "&client_secret=" + client_secret, parameters);
        JsonObject jsonObject = new JsonParser().parse(result).getAsJsonObject();
        Iterator iter = jsonObject.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            if (entry.getKey().toString().equals("access_token")) {
                token = entry.getValue().toString().replace("\"", "");
                ;
                log.info(token);
            }
        }
        return token;

    }

    //通过token、拿到监护人信息
    public static String[] getHuJi(String token, String icd) {
        Map<String, String> parameters = new HashMap<String, String>();
        String[] a = new String[8];
        String result = sendGet("http://220.179.5.123:9090/service/api/zxxbm/hjxxcx2?client_id=" + client_id + "&access_token=" + token + "&STU_IDCARD=" + icd, parameters);
        result = result.replaceAll("(\\[|\\])", "");
        log.info(result);
        if (isjson(result)) {
            JsonObject jsonObject = new JsonParser().parse(result).getAsJsonObject();
            Iterator iter = jsonObject.entrySet().iterator();
            while (iter.hasNext()) {
                Map.Entry entry = (Map.Entry) iter.next();
                if (entry.getKey().toString().equals("jhryxm")) {
                    a[0] = entry.getValue().toString().replace("\"", "");
                    ;
                    log.info(a[0]);
                }
                if (entry.getKey().toString().equals("jhrygmsfhm")) {
                    a[1] = entry.getValue().toString().replace("\"", "");
                    ;
                    log.info(a[1]);
                }
                if (entry.getKey().toString().equals("jhrexm")) {
                    a[2] = entry.getValue().toString().replace("\"", "");
                    ;
                    log.info(a[2]);

                }
                if (entry.getKey().toString().equals("jhregmsfhm")) {
                    a[3] = entry.getValue().toString().replace("\"", "");
                    log.info(a[3]);
                }
                if (entry.getKey().toString().equals("hjdxz")) {
                    a[4] = entry.getValue().toString().replace("\"", "");
                    log.info(a[4]);
                }
                if (entry.getKey().toString().equals("mc")) {
                    a[5] = entry.getValue().toString().replace("\"", "");
                    log.info(a[5]);
                }
                if (entry.getKey().toString().equals("jhryjhgx")) {
                    a[6] = entry.getValue().toString().replace("\"", "");
                    log.info(a[6]);
                }
                if (entry.getKey().toString().equals("jhrejhgx")) {
                    a[7] = entry.getValue().toString().replace("\"", "");
                    log.info(a[7]);
                }



            }
        }
        return a;

    }

    //通过产权证号、身份证获取产权信息
    public static String[] getChanQuan(String token, String number, String icd) {
        Map<String, String> parameters = new HashMap<String, String>();
        String[] a = new String[5];
        String result = sendGet("http://220.179.5.123:9090/service/api/zxxbm/fczxxcx1?client_id=" + client_id + "&access_token=" + token + "&CQRSFZH=" + icd + "&FCZH=" + number, parameters);
        result = result.replaceAll("(\\[|\\])", "");
        log.info(result);
        if (isjson(result)) {
            JsonObject jsonObject = new JsonParser().parse(result).getAsJsonObject();
            Iterator iter = jsonObject.entrySet().iterator();
            while (iter.hasNext()) {
                Map.Entry entry = (Map.Entry) iter.next();
                if (entry.getKey().toString().equals("FCZH")) {
                    a[0] = entry.getValue().toString().replace("\"", "");
                    ;
                    log.info(a[0]);
                }
                if (entry.getKey().toString().equals("CQR")) {
                    a[1] = entry.getValue().toString().replace("\"", "");
                    ;
                    log.info(a[1]);
                }
                if (entry.getKey().toString().equals("CQRSFZH")) {
                    a[2] = entry.getValue().toString().replace("\"", "");
                    ;
                    log.info(a[2]);

                }
                if (entry.getKey().toString().equals("FCDZ")) {
                    a[3] = entry.getValue().toString().replace("\"", "");
                    log.info(a[3]);
                }
                if (entry.getKey().toString().equals("FCZBZSJ")) {
                    a[4] = entry.getValue().toString().replace("\"", "");
                    log.info(a[4]);
                }


            }

        }
        return a;

    }

    private static boolean isjson(String string) {
        try {
            JsonObject jsonStr = new JsonParser().parse(string).getAsJsonObject();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
