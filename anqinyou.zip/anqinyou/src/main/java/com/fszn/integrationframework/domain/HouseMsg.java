package com.fszn.integrationframework.domain;


public class HouseMsg {
    private String jsonImg11;  //图片文件   1 2 3  4  分为4类   即   6 2  3  2  户口、接种 、房产、居住证明
    private String jsonImg12;
    private String jsonImg13;
    private String jsonImg41;
    private String jsonImg42;


    public String getJsonImg41() {
        return jsonImg41;
    }

    public void setJsonImg41(String jsonImg41) {
        this.jsonImg41 = jsonImg41;
    }

    public String getJsonImg42() {
        return jsonImg42;
    }

    public void setJsonImg42(String jsonImg42) {
        this.jsonImg42 = jsonImg42;
    }


    public String getJsonImg11() {
        return jsonImg11;
    }

    public void setJsonImg11(String jsonImg11) {
        this.jsonImg11 = jsonImg11;
    }

    public String getJsonImg12() {
        return jsonImg12;
    }

    public void setJsonImg12(String jsonImg12) {
        this.jsonImg12 = jsonImg12;
    }

    public String getJsonImg13() {
        return jsonImg13;
    }

    public void setJsonImg13(String jsonImg13) {
        this.jsonImg13 = jsonImg13;
    }

    public String getJsonImg14() {
        return jsonImg14;
    }

    public void setJsonImg14(String jsonImg14) {
        this.jsonImg14 = jsonImg14;
    }

    public String getJsonImg15() {
        return jsonImg15;
    }

    public void setJsonImg15(String jsonImg15) {
        this.jsonImg15 = jsonImg15;
    }

    public String getJsonImg16() {
        return jsonImg16;
    }

    public void setJsonImg16(String jsonImg16) {
        this.jsonImg16 = jsonImg16;
    }

    public String getJsonImg21() {
        return jsonImg21;
    }

    public void setJsonImg21(String jsonImg21) {
        this.jsonImg21 = jsonImg21;
    }

    public String getJsonImg22() {
        return jsonImg22;
    }

    public void setJsonImg22(String jsonImg22) {
        this.jsonImg22 = jsonImg22;
    }

    public String getJsonImg31() {
        return jsonImg31;
    }

    public void setJsonImg31(String jsonImg31) {
        this.jsonImg31 = jsonImg31;
    }

    public String getJsonImg32() {
        return jsonImg32;
    }

    public void setJsonImg32(String jsonImg32) {
        this.jsonImg32 = jsonImg32;
    }

    public String getJsonImg33() {
        return jsonImg33;
    }

    public void setJsonImg33(String jsonImg33) {
        this.jsonImg33 = jsonImg33;
    }

    private String jsonImg14;
    private String jsonImg15;
    private String jsonImg16;
    private String jsonImg21;
    private String jsonImg22;
    private String jsonImg31;
    private String jsonImg32;
    private String jsonImg33;
    private String picd;//产权身份证
    private String pno;//产权号
    private String paddress;//房产地址

    public String getPicd() {
        return picd;
    }

    public void setPicd(String picd) {
        this.picd = picd;
    }

    public String getPno() {
        return pno;
    }

    public void setPno(String pno) {
        this.pno = pno;
    }

    public String getPaddress() {
        return paddress;
    }

    public void setPaddress(String paddress) {
        this.paddress = paddress;
    }
}
