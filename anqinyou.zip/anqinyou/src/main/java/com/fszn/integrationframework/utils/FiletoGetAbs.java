package com.fszn.integrationframework.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

@Component
@Slf4j
public class FiletoGetAbs {
    //获取项目存储的绝对路径 并返回FileAttribute
    public static FileAttribute filetoGetAbs(String str, String contentPath,String FileName) {
        FileAttribute fileAttribute= new FileAttribute();
        //上传文件名   contentPath为  当前项目的相对路劲
        File file1 = new File(contentPath);
        log.info("-----------输出文件夹绝对路径 -- 这里的绝对路径是相当于当前项目的路径而不是“容器”路径【" + file1.getAbsolutePath() + "】-----------");
        try{   //进行写入文件
            File dir = new File(file1.getAbsolutePath());
            if(!dir.exists()) {
                dir.mkdirs();
            }//生成文件夹
            File txt = new File(file1.getAbsolutePath() + "\\" + FileName);
            if (!txt.exists()) {
                txt.createNewFile();
            }
            byte bytes[] = new byte[512];
            bytes = str.getBytes();
            int b = bytes.length; // 是字节的长度，不是字符串的长度
            FileOutputStream fos = new FileOutputStream(txt);
            fos.write(bytes);
            fos.flush();
            fos.close();
            fileAttribute.setCode(200);
            fileAttribute.setAddress(file1.getAbsolutePath()+"\\" + FileName);
            fileAttribute.setMname(FileName);
            Date date = new Date();
            Timestamp timeStamep = new Timestamp(date.getTime());
            fileAttribute.setUptime((timeStamep));
            fileAttribute.setMsize(((int) txt.length()/1024));
        }catch (Exception e){
            log.error("文件写入异常");
            fileAttribute.setCode(500);
        }


     return fileAttribute;
    }



}
