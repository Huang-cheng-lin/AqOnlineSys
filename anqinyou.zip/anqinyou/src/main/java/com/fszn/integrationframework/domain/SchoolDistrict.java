package com.fszn.integrationframework.domain;

public class SchoolDistrict {
    private Integer dsn;

    private String dname;

    private String description;

    private Integer dyear;

    public Integer getDsn() {
        return dsn;
    }

    public void setDsn(Integer dsn) {
        this.dsn = dsn;
    }

    public String getDname() {
        return dname;
    }

    public void setDname(String dname) {
        this.dname = dname == null ? null : dname.trim();
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    public Integer getDyear() {
        return dyear;
    }

    public void setDyear(Integer dyear) {
        this.dyear = dyear;
    }
}