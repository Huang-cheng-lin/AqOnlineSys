package com.fszn.integrationframework.domain;

public class Family {
    private Long fsn;

    private Long esn;

    private String realname;

    private String id;

    private String swho;

    private Integer isjhr;

    private String phone;

    public Long getFsn() {
        return fsn;
    }

    public void setFsn(Long fsn) {
        this.fsn = fsn;
    }

    public Long getEsn() {
        return esn;
    }

    public void setEsn(Long esn) {
        this.esn = esn;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname == null ? null : realname.trim();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getSwho() {
        return swho;
    }

    public void setSwho(String swho) {
        this.swho = swho == null ? null : swho.trim();
    }

    public Integer getIsjhr() {
        return isjhr;
    }

    public void setIsjhr(Integer isjhr) {
        this.isjhr = isjhr;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }
}