package com.fszn.integrationframework.service;

import com.fszn.integrationframework.domain.*;
import com.fszn.integrationframework.utils.Result;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface ChooseService {
    Result primaryTomiddle(String type, String wid, int childsn, String schoolname,String selecttypevalue);

    Result choosearea(String type, String wid);

    Result submitxueji(Student student, String wid, int childsn, String type);

    Result submitfamily(Family family1, Family family2, String wid, String type);

    Result submitHouseMsg(HouseMsg houseMsg, String wid, String type);

    Result checkfirst(UserRoll userRoll, String wid);

    Result updatemrdtype(int mrdtype, String wid, String type);

    Result submitSecMsg(SecImg secImg, String wid, int childsn, String type);

    void addIsyh(String phone,String selectchild, String gettype, String wid);

    int getChildsn(String type, String wid);

    Result temporarySecMsg(SecImg secImg, String wid, int childsn, String type);

    int getChildsn1(String type, String wid);

    int getChildsn2(String type, String wid);

    Result delete();

    Result submitxuejiDuo(Student student, Student student1, String wid, int childsn, String gettype, String type);

    Result deleteByEsn(String wid, String type);

    void notAddIsyh(String phone, String wid);

    Result submitHouseMsgMdtype1(MiddleHouseMsg1 houseMsg, String wid, String type);

    Result submitHouseMsgNonMdtype1(MiddleHouseMsgNon1 houseMsg, String wid, String type);

    Result submitHouseMsgMdtype2(MiddleHouseMsg2 houseMsg, String wid, String type);

    Result submitHouseMsgMdtype3(MiddleHouseMsg3 houseMsg, String wid, String type);

    Result submitHouseMsgMdtype4(MiddleHouseMsg4 houseMsg, String wid, String type);

    Result submitShuangXuan(String schoolname, String wid, String type);

    int getErollChildsn(String wid, String type);

    Result submitHouseMsgYSH(HouseMsgYSH houseMsg, String wid, String type);
}
