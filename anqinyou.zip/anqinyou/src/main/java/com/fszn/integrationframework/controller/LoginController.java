package com.fszn.integrationframework.controller;

import com.fszn.integrationframework.service.LoginService;
import com.fszn.integrationframework.utils.HttpUtils;
import com.fszn.integrationframework.utils.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
@RequestMapping("login1")
@Slf4j
public class LoginController {
    @Autowired
    private  LoginService loginService;
    @Autowired
    private  Result result;
    @RequestMapping("/token") //调用token接口   获取用户信息    如返回信息则 转发至用户选择页面
    public String token(String token,HttpServletRequest request, HttpServletResponse response) throws Exception {
        if (token != null) {
            String[] str = HttpUtils.getMessage(token);
            //str   格式为String[6]   从0-5   分别 是  皖氏通id、姓名、性别、接入时间、身份证、手机号
            Cookie cookie = new Cookie("wid", str[0]);   //存入token   并返回 方便下次调用
            Cookie cookie1 = new Cookie("childsn","1");   //存入token   并返回 方便下次调用
            //进行数据库的存储
            loginService.token(str);
            cookie.setPath("/");
            cookie1.setPath("/");
            response.addCookie(cookie);
            response.addCookie(cookie1);
            return "forward:/static/page/index2.html";
        } else {
            return "forward:/static/page/index2.html";

        }


    }
    @RequestMapping("/addChild") //新增小孩报名并跳回首页  更换token
    @ResponseBody
    public Result addChild(Integer count,HttpServletRequest request, HttpServletResponse response) throws Exception {
            Cookie cookie1 = new Cookie("childsn",""+count);   //存入token   并返回 方便下次调用
            //进行数据库的存储
             cookie1.setPath("/");
            response.addCookie(cookie1);
            result.setCode("200");
            result.setContent("../../../static/page/index.html");
            return result ;
    }
}
