package com.fszn.integrationframework.dao;

import com.fszn.integrationframework.domain.Porperty;
import com.fszn.integrationframework.domain.PorpertyExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PorpertyMapper {
    long countByExample(PorpertyExample example);

    int deleteByExample(PorpertyExample example);

    int deleteByPrimaryKey(Long psn);

    int insert(Porperty record);

    int insertSelective(Porperty record);

    List<Porperty> selectByExample(PorpertyExample example);

    Porperty selectByPrimaryKey(Long psn);

    int updateByExampleSelective(@Param("record") Porperty record, @Param("example") PorpertyExample example);

    int updateByExample(@Param("record") Porperty record, @Param("example") PorpertyExample example);

    int updateByPrimaryKeySelective(Porperty record);

    int updateByPrimaryKey(Porperty record);
}