package com.fszn.integrationframework.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EnrollExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public EnrollExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andEsnIsNull() {
            addCriterion("esn is null");
            return (Criteria) this;
        }

        public Criteria andEsnIsNotNull() {
            addCriterion("esn is not null");
            return (Criteria) this;
        }

        public Criteria andEsnEqualTo(Long value) {
            addCriterion("esn =", value, "esn");
            return (Criteria) this;
        }

        public Criteria andEsnNotEqualTo(Long value) {
            addCriterion("esn <>", value, "esn");
            return (Criteria) this;
        }

        public Criteria andEsnGreaterThan(Long value) {
            addCriterion("esn >", value, "esn");
            return (Criteria) this;
        }

        public Criteria andEsnGreaterThanOrEqualTo(Long value) {
            addCriterion("esn >=", value, "esn");
            return (Criteria) this;
        }

        public Criteria andEsnLessThan(Long value) {
            addCriterion("esn <", value, "esn");
            return (Criteria) this;
        }

        public Criteria andEsnLessThanOrEqualTo(Long value) {
            addCriterion("esn <=", value, "esn");
            return (Criteria) this;
        }

        public Criteria andEsnIn(List<Long> values) {
            addCriterion("esn in", values, "esn");
            return (Criteria) this;
        }

        public Criteria andEsnNotIn(List<Long> values) {
            addCriterion("esn not in", values, "esn");
            return (Criteria) this;
        }

        public Criteria andEsnBetween(Long value1, Long value2) {
            addCriterion("esn between", value1, value2, "esn");
            return (Criteria) this;
        }

        public Criteria andEsnNotBetween(Long value1, Long value2) {
            addCriterion("esn not between", value1, value2, "esn");
            return (Criteria) this;
        }

        public Criteria andWidIsNull() {
            addCriterion("wid is null");
            return (Criteria) this;
        }

        public Criteria andWidIsNotNull() {
            addCriterion("wid is not null");
            return (Criteria) this;
        }

        public Criteria andWidEqualTo(String value) {
            addCriterion("wid =", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidNotEqualTo(String value) {
            addCriterion("wid <>", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidGreaterThan(String value) {
            addCriterion("wid >", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidGreaterThanOrEqualTo(String value) {
            addCriterion("wid >=", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidLessThan(String value) {
            addCriterion("wid <", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidLessThanOrEqualTo(String value) {
            addCriterion("wid <=", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidLike(String value) {
            addCriterion("wid like", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidNotLike(String value) {
            addCriterion("wid not like", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidIn(List<String> values) {
            addCriterion("wid in", values, "wid");
            return (Criteria) this;
        }

        public Criteria andWidNotIn(List<String> values) {
            addCriterion("wid not in", values, "wid");
            return (Criteria) this;
        }

        public Criteria andWidBetween(String value1, String value2) {
            addCriterion("wid between", value1, value2, "wid");
            return (Criteria) this;
        }

        public Criteria andWidNotBetween(String value1, String value2) {
            addCriterion("wid not between", value1, value2, "wid");
            return (Criteria) this;
        }

        public Criteria andChildsnIsNull() {
            addCriterion("childsn is null");
            return (Criteria) this;
        }

        public Criteria andChildsnIsNotNull() {
            addCriterion("childsn is not null");
            return (Criteria) this;
        }

        public Criteria andChildsnEqualTo(Integer value) {
            addCriterion("childsn =", value, "childsn");
            return (Criteria) this;
        }

        public Criteria andChildsnNotEqualTo(Integer value) {
            addCriterion("childsn <>", value, "childsn");
            return (Criteria) this;
        }

        public Criteria andChildsnGreaterThan(Integer value) {
            addCriterion("childsn >", value, "childsn");
            return (Criteria) this;
        }

        public Criteria andChildsnGreaterThanOrEqualTo(Integer value) {
            addCriterion("childsn >=", value, "childsn");
            return (Criteria) this;
        }

        public Criteria andChildsnLessThan(Integer value) {
            addCriterion("childsn <", value, "childsn");
            return (Criteria) this;
        }

        public Criteria andChildsnLessThanOrEqualTo(Integer value) {
            addCriterion("childsn <=", value, "childsn");
            return (Criteria) this;
        }

        public Criteria andChildsnIn(List<Integer> values) {
            addCriterion("childsn in", values, "childsn");
            return (Criteria) this;
        }

        public Criteria andChildsnNotIn(List<Integer> values) {
            addCriterion("childsn not in", values, "childsn");
            return (Criteria) this;
        }

        public Criteria andChildsnBetween(Integer value1, Integer value2) {
            addCriterion("childsn between", value1, value2, "childsn");
            return (Criteria) this;
        }

        public Criteria andChildsnNotBetween(Integer value1, Integer value2) {
            addCriterion("childsn not between", value1, value2, "childsn");
            return (Criteria) this;
        }

        public Criteria andBcodeIsNull() {
            addCriterion("bcode is null");
            return (Criteria) this;
        }

        public Criteria andBcodeIsNotNull() {
            addCriterion("bcode is not null");
            return (Criteria) this;
        }

        public Criteria andBcodeEqualTo(String value) {
            addCriterion("bcode =", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeNotEqualTo(String value) {
            addCriterion("bcode <>", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeGreaterThan(String value) {
            addCriterion("bcode >", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeGreaterThanOrEqualTo(String value) {
            addCriterion("bcode >=", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeLessThan(String value) {
            addCriterion("bcode <", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeLessThanOrEqualTo(String value) {
            addCriterion("bcode <=", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeLike(String value) {
            addCriterion("bcode like", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeNotLike(String value) {
            addCriterion("bcode not like", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeIn(List<String> values) {
            addCriterion("bcode in", values, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeNotIn(List<String> values) {
            addCriterion("bcode not in", values, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeBetween(String value1, String value2) {
            addCriterion("bcode between", value1, value2, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeNotBetween(String value1, String value2) {
            addCriterion("bcode not between", value1, value2, "bcode");
            return (Criteria) this;
        }

        public Criteria andEdtIsNull() {
            addCriterion("edt is null");
            return (Criteria) this;
        }

        public Criteria andEdtIsNotNull() {
            addCriterion("edt is not null");
            return (Criteria) this;
        }

        public Criteria andEdtEqualTo(Date value) {
            addCriterion("edt =", value, "edt");
            return (Criteria) this;
        }

        public Criteria andEdtNotEqualTo(Date value) {
            addCriterion("edt <>", value, "edt");
            return (Criteria) this;
        }

        public Criteria andEdtGreaterThan(Date value) {
            addCriterion("edt >", value, "edt");
            return (Criteria) this;
        }

        public Criteria andEdtGreaterThanOrEqualTo(Date value) {
            addCriterion("edt >=", value, "edt");
            return (Criteria) this;
        }

        public Criteria andEdtLessThan(Date value) {
            addCriterion("edt <", value, "edt");
            return (Criteria) this;
        }

        public Criteria andEdtLessThanOrEqualTo(Date value) {
            addCriterion("edt <=", value, "edt");
            return (Criteria) this;
        }

        public Criteria andEdtIn(List<Date> values) {
            addCriterion("edt in", values, "edt");
            return (Criteria) this;
        }

        public Criteria andEdtNotIn(List<Date> values) {
            addCriterion("edt not in", values, "edt");
            return (Criteria) this;
        }

        public Criteria andEdtBetween(Date value1, Date value2) {
            addCriterion("edt between", value1, value2, "edt");
            return (Criteria) this;
        }

        public Criteria andEdtNotBetween(Date value1, Date value2) {
            addCriterion("edt not between", value1, value2, "edt");
            return (Criteria) this;
        }

        public Criteria andStepIsNull() {
            addCriterion("step is null");
            return (Criteria) this;
        }

        public Criteria andStepIsNotNull() {
            addCriterion("step is not null");
            return (Criteria) this;
        }

        public Criteria andStepEqualTo(Integer value) {
            addCriterion("step =", value, "step");
            return (Criteria) this;
        }

        public Criteria andStepNotEqualTo(Integer value) {
            addCriterion("step <>", value, "step");
            return (Criteria) this;
        }

        public Criteria andStepGreaterThan(Integer value) {
            addCriterion("step >", value, "step");
            return (Criteria) this;
        }

        public Criteria andStepGreaterThanOrEqualTo(Integer value) {
            addCriterion("step >=", value, "step");
            return (Criteria) this;
        }

        public Criteria andStepLessThan(Integer value) {
            addCriterion("step <", value, "step");
            return (Criteria) this;
        }

        public Criteria andStepLessThanOrEqualTo(Integer value) {
            addCriterion("step <=", value, "step");
            return (Criteria) this;
        }

        public Criteria andStepIn(List<Integer> values) {
            addCriterion("step in", values, "step");
            return (Criteria) this;
        }

        public Criteria andStepNotIn(List<Integer> values) {
            addCriterion("step not in", values, "step");
            return (Criteria) this;
        }

        public Criteria andStepBetween(Integer value1, Integer value2) {
            addCriterion("step between", value1, value2, "step");
            return (Criteria) this;
        }

        public Criteria andStepNotBetween(Integer value1, Integer value2) {
            addCriterion("step not between", value1, value2, "step");
            return (Criteria) this;
        }

        public Criteria andMrdtypeIsNull() {
            addCriterion("mrdtype is null");
            return (Criteria) this;
        }

        public Criteria andMrdtypeIsNotNull() {
            addCriterion("mrdtype is not null");
            return (Criteria) this;
        }

        public Criteria andMrdtypeEqualTo(Integer value) {
            addCriterion("mrdtype =", value, "mrdtype");
            return (Criteria) this;
        }

        public Criteria andMrdtypeNotEqualTo(Integer value) {
            addCriterion("mrdtype <>", value, "mrdtype");
            return (Criteria) this;
        }

        public Criteria andMrdtypeGreaterThan(Integer value) {
            addCriterion("mrdtype >", value, "mrdtype");
            return (Criteria) this;
        }

        public Criteria andMrdtypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("mrdtype >=", value, "mrdtype");
            return (Criteria) this;
        }

        public Criteria andMrdtypeLessThan(Integer value) {
            addCriterion("mrdtype <", value, "mrdtype");
            return (Criteria) this;
        }

        public Criteria andMrdtypeLessThanOrEqualTo(Integer value) {
            addCriterion("mrdtype <=", value, "mrdtype");
            return (Criteria) this;
        }

        public Criteria andMrdtypeIn(List<Integer> values) {
            addCriterion("mrdtype in", values, "mrdtype");
            return (Criteria) this;
        }

        public Criteria andMrdtypeNotIn(List<Integer> values) {
            addCriterion("mrdtype not in", values, "mrdtype");
            return (Criteria) this;
        }

        public Criteria andMrdtypeBetween(Integer value1, Integer value2) {
            addCriterion("mrdtype between", value1, value2, "mrdtype");
            return (Criteria) this;
        }

        public Criteria andMrdtypeNotBetween(Integer value1, Integer value2) {
            addCriterion("mrdtype not between", value1, value2, "mrdtype");
            return (Criteria) this;
        }

        public Criteria andBinfoIsrightIsNull() {
            addCriterion("binfo_isright is null");
            return (Criteria) this;
        }

        public Criteria andBinfoIsrightIsNotNull() {
            addCriterion("binfo_isright is not null");
            return (Criteria) this;
        }

        public Criteria andBinfoIsrightEqualTo(Integer value) {
            addCriterion("binfo_isright =", value, "binfoIsright");
            return (Criteria) this;
        }

        public Criteria andBinfoIsrightNotEqualTo(Integer value) {
            addCriterion("binfo_isright <>", value, "binfoIsright");
            return (Criteria) this;
        }

        public Criteria andBinfoIsrightGreaterThan(Integer value) {
            addCriterion("binfo_isright >", value, "binfoIsright");
            return (Criteria) this;
        }

        public Criteria andBinfoIsrightGreaterThanOrEqualTo(Integer value) {
            addCriterion("binfo_isright >=", value, "binfoIsright");
            return (Criteria) this;
        }

        public Criteria andBinfoIsrightLessThan(Integer value) {
            addCriterion("binfo_isright <", value, "binfoIsright");
            return (Criteria) this;
        }

        public Criteria andBinfoIsrightLessThanOrEqualTo(Integer value) {
            addCriterion("binfo_isright <=", value, "binfoIsright");
            return (Criteria) this;
        }

        public Criteria andBinfoIsrightIn(List<Integer> values) {
            addCriterion("binfo_isright in", values, "binfoIsright");
            return (Criteria) this;
        }

        public Criteria andBinfoIsrightNotIn(List<Integer> values) {
            addCriterion("binfo_isright not in", values, "binfoIsright");
            return (Criteria) this;
        }

        public Criteria andBinfoIsrightBetween(Integer value1, Integer value2) {
            addCriterion("binfo_isright between", value1, value2, "binfoIsright");
            return (Criteria) this;
        }

        public Criteria andBinfoIsrightNotBetween(Integer value1, Integer value2) {
            addCriterion("binfo_isright not between", value1, value2, "binfoIsright");
            return (Criteria) this;
        }

        public Criteria andMaterialIsrightIsNull() {
            addCriterion("material_isright is null");
            return (Criteria) this;
        }

        public Criteria andMaterialIsrightIsNotNull() {
            addCriterion("material_isright is not null");
            return (Criteria) this;
        }

        public Criteria andMaterialIsrightEqualTo(Integer value) {
            addCriterion("material_isright =", value, "materialIsright");
            return (Criteria) this;
        }

        public Criteria andMaterialIsrightNotEqualTo(Integer value) {
            addCriterion("material_isright <>", value, "materialIsright");
            return (Criteria) this;
        }

        public Criteria andMaterialIsrightGreaterThan(Integer value) {
            addCriterion("material_isright >", value, "materialIsright");
            return (Criteria) this;
        }

        public Criteria andMaterialIsrightGreaterThanOrEqualTo(Integer value) {
            addCriterion("material_isright >=", value, "materialIsright");
            return (Criteria) this;
        }

        public Criteria andMaterialIsrightLessThan(Integer value) {
            addCriterion("material_isright <", value, "materialIsright");
            return (Criteria) this;
        }

        public Criteria andMaterialIsrightLessThanOrEqualTo(Integer value) {
            addCriterion("material_isright <=", value, "materialIsright");
            return (Criteria) this;
        }

        public Criteria andMaterialIsrightIn(List<Integer> values) {
            addCriterion("material_isright in", values, "materialIsright");
            return (Criteria) this;
        }

        public Criteria andMaterialIsrightNotIn(List<Integer> values) {
            addCriterion("material_isright not in", values, "materialIsright");
            return (Criteria) this;
        }

        public Criteria andMaterialIsrightBetween(Integer value1, Integer value2) {
            addCriterion("material_isright between", value1, value2, "materialIsright");
            return (Criteria) this;
        }

        public Criteria andMaterialIsrightNotBetween(Integer value1, Integer value2) {
            addCriterion("material_isright not between", value1, value2, "materialIsright");
            return (Criteria) this;
        }

        public Criteria andPreauditIsNull() {
            addCriterion("preaudit is null");
            return (Criteria) this;
        }

        public Criteria andPreauditIsNotNull() {
            addCriterion("preaudit is not null");
            return (Criteria) this;
        }

        public Criteria andPreauditEqualTo(Integer value) {
            addCriterion("preaudit =", value, "preaudit");
            return (Criteria) this;
        }

        public Criteria andPreauditNotEqualTo(Integer value) {
            addCriterion("preaudit <>", value, "preaudit");
            return (Criteria) this;
        }

        public Criteria andPreauditGreaterThan(Integer value) {
            addCriterion("preaudit >", value, "preaudit");
            return (Criteria) this;
        }

        public Criteria andPreauditGreaterThanOrEqualTo(Integer value) {
            addCriterion("preaudit >=", value, "preaudit");
            return (Criteria) this;
        }

        public Criteria andPreauditLessThan(Integer value) {
            addCriterion("preaudit <", value, "preaudit");
            return (Criteria) this;
        }

        public Criteria andPreauditLessThanOrEqualTo(Integer value) {
            addCriterion("preaudit <=", value, "preaudit");
            return (Criteria) this;
        }

        public Criteria andPreauditIn(List<Integer> values) {
            addCriterion("preaudit in", values, "preaudit");
            return (Criteria) this;
        }

        public Criteria andPreauditNotIn(List<Integer> values) {
            addCriterion("preaudit not in", values, "preaudit");
            return (Criteria) this;
        }

        public Criteria andPreauditBetween(Integer value1, Integer value2) {
            addCriterion("preaudit between", value1, value2, "preaudit");
            return (Criteria) this;
        }

        public Criteria andPreauditNotBetween(Integer value1, Integer value2) {
            addCriterion("preaudit not between", value1, value2, "preaudit");
            return (Criteria) this;
        }

        public Criteria andSchool1IsNull() {
            addCriterion("school1 is null");
            return (Criteria) this;
        }

        public Criteria andSchool1IsNotNull() {
            addCriterion("school1 is not null");
            return (Criteria) this;
        }

        public Criteria andSchool1EqualTo(String value) {
            addCriterion("school1 =", value, "school1");
            return (Criteria) this;
        }

        public Criteria andSchool1NotEqualTo(String value) {
            addCriterion("school1 <>", value, "school1");
            return (Criteria) this;
        }

        public Criteria andSchool1GreaterThan(String value) {
            addCriterion("school1 >", value, "school1");
            return (Criteria) this;
        }

        public Criteria andSchool1GreaterThanOrEqualTo(String value) {
            addCriterion("school1 >=", value, "school1");
            return (Criteria) this;
        }

        public Criteria andSchool1LessThan(String value) {
            addCriterion("school1 <", value, "school1");
            return (Criteria) this;
        }

        public Criteria andSchool1LessThanOrEqualTo(String value) {
            addCriterion("school1 <=", value, "school1");
            return (Criteria) this;
        }

        public Criteria andSchool1Like(String value) {
            addCriterion("school1 like", value, "school1");
            return (Criteria) this;
        }

        public Criteria andSchool1NotLike(String value) {
            addCriterion("school1 not like", value, "school1");
            return (Criteria) this;
        }

        public Criteria andSchool1In(List<String> values) {
            addCriterion("school1 in", values, "school1");
            return (Criteria) this;
        }

        public Criteria andSchool1NotIn(List<String> values) {
            addCriterion("school1 not in", values, "school1");
            return (Criteria) this;
        }

        public Criteria andSchool1Between(String value1, String value2) {
            addCriterion("school1 between", value1, value2, "school1");
            return (Criteria) this;
        }

        public Criteria andSchool1NotBetween(String value1, String value2) {
            addCriterion("school1 not between", value1, value2, "school1");
            return (Criteria) this;
        }

        public Criteria andSchool2IsNull() {
            addCriterion("school2 is null");
            return (Criteria) this;
        }

        public Criteria andSchool2IsNotNull() {
            addCriterion("school2 is not null");
            return (Criteria) this;
        }

        public Criteria andSchool2EqualTo(String value) {
            addCriterion("school2 =", value, "school2");
            return (Criteria) this;
        }

        public Criteria andSchool2NotEqualTo(String value) {
            addCriterion("school2 <>", value, "school2");
            return (Criteria) this;
        }

        public Criteria andSchool2GreaterThan(String value) {
            addCriterion("school2 >", value, "school2");
            return (Criteria) this;
        }

        public Criteria andSchool2GreaterThanOrEqualTo(String value) {
            addCriterion("school2 >=", value, "school2");
            return (Criteria) this;
        }

        public Criteria andSchool2LessThan(String value) {
            addCriterion("school2 <", value, "school2");
            return (Criteria) this;
        }

        public Criteria andSchool2LessThanOrEqualTo(String value) {
            addCriterion("school2 <=", value, "school2");
            return (Criteria) this;
        }

        public Criteria andSchool2Like(String value) {
            addCriterion("school2 like", value, "school2");
            return (Criteria) this;
        }

        public Criteria andSchool2NotLike(String value) {
            addCriterion("school2 not like", value, "school2");
            return (Criteria) this;
        }

        public Criteria andSchool2In(List<String> values) {
            addCriterion("school2 in", values, "school2");
            return (Criteria) this;
        }

        public Criteria andSchool2NotIn(List<String> values) {
            addCriterion("school2 not in", values, "school2");
            return (Criteria) this;
        }

        public Criteria andSchool2Between(String value1, String value2) {
            addCriterion("school2 between", value1, value2, "school2");
            return (Criteria) this;
        }

        public Criteria andSchool2NotBetween(String value1, String value2) {
            addCriterion("school2 not between", value1, value2, "school2");
            return (Criteria) this;
        }

        public Criteria andNoteIsNull() {
            addCriterion("note is null");
            return (Criteria) this;
        }

        public Criteria andNoteIsNotNull() {
            addCriterion("note is not null");
            return (Criteria) this;
        }

        public Criteria andNoteEqualTo(String value) {
            addCriterion("note =", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotEqualTo(String value) {
            addCriterion("note <>", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteGreaterThan(String value) {
            addCriterion("note >", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteGreaterThanOrEqualTo(String value) {
            addCriterion("note >=", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteLessThan(String value) {
            addCriterion("note <", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteLessThanOrEqualTo(String value) {
            addCriterion("note <=", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteLike(String value) {
            addCriterion("note like", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotLike(String value) {
            addCriterion("note not like", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteIn(List<String> values) {
            addCriterion("note in", values, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotIn(List<String> values) {
            addCriterion("note not in", values, "note");
            return (Criteria) this;
        }

        public Criteria andNoteBetween(String value1, String value2) {
            addCriterion("note between", value1, value2, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotBetween(String value1, String value2) {
            addCriterion("note not between", value1, value2, "note");
            return (Criteria) this;
        }

        public Criteria andUidSchoolIsNull() {
            addCriterion("uid_school is null");
            return (Criteria) this;
        }

        public Criteria andUidSchoolIsNotNull() {
            addCriterion("uid_school is not null");
            return (Criteria) this;
        }

        public Criteria andUidSchoolEqualTo(Long value) {
            addCriterion("uid_school =", value, "uidSchool");
            return (Criteria) this;
        }

        public Criteria andUidSchoolNotEqualTo(Long value) {
            addCriterion("uid_school <>", value, "uidSchool");
            return (Criteria) this;
        }

        public Criteria andUidSchoolGreaterThan(Long value) {
            addCriterion("uid_school >", value, "uidSchool");
            return (Criteria) this;
        }

        public Criteria andUidSchoolGreaterThanOrEqualTo(Long value) {
            addCriterion("uid_school >=", value, "uidSchool");
            return (Criteria) this;
        }

        public Criteria andUidSchoolLessThan(Long value) {
            addCriterion("uid_school <", value, "uidSchool");
            return (Criteria) this;
        }

        public Criteria andUidSchoolLessThanOrEqualTo(Long value) {
            addCriterion("uid_school <=", value, "uidSchool");
            return (Criteria) this;
        }

        public Criteria andUidSchoolIn(List<Long> values) {
            addCriterion("uid_school in", values, "uidSchool");
            return (Criteria) this;
        }

        public Criteria andUidSchoolNotIn(List<Long> values) {
            addCriterion("uid_school not in", values, "uidSchool");
            return (Criteria) this;
        }

        public Criteria andUidSchoolBetween(Long value1, Long value2) {
            addCriterion("uid_school between", value1, value2, "uidSchool");
            return (Criteria) this;
        }

        public Criteria andUidSchoolNotBetween(Long value1, Long value2) {
            addCriterion("uid_school not between", value1, value2, "uidSchool");
            return (Criteria) this;
        }

        public Criteria andShTimeIsNull() {
            addCriterion("sh_time is null");
            return (Criteria) this;
        }

        public Criteria andShTimeIsNotNull() {
            addCriterion("sh_time is not null");
            return (Criteria) this;
        }

        public Criteria andShTimeEqualTo(Date value) {
            addCriterion("sh_time =", value, "shTime");
            return (Criteria) this;
        }

        public Criteria andShTimeNotEqualTo(Date value) {
            addCriterion("sh_time <>", value, "shTime");
            return (Criteria) this;
        }

        public Criteria andShTimeGreaterThan(Date value) {
            addCriterion("sh_time >", value, "shTime");
            return (Criteria) this;
        }

        public Criteria andShTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("sh_time >=", value, "shTime");
            return (Criteria) this;
        }

        public Criteria andShTimeLessThan(Date value) {
            addCriterion("sh_time <", value, "shTime");
            return (Criteria) this;
        }

        public Criteria andShTimeLessThanOrEqualTo(Date value) {
            addCriterion("sh_time <=", value, "shTime");
            return (Criteria) this;
        }

        public Criteria andShTimeIn(List<Date> values) {
            addCriterion("sh_time in", values, "shTime");
            return (Criteria) this;
        }

        public Criteria andShTimeNotIn(List<Date> values) {
            addCriterion("sh_time not in", values, "shTime");
            return (Criteria) this;
        }

        public Criteria andShTimeBetween(Date value1, Date value2) {
            addCriterion("sh_time between", value1, value2, "shTime");
            return (Criteria) this;
        }

        public Criteria andShTimeNotBetween(Date value1, Date value2) {
            addCriterion("sh_time not between", value1, value2, "shTime");
            return (Criteria) this;
        }

        public Criteria andFlagIsNull() {
            addCriterion("Flag is null");
            return (Criteria) this;
        }

        public Criteria andFlagIsNotNull() {
            addCriterion("Flag is not null");
            return (Criteria) this;
        }

        public Criteria andFlagEqualTo(Integer value) {
            addCriterion("Flag =", value, "flag");
            return (Criteria) this;
        }

        public Criteria andFlagNotEqualTo(Integer value) {
            addCriterion("Flag <>", value, "flag");
            return (Criteria) this;
        }

        public Criteria andFlagGreaterThan(Integer value) {
            addCriterion("Flag >", value, "flag");
            return (Criteria) this;
        }

        public Criteria andFlagGreaterThanOrEqualTo(Integer value) {
            addCriterion("Flag >=", value, "flag");
            return (Criteria) this;
        }

        public Criteria andFlagLessThan(Integer value) {
            addCriterion("Flag <", value, "flag");
            return (Criteria) this;
        }

        public Criteria andFlagLessThanOrEqualTo(Integer value) {
            addCriterion("Flag <=", value, "flag");
            return (Criteria) this;
        }

        public Criteria andFlagIn(List<Integer> values) {
            addCriterion("Flag in", values, "flag");
            return (Criteria) this;
        }

        public Criteria andFlagNotIn(List<Integer> values) {
            addCriterion("Flag not in", values, "flag");
            return (Criteria) this;
        }

        public Criteria andFlagBetween(Integer value1, Integer value2) {
            addCriterion("Flag between", value1, value2, "flag");
            return (Criteria) this;
        }

        public Criteria andFlagNotBetween(Integer value1, Integer value2) {
            addCriterion("Flag not between", value1, value2, "flag");
            return (Criteria) this;
        }

        public Criteria andUidGlIsNull() {
            addCriterion("uid_gl is null");
            return (Criteria) this;
        }

        public Criteria andUidGlIsNotNull() {
            addCriterion("uid_gl is not null");
            return (Criteria) this;
        }

        public Criteria andUidGlEqualTo(Long value) {
            addCriterion("uid_gl =", value, "uidGl");
            return (Criteria) this;
        }

        public Criteria andUidGlNotEqualTo(Long value) {
            addCriterion("uid_gl <>", value, "uidGl");
            return (Criteria) this;
        }

        public Criteria andUidGlGreaterThan(Long value) {
            addCriterion("uid_gl >", value, "uidGl");
            return (Criteria) this;
        }

        public Criteria andUidGlGreaterThanOrEqualTo(Long value) {
            addCriterion("uid_gl >=", value, "uidGl");
            return (Criteria) this;
        }

        public Criteria andUidGlLessThan(Long value) {
            addCriterion("uid_gl <", value, "uidGl");
            return (Criteria) this;
        }

        public Criteria andUidGlLessThanOrEqualTo(Long value) {
            addCriterion("uid_gl <=", value, "uidGl");
            return (Criteria) this;
        }

        public Criteria andUidGlIn(List<Long> values) {
            addCriterion("uid_gl in", values, "uidGl");
            return (Criteria) this;
        }

        public Criteria andUidGlNotIn(List<Long> values) {
            addCriterion("uid_gl not in", values, "uidGl");
            return (Criteria) this;
        }

        public Criteria andUidGlBetween(Long value1, Long value2) {
            addCriterion("uid_gl between", value1, value2, "uidGl");
            return (Criteria) this;
        }

        public Criteria andUidGlNotBetween(Long value1, Long value2) {
            addCriterion("uid_gl not between", value1, value2, "uidGl");
            return (Criteria) this;
        }

        public Criteria andShTimeGlIsNull() {
            addCriterion("sh_time_gl is null");
            return (Criteria) this;
        }

        public Criteria andShTimeGlIsNotNull() {
            addCriterion("sh_time_gl is not null");
            return (Criteria) this;
        }

        public Criteria andShTimeGlEqualTo(Date value) {
            addCriterion("sh_time_gl =", value, "shTimeGl");
            return (Criteria) this;
        }

        public Criteria andShTimeGlNotEqualTo(Date value) {
            addCriterion("sh_time_gl <>", value, "shTimeGl");
            return (Criteria) this;
        }

        public Criteria andShTimeGlGreaterThan(Date value) {
            addCriterion("sh_time_gl >", value, "shTimeGl");
            return (Criteria) this;
        }

        public Criteria andShTimeGlGreaterThanOrEqualTo(Date value) {
            addCriterion("sh_time_gl >=", value, "shTimeGl");
            return (Criteria) this;
        }

        public Criteria andShTimeGlLessThan(Date value) {
            addCriterion("sh_time_gl <", value, "shTimeGl");
            return (Criteria) this;
        }

        public Criteria andShTimeGlLessThanOrEqualTo(Date value) {
            addCriterion("sh_time_gl <=", value, "shTimeGl");
            return (Criteria) this;
        }

        public Criteria andShTimeGlIn(List<Date> values) {
            addCriterion("sh_time_gl in", values, "shTimeGl");
            return (Criteria) this;
        }

        public Criteria andShTimeGlNotIn(List<Date> values) {
            addCriterion("sh_time_gl not in", values, "shTimeGl");
            return (Criteria) this;
        }

        public Criteria andShTimeGlBetween(Date value1, Date value2) {
            addCriterion("sh_time_gl between", value1, value2, "shTimeGl");
            return (Criteria) this;
        }

        public Criteria andShTimeGlNotBetween(Date value1, Date value2) {
            addCriterion("sh_time_gl not between", value1, value2, "shTimeGl");
            return (Criteria) this;
        }

        public Criteria andFrom1IsNull() {
            addCriterion("from1 is null");
            return (Criteria) this;
        }

        public Criteria andFrom1IsNotNull() {
            addCriterion("from1 is not null");
            return (Criteria) this;
        }

        public Criteria andFrom1EqualTo(String value) {
            addCriterion("from1 =", value, "from1");
            return (Criteria) this;
        }

        public Criteria andFrom1NotEqualTo(String value) {
            addCriterion("from1 <>", value, "from1");
            return (Criteria) this;
        }

        public Criteria andFrom1GreaterThan(String value) {
            addCriterion("from1 >", value, "from1");
            return (Criteria) this;
        }

        public Criteria andFrom1GreaterThanOrEqualTo(String value) {
            addCriterion("from1 >=", value, "from1");
            return (Criteria) this;
        }

        public Criteria andFrom1LessThan(String value) {
            addCriterion("from1 <", value, "from1");
            return (Criteria) this;
        }

        public Criteria andFrom1LessThanOrEqualTo(String value) {
            addCriterion("from1 <=", value, "from1");
            return (Criteria) this;
        }

        public Criteria andFrom1Like(String value) {
            addCriterion("from1 like", value, "from1");
            return (Criteria) this;
        }

        public Criteria andFrom1NotLike(String value) {
            addCriterion("from1 not like", value, "from1");
            return (Criteria) this;
        }

        public Criteria andFrom1In(List<String> values) {
            addCriterion("from1 in", values, "from1");
            return (Criteria) this;
        }

        public Criteria andFrom1NotIn(List<String> values) {
            addCriterion("from1 not in", values, "from1");
            return (Criteria) this;
        }

        public Criteria andFrom1Between(String value1, String value2) {
            addCriterion("from1 between", value1, value2, "from1");
            return (Criteria) this;
        }

        public Criteria andFrom1NotBetween(String value1, String value2) {
            addCriterion("from1 not between", value1, value2, "from1");
            return (Criteria) this;
        }

        public Criteria andDflagIsNull() {
            addCriterion("dflag is null");
            return (Criteria) this;
        }

        public Criteria andDflagIsNotNull() {
            addCriterion("dflag is not null");
            return (Criteria) this;
        }

        public Criteria andDflagEqualTo(Integer value) {
            addCriterion("dflag =", value, "dflag");
            return (Criteria) this;
        }

        public Criteria andDflagNotEqualTo(Integer value) {
            addCriterion("dflag <>", value, "dflag");
            return (Criteria) this;
        }

        public Criteria andDflagGreaterThan(Integer value) {
            addCriterion("dflag >", value, "dflag");
            return (Criteria) this;
        }

        public Criteria andDflagGreaterThanOrEqualTo(Integer value) {
            addCriterion("dflag >=", value, "dflag");
            return (Criteria) this;
        }

        public Criteria andDflagLessThan(Integer value) {
            addCriterion("dflag <", value, "dflag");
            return (Criteria) this;
        }

        public Criteria andDflagLessThanOrEqualTo(Integer value) {
            addCriterion("dflag <=", value, "dflag");
            return (Criteria) this;
        }

        public Criteria andDflagIn(List<Integer> values) {
            addCriterion("dflag in", values, "dflag");
            return (Criteria) this;
        }

        public Criteria andDflagNotIn(List<Integer> values) {
            addCriterion("dflag not in", values, "dflag");
            return (Criteria) this;
        }

        public Criteria andDflagBetween(Integer value1, Integer value2) {
            addCriterion("dflag between", value1, value2, "dflag");
            return (Criteria) this;
        }

        public Criteria andDflagNotBetween(Integer value1, Integer value2) {
            addCriterion("dflag not between", value1, value2, "dflag");
            return (Criteria) this;
        }

        public Criteria andLqflagIsNull() {
            addCriterion("lqflag is null");
            return (Criteria) this;
        }

        public Criteria andLqflagIsNotNull() {
            addCriterion("lqflag is not null");
            return (Criteria) this;
        }

        public Criteria andLqflagEqualTo(Integer value) {
            addCriterion("lqflag =", value, "lqflag");
            return (Criteria) this;
        }

        public Criteria andLqflagNotEqualTo(Integer value) {
            addCriterion("lqflag <>", value, "lqflag");
            return (Criteria) this;
        }

        public Criteria andLqflagGreaterThan(Integer value) {
            addCriterion("lqflag >", value, "lqflag");
            return (Criteria) this;
        }

        public Criteria andLqflagGreaterThanOrEqualTo(Integer value) {
            addCriterion("lqflag >=", value, "lqflag");
            return (Criteria) this;
        }

        public Criteria andLqflagLessThan(Integer value) {
            addCriterion("lqflag <", value, "lqflag");
            return (Criteria) this;
        }

        public Criteria andLqflagLessThanOrEqualTo(Integer value) {
            addCriterion("lqflag <=", value, "lqflag");
            return (Criteria) this;
        }

        public Criteria andLqflagIn(List<Integer> values) {
            addCriterion("lqflag in", values, "lqflag");
            return (Criteria) this;
        }

        public Criteria andLqflagNotIn(List<Integer> values) {
            addCriterion("lqflag not in", values, "lqflag");
            return (Criteria) this;
        }

        public Criteria andLqflagBetween(Integer value1, Integer value2) {
            addCriterion("lqflag between", value1, value2, "lqflag");
            return (Criteria) this;
        }

        public Criteria andLqflagNotBetween(Integer value1, Integer value2) {
            addCriterion("lqflag not between", value1, value2, "lqflag");
            return (Criteria) this;
        }

        public Criteria andJzflagIsNull() {
            addCriterion("jzflag is null");
            return (Criteria) this;
        }

        public Criteria andJzflagIsNotNull() {
            addCriterion("jzflag is not null");
            return (Criteria) this;
        }

        public Criteria andJzflagEqualTo(Integer value) {
            addCriterion("jzflag =", value, "jzflag");
            return (Criteria) this;
        }

        public Criteria andJzflagNotEqualTo(Integer value) {
            addCriterion("jzflag <>", value, "jzflag");
            return (Criteria) this;
        }

        public Criteria andJzflagGreaterThan(Integer value) {
            addCriterion("jzflag >", value, "jzflag");
            return (Criteria) this;
        }

        public Criteria andJzflagGreaterThanOrEqualTo(Integer value) {
            addCriterion("jzflag >=", value, "jzflag");
            return (Criteria) this;
        }

        public Criteria andJzflagLessThan(Integer value) {
            addCriterion("jzflag <", value, "jzflag");
            return (Criteria) this;
        }

        public Criteria andJzflagLessThanOrEqualTo(Integer value) {
            addCriterion("jzflag <=", value, "jzflag");
            return (Criteria) this;
        }

        public Criteria andJzflagIn(List<Integer> values) {
            addCriterion("jzflag in", values, "jzflag");
            return (Criteria) this;
        }

        public Criteria andJzflagNotIn(List<Integer> values) {
            addCriterion("jzflag not in", values, "jzflag");
            return (Criteria) this;
        }

        public Criteria andJzflagBetween(Integer value1, Integer value2) {
            addCriterion("jzflag between", value1, value2, "jzflag");
            return (Criteria) this;
        }

        public Criteria andJzflagNotBetween(Integer value1, Integer value2) {
            addCriterion("jzflag not between", value1, value2, "jzflag");
            return (Criteria) this;
        }

        public Criteria andReport1IsNull() {
            addCriterion("report1 is null");
            return (Criteria) this;
        }

        public Criteria andReport1IsNotNull() {
            addCriterion("report1 is not null");
            return (Criteria) this;
        }

        public Criteria andReport1EqualTo(Integer value) {
            addCriterion("report1 =", value, "report1");
            return (Criteria) this;
        }

        public Criteria andReport1NotEqualTo(Integer value) {
            addCriterion("report1 <>", value, "report1");
            return (Criteria) this;
        }

        public Criteria andReport1GreaterThan(Integer value) {
            addCriterion("report1 >", value, "report1");
            return (Criteria) this;
        }

        public Criteria andReport1GreaterThanOrEqualTo(Integer value) {
            addCriterion("report1 >=", value, "report1");
            return (Criteria) this;
        }

        public Criteria andReport1LessThan(Integer value) {
            addCriterion("report1 <", value, "report1");
            return (Criteria) this;
        }

        public Criteria andReport1LessThanOrEqualTo(Integer value) {
            addCriterion("report1 <=", value, "report1");
            return (Criteria) this;
        }

        public Criteria andReport1In(List<Integer> values) {
            addCriterion("report1 in", values, "report1");
            return (Criteria) this;
        }

        public Criteria andReport1NotIn(List<Integer> values) {
            addCriterion("report1 not in", values, "report1");
            return (Criteria) this;
        }

        public Criteria andReport1Between(Integer value1, Integer value2) {
            addCriterion("report1 between", value1, value2, "report1");
            return (Criteria) this;
        }

        public Criteria andReport1NotBetween(Integer value1, Integer value2) {
            addCriterion("report1 not between", value1, value2, "report1");
            return (Criteria) this;
        }

        public Criteria andReport2IsNull() {
            addCriterion("report2 is null");
            return (Criteria) this;
        }

        public Criteria andReport2IsNotNull() {
            addCriterion("report2 is not null");
            return (Criteria) this;
        }

        public Criteria andReport2EqualTo(Integer value) {
            addCriterion("report2 =", value, "report2");
            return (Criteria) this;
        }

        public Criteria andReport2NotEqualTo(Integer value) {
            addCriterion("report2 <>", value, "report2");
            return (Criteria) this;
        }

        public Criteria andReport2GreaterThan(Integer value) {
            addCriterion("report2 >", value, "report2");
            return (Criteria) this;
        }

        public Criteria andReport2GreaterThanOrEqualTo(Integer value) {
            addCriterion("report2 >=", value, "report2");
            return (Criteria) this;
        }

        public Criteria andReport2LessThan(Integer value) {
            addCriterion("report2 <", value, "report2");
            return (Criteria) this;
        }

        public Criteria andReport2LessThanOrEqualTo(Integer value) {
            addCriterion("report2 <=", value, "report2");
            return (Criteria) this;
        }

        public Criteria andReport2In(List<Integer> values) {
            addCriterion("report2 in", values, "report2");
            return (Criteria) this;
        }

        public Criteria andReport2NotIn(List<Integer> values) {
            addCriterion("report2 not in", values, "report2");
            return (Criteria) this;
        }

        public Criteria andReport2Between(Integer value1, Integer value2) {
            addCriterion("report2 between", value1, value2, "report2");
            return (Criteria) this;
        }

        public Criteria andReport2NotBetween(Integer value1, Integer value2) {
            addCriterion("report2 not between", value1, value2, "report2");
            return (Criteria) this;
        }

        public Criteria andUidFirstsbrIsNull() {
            addCriterion("uid_firstsbr is null");
            return (Criteria) this;
        }

        public Criteria andUidFirstsbrIsNotNull() {
            addCriterion("uid_firstsbr is not null");
            return (Criteria) this;
        }

        public Criteria andUidFirstsbrEqualTo(Long value) {
            addCriterion("uid_firstsbr =", value, "uidFirstsbr");
            return (Criteria) this;
        }

        public Criteria andUidFirstsbrNotEqualTo(Long value) {
            addCriterion("uid_firstsbr <>", value, "uidFirstsbr");
            return (Criteria) this;
        }

        public Criteria andUidFirstsbrGreaterThan(Long value) {
            addCriterion("uid_firstsbr >", value, "uidFirstsbr");
            return (Criteria) this;
        }

        public Criteria andUidFirstsbrGreaterThanOrEqualTo(Long value) {
            addCriterion("uid_firstsbr >=", value, "uidFirstsbr");
            return (Criteria) this;
        }

        public Criteria andUidFirstsbrLessThan(Long value) {
            addCriterion("uid_firstsbr <", value, "uidFirstsbr");
            return (Criteria) this;
        }

        public Criteria andUidFirstsbrLessThanOrEqualTo(Long value) {
            addCriterion("uid_firstsbr <=", value, "uidFirstsbr");
            return (Criteria) this;
        }

        public Criteria andUidFirstsbrIn(List<Long> values) {
            addCriterion("uid_firstsbr in", values, "uidFirstsbr");
            return (Criteria) this;
        }

        public Criteria andUidFirstsbrNotIn(List<Long> values) {
            addCriterion("uid_firstsbr not in", values, "uidFirstsbr");
            return (Criteria) this;
        }

        public Criteria andUidFirstsbrBetween(Long value1, Long value2) {
            addCriterion("uid_firstsbr between", value1, value2, "uidFirstsbr");
            return (Criteria) this;
        }

        public Criteria andUidFirstsbrNotBetween(Long value1, Long value2) {
            addCriterion("uid_firstsbr not between", value1, value2, "uidFirstsbr");
            return (Criteria) this;
        }

        public Criteria andFirstSbsjIsNull() {
            addCriterion("first_sbsj is null");
            return (Criteria) this;
        }

        public Criteria andFirstSbsjIsNotNull() {
            addCriterion("first_sbsj is not null");
            return (Criteria) this;
        }

        public Criteria andFirstSbsjEqualTo(Date value) {
            addCriterion("first_sbsj =", value, "firstSbsj");
            return (Criteria) this;
        }

        public Criteria andFirstSbsjNotEqualTo(Date value) {
            addCriterion("first_sbsj <>", value, "firstSbsj");
            return (Criteria) this;
        }

        public Criteria andFirstSbsjGreaterThan(Date value) {
            addCriterion("first_sbsj >", value, "firstSbsj");
            return (Criteria) this;
        }

        public Criteria andFirstSbsjGreaterThanOrEqualTo(Date value) {
            addCriterion("first_sbsj >=", value, "firstSbsj");
            return (Criteria) this;
        }

        public Criteria andFirstSbsjLessThan(Date value) {
            addCriterion("first_sbsj <", value, "firstSbsj");
            return (Criteria) this;
        }

        public Criteria andFirstSbsjLessThanOrEqualTo(Date value) {
            addCriterion("first_sbsj <=", value, "firstSbsj");
            return (Criteria) this;
        }

        public Criteria andFirstSbsjIn(List<Date> values) {
            addCriterion("first_sbsj in", values, "firstSbsj");
            return (Criteria) this;
        }

        public Criteria andFirstSbsjNotIn(List<Date> values) {
            addCriterion("first_sbsj not in", values, "firstSbsj");
            return (Criteria) this;
        }

        public Criteria andFirstSbsjBetween(Date value1, Date value2) {
            addCriterion("first_sbsj between", value1, value2, "firstSbsj");
            return (Criteria) this;
        }

        public Criteria andFirstSbsjNotBetween(Date value1, Date value2) {
            addCriterion("first_sbsj not between", value1, value2, "firstSbsj");
            return (Criteria) this;
        }

        public Criteria andUidSecondsbrIsNull() {
            addCriterion("uid_secondsbr is null");
            return (Criteria) this;
        }

        public Criteria andUidSecondsbrIsNotNull() {
            addCriterion("uid_secondsbr is not null");
            return (Criteria) this;
        }

        public Criteria andUidSecondsbrEqualTo(Long value) {
            addCriterion("uid_secondsbr =", value, "uidSecondsbr");
            return (Criteria) this;
        }

        public Criteria andUidSecondsbrNotEqualTo(Long value) {
            addCriterion("uid_secondsbr <>", value, "uidSecondsbr");
            return (Criteria) this;
        }

        public Criteria andUidSecondsbrGreaterThan(Long value) {
            addCriterion("uid_secondsbr >", value, "uidSecondsbr");
            return (Criteria) this;
        }

        public Criteria andUidSecondsbrGreaterThanOrEqualTo(Long value) {
            addCriterion("uid_secondsbr >=", value, "uidSecondsbr");
            return (Criteria) this;
        }

        public Criteria andUidSecondsbrLessThan(Long value) {
            addCriterion("uid_secondsbr <", value, "uidSecondsbr");
            return (Criteria) this;
        }

        public Criteria andUidSecondsbrLessThanOrEqualTo(Long value) {
            addCriterion("uid_secondsbr <=", value, "uidSecondsbr");
            return (Criteria) this;
        }

        public Criteria andUidSecondsbrIn(List<Long> values) {
            addCriterion("uid_secondsbr in", values, "uidSecondsbr");
            return (Criteria) this;
        }

        public Criteria andUidSecondsbrNotIn(List<Long> values) {
            addCriterion("uid_secondsbr not in", values, "uidSecondsbr");
            return (Criteria) this;
        }

        public Criteria andUidSecondsbrBetween(Long value1, Long value2) {
            addCriterion("uid_secondsbr between", value1, value2, "uidSecondsbr");
            return (Criteria) this;
        }

        public Criteria andUidSecondsbrNotBetween(Long value1, Long value2) {
            addCriterion("uid_secondsbr not between", value1, value2, "uidSecondsbr");
            return (Criteria) this;
        }

        public Criteria andSecondSbsjIsNull() {
            addCriterion("second_sbsj is null");
            return (Criteria) this;
        }

        public Criteria andSecondSbsjIsNotNull() {
            addCriterion("second_sbsj is not null");
            return (Criteria) this;
        }

        public Criteria andSecondSbsjEqualTo(Date value) {
            addCriterion("second_sbsj =", value, "secondSbsj");
            return (Criteria) this;
        }

        public Criteria andSecondSbsjNotEqualTo(Date value) {
            addCriterion("second_sbsj <>", value, "secondSbsj");
            return (Criteria) this;
        }

        public Criteria andSecondSbsjGreaterThan(Date value) {
            addCriterion("second_sbsj >", value, "secondSbsj");
            return (Criteria) this;
        }

        public Criteria andSecondSbsjGreaterThanOrEqualTo(Date value) {
            addCriterion("second_sbsj >=", value, "secondSbsj");
            return (Criteria) this;
        }

        public Criteria andSecondSbsjLessThan(Date value) {
            addCriterion("second_sbsj <", value, "secondSbsj");
            return (Criteria) this;
        }

        public Criteria andSecondSbsjLessThanOrEqualTo(Date value) {
            addCriterion("second_sbsj <=", value, "secondSbsj");
            return (Criteria) this;
        }

        public Criteria andSecondSbsjIn(List<Date> values) {
            addCriterion("second_sbsj in", values, "secondSbsj");
            return (Criteria) this;
        }

        public Criteria andSecondSbsjNotIn(List<Date> values) {
            addCriterion("second_sbsj not in", values, "secondSbsj");
            return (Criteria) this;
        }

        public Criteria andSecondSbsjBetween(Date value1, Date value2) {
            addCriterion("second_sbsj between", value1, value2, "secondSbsj");
            return (Criteria) this;
        }

        public Criteria andSecondSbsjNotBetween(Date value1, Date value2) {
            addCriterion("second_sbsj not between", value1, value2, "secondSbsj");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}