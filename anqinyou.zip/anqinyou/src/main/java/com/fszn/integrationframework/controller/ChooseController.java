package com.fszn.integrationframework.controller;

import com.fszn.integrationframework.domain.*;
import com.fszn.integrationframework.service.ChooseService;
import com.fszn.integrationframework.utils.JsonTool;
import com.fszn.integrationframework.utils.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.server.PathParam;

@Controller
@RequestMapping("choose")
@Slf4j
public class ChooseController {

    @Autowired
    ChooseService chooseService;
    @Autowired
    Result result;

    @RequestMapping("/primaryTomiddle")
    //进行选择选择功能模块  即报名类型 幼儿园报名
    @ResponseBody
    public Result primaryTomiddle(String area, String schoolname, String selecttypevalue, HttpServletRequest request, HttpServletResponse response) throws Exception {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";  //为报名类型  mdtype
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //判断mdtype  如果mdtype为小学标志--则进行Userroll选区信息的修改
        if(type.equals("02")){
            //进行修改数据库
            chooseService.choosearea(area,wid);
        }
        Cookie cookie1 = new Cookie("childsn", "1");   //存入token   并返回 方便下次调用
        cookie1.setPath("/");
        log.info("进入primaryTomiddle成功,皖氏通id" + wid);
        response.addCookie(cookie1);
        int childsn = 1;
        //进行选区数据的录入   type为选择的类型  即 幼儿园 或者  小学    小学为02  幼儿园为01
        //认证信息的录入
        result = chooseService.primaryTomiddle(type, wid, childsn, schoolname, selecttypevalue);

        return result;
    }

    @RequestMapping("/getChildsn")
    //返回目前所储存的孩子childsn
    @ResponseBody
    public Result getChildsn(HttpServletRequest request, HttpServletResponse response) throws Exception {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //获取wid  判断名下是否有已提交的孩子信息
        int size = chooseService.getChildsn(type,wid);
        result.setCode("200");
        result.setContent(size + 1);
        return result;
    }

    @RequestMapping("/getChildsn1")
    //返回目前所储存的孩子childsn   该方法返回所有孩子数量
    @ResponseBody
    public Result getChildsn1(HttpServletRequest request, HttpServletResponse response) throws Exception {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }

        }
        //获取wid  判断名下所有的学生不管提交还是没提交
        int size = chooseService.getChildsn1(type,wid);

        if (size + 1 == 2) {
            result.setCode("500");
            result.setMsg("你的报名名额已达上限，不能继续报名");
        } else {
            result.setCode("200");
            result.setContent(size + 1);
        }
        return result;
    }

    @RequestMapping("/getChildsn2")
    //返回目前所储存的孩子childsn   该方法返回已存在但是step属性尚未更新、即尚未提交的孩子
    @ResponseBody
    public Result getChildsn2(HttpServletRequest request, HttpServletResponse response) throws Exception {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //获取wid  判断名下所有的学生不管提交还是没提交
        int size = chooseService.getChildsn2(type,wid);
        result.setCode("200");
        result.setContent(size + 1);

        return result;
    }

    @RequestMapping("/choosearea")
    //进行选择选区
    @ResponseBody
    public Result choosearea(String type, HttpServletRequest request) throws Exception {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
                break;
            }

        }
        log.info("进入primaryTomiddle成功,皖氏通id" + wid);
        //进行选区数据的录入   type为选择的类型  即 区县市代码号   area表
        result = chooseService.choosearea(type+"", wid);
        return result;
    }

    @RequestMapping("/updatemrdtype")
    //进行认证资料的更新
    @ResponseBody
    public Result updatemrdtype(int mrdtype, HttpServletRequest request) throws Exception {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        log.info("进入updatemrdtype成功,皖氏通id" + wid);
        //进行选区数据的录入   type为选择的类型  即 区县市代码号   area表
        result = chooseService.updatemrdtype(mrdtype, wid, type);
        return result;
    }
    @RequestMapping("/checkfirst")
    ////修改个人信息、  手机号、所在区、
    //selectarea="+selectarea+"&phonenum="+phonenum+"&selectchild="+selectchild+"&flag="+fla
    @ResponseBody
    public Result checkfirst(String selectarea, String phonenum, HttpServletRequest request) throws Exception {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
                break;
            }

        }
        log.info("进入checkfirst成功,皖氏通id" + wid);
        //进行手机号、所在区、  user_roll数据表的修改操作
        UserRoll userRoll = new UserRoll();
        userRoll.setWid(wid);
        userRoll.setPhone(phonenum);
        userRoll.setAsn(Integer.parseInt(selectarea));
        result = chooseService.checkfirst(userRoll, wid);
        return result;
    }

    @RequestMapping("/submitfamily")
    //进行家属信息、监护人的信息填入
    @ResponseBody
    //参数更新  、fathername  monthername  分别代表监护人1  监护人2        username分别为监护人与学生的关系  逗号隔开  且
    public Result submitfamily(@PathParam("username") String username, @PathParam("username1") String username1, @PathParam("fathername") String fathername, @PathParam("fathericd") String fathericd, @PathParam("monthername") String monthername, @PathParam("monthericd") String monthericd, HttpServletRequest request) throws Exception {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }

        }
        Family family1 = new Family();//第一个监护人信息
        Family family2 = new Family();//第二个监护人信息
        log.info("familyMsg.html,皖氏通id" + wid);
        //进行家属信息、监护人的信息填入   相关数据表  family数据表
        family1.setRealname(fathername);//关系、姓名、icd
        family1.setId(fathericd);
        family1.setSwho(username);
        family2.setRealname(monthername);
        family2.setId(monthericd);
        family2.setSwho(username1);
        result = chooseService.submitfamily(family1, family2, wid,type);
        return result;
    }

    @RequestMapping("/submitxueji")
    //进行选择选区
    @ResponseBody
    public Result submitxueji(@PathParam("username") String username, @PathParam("icd") String icd, @PathParam("phone") String phone, @PathParam("selectchild") String selectchild, @PathParam("gettype") String gettype, HttpServletRequest request, HttpServletResponse response) throws Exception {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        int childsn = 1;
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("childsn")) { //通过获取cookie childsn  即 孩子标识码  进行操作
                childsn = Integer.parseInt(cook.getValue());
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        if (selectchild.equals("2")) {
            Cookie cookie1 = new Cookie("childsn", "2");   //存入token   并返回 方便下次调用
            childsn=2;
            cookie1.setPath("/");
            log.info("进入primaryTomiddle成功,皖氏通id" + wid);
            response.addCookie(cookie1);
        }
        log.info("进入submitxueji成功,皖氏通id" + wid);
        //将表单信息存入数据库
        Student student = new Student();
        student.setId(icd);
        student.setRealname(username);
        //往userroll插入单孩、多孩信息（额外补充）
        if(type.equals("02")){
            chooseService.notAddIsyh(phone,wid);
        }else{
            chooseService.addIsyh(phone, selectchild, gettype, wid);
        }
        result = chooseService.submitxueji(student, wid, childsn,type);
        return result;
    }

    @RequestMapping("/submitxuejiDuo")
    //进行选择选区----------------------------------------多孩的导入
    @ResponseBody
    public Result submitxuejiDuo(@PathParam("username") String username, @PathParam("icd") String icd, @PathParam("phone") String phone, @PathParam("selectchild") String selectchild, @PathParam("gettype") String gettype, @PathParam("username1") String username1, @PathParam("icd1") String icd1, HttpServletRequest request, HttpServletResponse response) throws Exception {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        int childsn = 1;
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        if (selectchild.equals("2")) {
            if (gettype == "true") {//多孩分开摇号
                Cookie cookie1 = new Cookie("childsn", 4 + "");
                childsn=4;
                cookie1.setPath("/");
                response.addCookie(cookie1);
            } else {//多孩整体
                Cookie cookie1 = new Cookie("childsn", 3 + "");
                childsn=3;
                cookie1.setPath("/");
                response.addCookie(cookie1);
            }
        }

        //通过判断多孩的摇号类型  进行给childsn分配不同的值   3代表摇号不分开   4代表摇号分开
        log.info("进入submitxueji成功,皖氏通id" + wid);
        //将表单信息存入数据库
     /*   Xueji xueji = new Xueji();  //学籍
        xueji.setXjhrPhone(phone);*/
        Student student = new Student();
        student.setId(icd);
        student.setRealname(username);
        Student student1 = new Student();
        student1.setId(icd1);
        student1.setRealname(username1);
        //往userroll插入单孩、多孩信息（额外补充）
        //进行判断type  区分报名类型 如果为小学的则不进行修改单孩、多孩标志-----整体摇号、单体摇号
        if(type.equals("02")){
            chooseService.notAddIsyh(phone,wid);
        }else{
            chooseService.addIsyh(phone, selectchild, gettype, wid);
        }

        //同时插入2条学生信息 且与之对应的是一条报名记录
        result = chooseService.submitxuejiDuo(student, student1, wid, childsn, gettype,type);

        return result;
    }

    @RequestMapping("/submitHouseMsg")
    //进行房产信息的录入   通过HouseMsg进行捕获form提交的表单
    @ResponseBody
    public Result submitHouseMsg(@RequestBody String data, HttpServletRequest request) throws Exception {

        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //将获取的Json字符串转成对象
        HouseMsg houseMsg = JsonTool.parseJsonWithGson(data, HouseMsg.class);
        log.info(houseMsg.toString());
        //将表单信息存入数据库
        result = chooseService.submitHouseMsg(houseMsg, wid,type);
        return result;
    }

  /*  @RequestMapping("/submitSecMsg")
    //进行认证信息的录入   通过SecMsg进行捕获form提交的表单
    @ResponseBody
    public Result submitSecMsg(@RequestBody String data, HttpServletRequest request) throws Exception {

        Cookie[] cookie = request.getCookies();
        String wid = "";
        int childsn = 1;
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("childsn")) { //通过获取cookie childsn  即 孩子标识码  进行操作
                childsn = Integer.parseInt(cook.getValue());
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //将获取的Json字符串转成对象
        SecImg secImg = JsonTool.parseJsonWithGson(data, SecImg.class);
        log.info(secImg.toString());
        //将表单信息存入数据库
        result = chooseService.submitSecMsg(secImg, wid, childsn,type);
        return result;
    }*/

/*    @RequestMapping("/temporarySecMsg")
    //进行认证信息的录入   通过SecMsg进行捕获form提交的表单
    @ResponseBody
    public Result temporarySecMsg(@RequestBody String data, HttpServletRequest request) throws Exception {

        Cookie[] cookie = request.getCookies();
        String wid = "";
        int childsn = 1;
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("childsn")) { //通过获取cookie childsn  即 孩子标识码  进行操作
                childsn = Integer.parseInt(cook.getValue());
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //将获取的Json字符串转成对象
        SecImg secImg = JsonTool.parseJsonWithGson(data, SecImg.class);
        log.info(secImg.toString());
        //将表单信息存入数据库
        result = chooseService.temporarySecMsg(secImg, wid, childsn,type);
        return result;
    }*/

 /*   @RequestMapping("/delete")
    //删除测试数据
    @ResponseBody
    public Result delete(HttpServletRequest request) throws Exception {
        result = chooseService.delete();
        return result;
    }*/

    @RequestMapping("/deleteByEsn")
    //删除尚未提交的报名信息
    @ResponseBody
    public Result deleteByEsn(HttpServletRequest request) throws Exception {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        result = chooseService.deleteByEsn(wid,type);
        return result;
    }

    @RequestMapping("/updateMdtype")
    //修改报名类型的cookie、或添加该cookie  以便后续进行判断
    @ResponseBody
    public Result updateMdtype(String mdtype, HttpServletRequest request, HttpServletResponse response) throws Exception {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        Cookie cookie1 = new Cookie("mdtype", mdtype);
        cookie1.setPath("/");
        response.addCookie(cookie1);
        //根据所存的报名类型进行cookie的修改----如果没有记录则存1  有记录取出相应的childsn
        int count=chooseService.getErollChildsn(wid,type);
        Cookie cookie2 = new Cookie("childsn", count+"");
        cookie2.setPath("/");
        response.addCookie(cookie2);
        result.setCode("200");
        return result;
    }
    @RequestMapping("/submitHouseMsgMdtype1")
    //进行房产信息的录入   通过HouseMsg进行捕获form提交的表单   -------------双一致类型--能提供房产原件类型
    @ResponseBody
    public Result submitHouseMsgMdtype1(@RequestBody String data, HttpServletRequest request) throws Exception {

        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //将获取的Json字符串转成对象
        MiddleHouseMsg1 houseMsg = JsonTool.parseJsonWithGson(data, MiddleHouseMsg1.class);
        log.info(houseMsg.toString());
        //将表单信息存入数据库
        result = chooseService.submitHouseMsgMdtype1(houseMsg, wid,type);
        return result;
    }
    @RequestMapping("/submitHouseMsgNonMdtype1")
    //进行房产信息的录入   通过HouseMsg进行捕获form提交的表单   -------------独立房产类型--不能提供房产原件类型
    @ResponseBody
    public Result submitHouseMsgNonMdtype1(@RequestBody String data, HttpServletRequest request,HttpServletResponse response) throws Exception {

        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //将获取的Json字符串转成对象
        MiddleHouseMsgNon1 houseMsg = JsonTool.parseJsonWithGson(data, MiddleHouseMsgNon1.class);
        //进行认证资格的修改
        chooseService.updatemrdtype(8,wid,type);
        Cookie cookie1 = new Cookie("mrdtype", "8");   //存入token   并返回 方便下次调用
        cookie1.setPath("/");
        log.info("进入primaryTomiddle成功,皖氏通id" + wid);
        response.addCookie(cookie1);
        log.info(houseMsg.toString());
        //将表单信息存入数据库
        result = chooseService.submitHouseMsgNonMdtype1(houseMsg, wid,type);
        return result;
    }
    @RequestMapping("/submitHouseMsgMdtype2")
    //进行房产信息的录入   通过HouseMsg进行捕获form提交的表单   -------------独立房产
    @ResponseBody
    public Result submitHouseMsgMdtype2(@RequestBody String data, HttpServletRequest request) throws Exception {

        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //将获取的Json字符串转成对象
        MiddleHouseMsg2 houseMsg = JsonTool.parseJsonWithGson(data, MiddleHouseMsg2.class);
        log.info(houseMsg.toString());
        //将表单信息存入数据库
        result = chooseService.submitHouseMsgMdtype2(houseMsg, wid,type);
        return result;
    }
    @RequestMapping("/submitHouseMsgMdtype3")
    //进行房产信息的录入   通过HouseMsg进行捕获form提交的表单   -------------爷孙户
    @ResponseBody
    public Result submitHouseMsgMdtype3(@RequestBody String data, HttpServletRequest request) throws Exception {

        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //将获取的Json字符串转成对象
        MiddleHouseMsg3 houseMsg = JsonTool.parseJsonWithGson(data, MiddleHouseMsg3.class);
        log.info(houseMsg.toString());
        //将表单信息存入数据库
        result = chooseService.submitHouseMsgMdtype3(houseMsg, wid,type);
        return result;
    }
    @RequestMapping("/submitHouseMsgMdtype4")
    //进行房产信息的录入   通过HouseMsg进行捕获form提交的表单   -------------公租房
    @ResponseBody
    public Result submitHouseMsgMdtype4(@RequestBody String data, HttpServletRequest request) throws Exception {

        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //将获取的Json字符串转成对象
        MiddleHouseMsg4 houseMsg = JsonTool.parseJsonWithGson(data, MiddleHouseMsg4.class);
        log.info(houseMsg.toString());
        //将表单信息存入数据库
        result = chooseService.submitHouseMsgMdtype4(houseMsg, wid,type);
        return result;
    }
    @RequestMapping("/submitHouseMsgYSH")
    //进行房产信息的录入   通过HouseMsg进行捕获form提交的表单   -------------幼儿园阶段的爷孙户信息填报
    @ResponseBody
    public Result submitHouseMsgYSH(@RequestBody String data, HttpServletRequest request) throws Exception {

        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //将获取的Json字符串转成对象
        HouseMsgYSH houseMsg = JsonTool.parseJsonWithGson(data, HouseMsgYSH.class);
        log.info(houseMsg.toString());
        //将表单信息存入数据库
        result = chooseService.submitHouseMsgYSH(houseMsg, wid,type);
        return result;
    }
    @RequestMapping("/submitShuangXuan")
    //进行双选学校的信息录入 和状态确认
    @ResponseBody
    public Result submitShuangXuan( String schoolname, HttpServletRequest request) throws Exception {

        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }

        //将双选学校录入进数据库--并修改报名表的确认报名状态
        result = chooseService.submitShuangXuan(schoolname, wid,type);
        return result;
    }



}
