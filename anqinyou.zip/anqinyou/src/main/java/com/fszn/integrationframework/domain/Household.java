package com.fszn.integrationframework.domain;

import java.util.Date;

public class Household {
    private Long rsn;

    private Long esn;

    private String realname;

    private String id;

    private Date rdt;

    private String address;

    public Long getRsn() {
        return rsn;
    }

    public void setRsn(Long rsn) {
        this.rsn = rsn;
    }

    public Long getEsn() {
        return esn;
    }

    public void setEsn(Long esn) {
        this.esn = esn;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname == null ? null : realname.trim();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public Date getRdt() {
        return rdt;
    }

    public void setRdt(Date rdt) {
        this.rdt = rdt;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }
}