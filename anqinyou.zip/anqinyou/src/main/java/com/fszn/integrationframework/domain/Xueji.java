package com.fszn.integrationframework.domain;

public class Xueji {
    private Integer xsn;

    private Long sn;

    private String xarea;

    private String xschool;

    private String gradeclass;

    private String xno;

    private String xjhrPhone;

    public Integer getXsn() {
        return xsn;
    }

    public void setXsn(Integer xsn) {
        this.xsn = xsn;
    }

    public Long getSn() {
        return sn;
    }

    public void setSn(Long sn) {
        this.sn = sn;
    }

    public String getXarea() {
        return xarea;
    }

    public void setXarea(String xarea) {
        this.xarea = xarea == null ? null : xarea.trim();
    }

    public String getXschool() {
        return xschool;
    }

    public void setXschool(String xschool) {
        this.xschool = xschool == null ? null : xschool.trim();
    }

    public String getGradeclass() {
        return gradeclass;
    }

    public void setGradeclass(String gradeclass) {
        this.gradeclass = gradeclass == null ? null : gradeclass.trim();
    }

    public String getXno() {
        return xno;
    }

    public void setXno(String xno) {
        this.xno = xno == null ? null : xno.trim();
    }

    public String getXjhrPhone() {
        return xjhrPhone;
    }

    public void setXjhrPhone(String xjhrPhone) {
        this.xjhrPhone = xjhrPhone == null ? null : xjhrPhone.trim();
    }
}