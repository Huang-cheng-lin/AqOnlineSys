package com.fszn.integrationframework.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TimecontrolExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public TimecontrolExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andSnIsNull() {
            addCriterion("sn is null");
            return (Criteria) this;
        }

        public Criteria andSnIsNotNull() {
            addCriterion("sn is not null");
            return (Criteria) this;
        }

        public Criteria andSnEqualTo(Integer value) {
            addCriterion("sn =", value, "sn");
            return (Criteria) this;
        }

        public Criteria andSnNotEqualTo(Integer value) {
            addCriterion("sn <>", value, "sn");
            return (Criteria) this;
        }

        public Criteria andSnGreaterThan(Integer value) {
            addCriterion("sn >", value, "sn");
            return (Criteria) this;
        }

        public Criteria andSnGreaterThanOrEqualTo(Integer value) {
            addCriterion("sn >=", value, "sn");
            return (Criteria) this;
        }

        public Criteria andSnLessThan(Integer value) {
            addCriterion("sn <", value, "sn");
            return (Criteria) this;
        }

        public Criteria andSnLessThanOrEqualTo(Integer value) {
            addCriterion("sn <=", value, "sn");
            return (Criteria) this;
        }

        public Criteria andSnIn(List<Integer> values) {
            addCriterion("sn in", values, "sn");
            return (Criteria) this;
        }

        public Criteria andSnNotIn(List<Integer> values) {
            addCriterion("sn not in", values, "sn");
            return (Criteria) this;
        }

        public Criteria andSnBetween(Integer value1, Integer value2) {
            addCriterion("sn between", value1, value2, "sn");
            return (Criteria) this;
        }

        public Criteria andSnNotBetween(Integer value1, Integer value2) {
            addCriterion("sn not between", value1, value2, "sn");
            return (Criteria) this;
        }

        public Criteria andBcodeIsNull() {
            addCriterion("bcode is null");
            return (Criteria) this;
        }

        public Criteria andBcodeIsNotNull() {
            addCriterion("bcode is not null");
            return (Criteria) this;
        }

        public Criteria andBcodeEqualTo(String value) {
            addCriterion("bcode =", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeNotEqualTo(String value) {
            addCriterion("bcode <>", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeGreaterThan(String value) {
            addCriterion("bcode >", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeGreaterThanOrEqualTo(String value) {
            addCriterion("bcode >=", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeLessThan(String value) {
            addCriterion("bcode <", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeLessThanOrEqualTo(String value) {
            addCriterion("bcode <=", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeLike(String value) {
            addCriterion("bcode like", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeNotLike(String value) {
            addCriterion("bcode not like", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeIn(List<String> values) {
            addCriterion("bcode in", values, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeNotIn(List<String> values) {
            addCriterion("bcode not in", values, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeBetween(String value1, String value2) {
            addCriterion("bcode between", value1, value2, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeNotBetween(String value1, String value2) {
            addCriterion("bcode not between", value1, value2, "bcode");
            return (Criteria) this;
        }

        public Criteria andTimeclassIsNull() {
            addCriterion("timeclass is null");
            return (Criteria) this;
        }

        public Criteria andTimeclassIsNotNull() {
            addCriterion("timeclass is not null");
            return (Criteria) this;
        }

        public Criteria andTimeclassEqualTo(String value) {
            addCriterion("timeclass =", value, "timeclass");
            return (Criteria) this;
        }

        public Criteria andTimeclassNotEqualTo(String value) {
            addCriterion("timeclass <>", value, "timeclass");
            return (Criteria) this;
        }

        public Criteria andTimeclassGreaterThan(String value) {
            addCriterion("timeclass >", value, "timeclass");
            return (Criteria) this;
        }

        public Criteria andTimeclassGreaterThanOrEqualTo(String value) {
            addCriterion("timeclass >=", value, "timeclass");
            return (Criteria) this;
        }

        public Criteria andTimeclassLessThan(String value) {
            addCriterion("timeclass <", value, "timeclass");
            return (Criteria) this;
        }

        public Criteria andTimeclassLessThanOrEqualTo(String value) {
            addCriterion("timeclass <=", value, "timeclass");
            return (Criteria) this;
        }

        public Criteria andTimeclassLike(String value) {
            addCriterion("timeclass like", value, "timeclass");
            return (Criteria) this;
        }

        public Criteria andTimeclassNotLike(String value) {
            addCriterion("timeclass not like", value, "timeclass");
            return (Criteria) this;
        }

        public Criteria andTimeclassIn(List<String> values) {
            addCriterion("timeclass in", values, "timeclass");
            return (Criteria) this;
        }

        public Criteria andTimeclassNotIn(List<String> values) {
            addCriterion("timeclass not in", values, "timeclass");
            return (Criteria) this;
        }

        public Criteria andTimeclassBetween(String value1, String value2) {
            addCriterion("timeclass between", value1, value2, "timeclass");
            return (Criteria) this;
        }

        public Criteria andTimeclassNotBetween(String value1, String value2) {
            addCriterion("timeclass not between", value1, value2, "timeclass");
            return (Criteria) this;
        }

        public Criteria andBtimeIsNull() {
            addCriterion("btime is null");
            return (Criteria) this;
        }

        public Criteria andBtimeIsNotNull() {
            addCriterion("btime is not null");
            return (Criteria) this;
        }

        public Criteria andBtimeEqualTo(Date value) {
            addCriterion("btime =", value, "btime");
            return (Criteria) this;
        }

        public Criteria andBtimeNotEqualTo(Date value) {
            addCriterion("btime <>", value, "btime");
            return (Criteria) this;
        }

        public Criteria andBtimeGreaterThan(Date value) {
            addCriterion("btime >", value, "btime");
            return (Criteria) this;
        }

        public Criteria andBtimeGreaterThanOrEqualTo(Date value) {
            addCriterion("btime >=", value, "btime");
            return (Criteria) this;
        }

        public Criteria andBtimeLessThan(Date value) {
            addCriterion("btime <", value, "btime");
            return (Criteria) this;
        }

        public Criteria andBtimeLessThanOrEqualTo(Date value) {
            addCriterion("btime <=", value, "btime");
            return (Criteria) this;
        }

        public Criteria andBtimeIn(List<Date> values) {
            addCriterion("btime in", values, "btime");
            return (Criteria) this;
        }

        public Criteria andBtimeNotIn(List<Date> values) {
            addCriterion("btime not in", values, "btime");
            return (Criteria) this;
        }

        public Criteria andBtimeBetween(Date value1, Date value2) {
            addCriterion("btime between", value1, value2, "btime");
            return (Criteria) this;
        }

        public Criteria andBtimeNotBetween(Date value1, Date value2) {
            addCriterion("btime not between", value1, value2, "btime");
            return (Criteria) this;
        }

        public Criteria andEtimeIsNull() {
            addCriterion("etime is null");
            return (Criteria) this;
        }

        public Criteria andEtimeIsNotNull() {
            addCriterion("etime is not null");
            return (Criteria) this;
        }

        public Criteria andEtimeEqualTo(Date value) {
            addCriterion("etime =", value, "etime");
            return (Criteria) this;
        }

        public Criteria andEtimeNotEqualTo(Date value) {
            addCriterion("etime <>", value, "etime");
            return (Criteria) this;
        }

        public Criteria andEtimeGreaterThan(Date value) {
            addCriterion("etime >", value, "etime");
            return (Criteria) this;
        }

        public Criteria andEtimeGreaterThanOrEqualTo(Date value) {
            addCriterion("etime >=", value, "etime");
            return (Criteria) this;
        }

        public Criteria andEtimeLessThan(Date value) {
            addCriterion("etime <", value, "etime");
            return (Criteria) this;
        }

        public Criteria andEtimeLessThanOrEqualTo(Date value) {
            addCriterion("etime <=", value, "etime");
            return (Criteria) this;
        }

        public Criteria andEtimeIn(List<Date> values) {
            addCriterion("etime in", values, "etime");
            return (Criteria) this;
        }

        public Criteria andEtimeNotIn(List<Date> values) {
            addCriterion("etime not in", values, "etime");
            return (Criteria) this;
        }

        public Criteria andEtimeBetween(Date value1, Date value2) {
            addCriterion("etime between", value1, value2, "etime");
            return (Criteria) this;
        }

        public Criteria andEtimeNotBetween(Date value1, Date value2) {
            addCriterion("etime not between", value1, value2, "etime");
            return (Criteria) this;
        }

        public Criteria andSyearIsNull() {
            addCriterion("syear is null");
            return (Criteria) this;
        }

        public Criteria andSyearIsNotNull() {
            addCriterion("syear is not null");
            return (Criteria) this;
        }

        public Criteria andSyearEqualTo(Integer value) {
            addCriterion("syear =", value, "syear");
            return (Criteria) this;
        }

        public Criteria andSyearNotEqualTo(Integer value) {
            addCriterion("syear <>", value, "syear");
            return (Criteria) this;
        }

        public Criteria andSyearGreaterThan(Integer value) {
            addCriterion("syear >", value, "syear");
            return (Criteria) this;
        }

        public Criteria andSyearGreaterThanOrEqualTo(Integer value) {
            addCriterion("syear >=", value, "syear");
            return (Criteria) this;
        }

        public Criteria andSyearLessThan(Integer value) {
            addCriterion("syear <", value, "syear");
            return (Criteria) this;
        }

        public Criteria andSyearLessThanOrEqualTo(Integer value) {
            addCriterion("syear <=", value, "syear");
            return (Criteria) this;
        }

        public Criteria andSyearIn(List<Integer> values) {
            addCriterion("syear in", values, "syear");
            return (Criteria) this;
        }

        public Criteria andSyearNotIn(List<Integer> values) {
            addCriterion("syear not in", values, "syear");
            return (Criteria) this;
        }

        public Criteria andSyearBetween(Integer value1, Integer value2) {
            addCriterion("syear between", value1, value2, "syear");
            return (Criteria) this;
        }

        public Criteria andSyearNotBetween(Integer value1, Integer value2) {
            addCriterion("syear not between", value1, value2, "syear");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}