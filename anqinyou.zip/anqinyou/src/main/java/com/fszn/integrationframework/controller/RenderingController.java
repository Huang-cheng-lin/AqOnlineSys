package com.fszn.integrationframework.controller;

import com.fszn.integrationframework.service.RenderingService;
import com.fszn.integrationframework.utils.HttpUtils;
import com.fszn.integrationframework.utils.HttpUtilsGetToken;
import com.fszn.integrationframework.utils.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Controller
@Slf4j
@RequestMapping("rendering")
public class RenderingController {  //该类均为页面渲染
    @Autowired
    private RenderingService renderingService;
    @Autowired
    private Result result;

    @RequestMapping("/index")
    @ResponseBody//index页面渲染
    public Result index(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        result = renderingService.index();
        return result;
    }

    @RequestMapping("/primaryTomiddle")  //该页面已被checkfirst页面  目前被使用在checkfirst的页面渲染当中 -----选区下拉框渲染
    @ResponseBody//primaryTomiddle页面渲染
    public Result primaryTomiddle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        result = renderingService.primaryTomiddle();
        return result;
    }

    @RequestMapping("/submitMsg")
    @ResponseBody//submitMsg页面渲染
    public Result submitMsg(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        result = renderingService.submitMsg(wid, type);
        return result;
    }

    @RequestMapping("/updateSubMsg")
    @ResponseBody//updateKindMsg页面渲染
    public Result updateSubMsg(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        result = renderingService.updateSubMsg(wid, type);
        return result;
    }

    @RequestMapping("/getStep")
    @ResponseBody//submitMsg页面中的进度查询模态框数据渲染
    //通过esn从enroll表中直接获取step数据
    public Result getStep(String esn, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        result = renderingService.getStep(Long.valueOf(esn));
        return result;
    }

    @RequestMapping("/updateCookie")
    @ResponseBody//更改当前cookie
    public Result updateCookie(String childsn, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Cookie cookie = new Cookie("childsn", childsn);
            cookie.setPath("/");
            response.addCookie(cookie);
            result.setCode("200");
        } catch (Exception e) {
            result.setCode("500");
        }
        return result;
    }

    @RequestMapping("/getSchoolName")
    @ResponseBody//index页面中的学校下拉框数据渲染
    //目前分为2种  1、幼儿园全部、2小学学校分区推送
    //判断bcode字段区分2种类型。。。
    //通过家长的asn进行锁定学校名称
    public Result getSchoolName(String bcode, Integer asn, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }

        }
        result = renderingService.getSchoolName(bcode, wid, asn);
        return result;
    }
    @RequestMapping("/getSchoolNamePrimary")
    @ResponseBody//index页面中的学校下拉框数据渲染
    //目前分为2种  1、幼儿园全部、2小学学校分区推送
    //判断bcode字段区分2种类型。。。
    //通过家长的asn进行锁定学校名称
    public Result getSchoolNamePrimary(String bcode, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }

        }
        result = renderingService.getSchoolNamePrimary(bcode, wid);
        return result;
    }

    //student数据回调
    @RequestMapping("/returnStuMsg")
    @ResponseBody//student页面中的数据渲染
    public Result returnStuMsg(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        result = renderingService.returnStuMsg(wid, type);
        return result;
    }

    //family数据回调
    @RequestMapping("/returnFamilyMsg")
    @ResponseBody//family页面中的数据渲染
    public Result returnFamilyMsg(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        result = renderingService.returnFamilyMsg(wid, type);
        return result;
    }

    //HouseMsg数据回调
    @RequestMapping("/returnHouseMsg")
    @ResponseBody//HouseMsg页面中的数据渲染
    public Result returnHouseMsg(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        result = renderingService.returnHouseMsg(wid, type);
        return result;
    }

    //MiddleHouseMsg数据回调
    @RequestMapping("/returnMiddleHouseMsg")
    @ResponseBody//HouseMsg页面中的数据渲染
    public Result returnMiddleHouseMsg(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        result = renderingService.returnMiddleHouseMsg(wid, type);
        return result;
    }

    /*//SecMsg数据回调
    @RequestMapping("/returnSecMsg")
    @ResponseBody//HouseMsg页面中的数据渲染
    public Result returnSecMsg(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        int childsn=1;
        String type="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("childsn")) { //通过获取cookie childsn  即 孩子标识码  进行操作
                childsn = Integer.parseInt(cook.getValue());
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        result=renderingService.returnSecMsg(wid,childsn,type);
        return result;
    }*/
    //Adult数据回调
    @RequestMapping("/returnAdult")
    @ResponseBody//returnAdult页面中的数据渲染
    public Result returnAdult(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        result = renderingService.returnAdult(wid, type);
        return result;
    }

    //updateAdult修改操作
    @RequestMapping("/updateAdult")
    @ResponseBody
    public Result updateAdult(String phone, Integer selectid, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        int childsn = 1;
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("childsn")) { //通过获取cookie childsn  即 孩子标识码  进行操作
                childsn = Integer.parseInt(cook.getValue());
            }
        }
        result = renderingService.updateAdult(phone, selectid, wid, childsn);
        return result;
    }

    //预选学校返回
    @RequestMapping("/returnSchool")
    @ResponseBody
    public Result returnSchool(String phone, Integer selectid, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        result = renderingService.returnSchool(wid, type);
        return result;
    }

    //确认提交
    @RequestMapping("/sureUpdate")
    @ResponseBody
    public Result sureUpdate(String phone, Integer selectid, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }

            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        result = renderingService.sureUpdate(wid, type);
        return result;
    }

    /*    //监护人信息返回
        @RequestMapping("/returnFamily")
        @ResponseBody
        public Result returnFamily(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            Cookie[] cookie = request.getCookies();
            String wid = "";
            int childsn=1;
            String type="";
            for (int i = 0; i < cookie.length; i++) {
                Cookie cook = cookie[i];
                if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                    wid = cook.getValue();
                }
                if (cook.getName().equals("childsn")) { //通过获取cookie childsn  即 孩子标识码  进行操作
                    childsn = Integer.parseInt(cook.getValue());
                }
                if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                    type = cook.getValue();
                }
            }
            result=renderingService.returnFamily(wid,type);
            return result;
        }*/
    //检查该报名是否已存在-----修改阶段允许身份证重复 、但已提交的报名记录不允许重复
    @RequestMapping("/checkStuMsg")
    @ResponseBody
    public Result checkStuMsg(String id, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        result = renderingService.checkStuMsg(id);
        return result;
    }
    //检查该报名是否已存在---报名阶段不允许身份证重复
    @RequestMapping("/checkStuMsgByBaoMing")
    @ResponseBody
    public Result checkStuMsgByBaoMing(String id, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        result = renderingService.checkStuMsgByBaoMing(id);
        return result;
    }

    //返回认证资格
    @RequestMapping("/returnRenZhen")
    @ResponseBody
    public Result returnRenZhen(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        result = renderingService.returnRenZhen(wid, type);
        return result;
    }

    //返回户籍查询信息
    @RequestMapping("/returnHuJi")
    @ResponseBody
    public Result returnHuJi(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //进行家长信息的回显    家长数据的回显和比对   如果后续提交和查询API不同时标记异常状态
        //查询API失败时则直接标记异常状态
        result = renderingService.returnHuJi(wid, type);
        return result;
    }

    //返回产权查询信息
    @RequestMapping("/returnChanQuan")
    @ResponseBody
    public Result returnChanQuan(String number, String icd, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //查询产权信息 返回并录入数据库
        result = renderingService.returnChanQuan(wid, number, icd, type);
        return result;
    }

    //返回产权查询信息----特例情况  爷孙户
    @RequestMapping("/returnChanQuanYSH")
    @ResponseBody
    public Result returnChanQuanYSH(String number, String icd, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";

        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //查询产权信息 返回并录入数据库
        result = renderingService.returnChanQuanYSH(wid, number, icd, type);
        return result;
    }

    //更新学校选择
    @RequestMapping("/changeSchool")
    @ResponseBody
    public Result changeSchool(String schoolname, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //查询产权信息 返回并录入数据库
        result = renderingService.changeSchool(wid, schoolname, type);
        return result;
    }

    //小学页面、页面渲染返回
    @RequestMapping("/returnMiddleAdult")
    @ResponseBody
    public Result returnMiddleAdult(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //查询产权信息 返回并录入数据库
        result = renderingService.returnMiddleAdult(wid, type);
        return result;
    }

    //小学学校的报名确认提交
    @RequestMapping("/middleSureUpdate")
    @ResponseBody
    public Result middleSureUpdate(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //查询产权信息 返回并录入数据库
        result = renderingService.middleSureUpdate(wid, type);

        return result;
    }

    //家长信息确认--页面回调/返回预审结果是否通过 如不通过跳转至修改页面进行修改
    @RequestMapping("/familySureMessageReturn")
    @ResponseBody
    public Result familySureMessageReturn(Integer sn, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //查询产权信息 返回并录入数据库
        result = renderingService.familySureMessageReturn(sn, wid, type);
        return result;
    }

    //二次修改时间返回
    @RequestMapping("/returnTime")
    @ResponseBody
    public Result returnTime(Integer sn, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //查询产权信息 返回并录入数据库
        result = renderingService.returnTime(sn, wid, type);
        return result;
    }

    //二次修改时间返回
    @RequestMapping("/returnMiddleSchoolName")
    @ResponseBody
    public Result returnMiddleSchoolName(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //查询产权信息 返回并录入数据库
        result = renderingService.returnMiddleSchoolName(wid, type);
        return result;
    }
    @RequestMapping("/returnFamilyYSH")
    @ResponseBody
    public Result returnFamilyYSH(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //查询产权信息 返回并录入数据库
        result = renderingService.returnFamilyYSH(wid, type);
        return result;
    }
    @RequestMapping("/returnMiddleAreaAndMdtype")
    @ResponseBody
    public Result returnMiddleAreaAndMdtype(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie[] cookie = request.getCookies();
        String wid = "";
        String type = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().equals("wid")) { //通过获取cookie wid  即 皖氏通id  进行操作
                wid = cook.getValue();
            }
            if (cook.getName().equals("mdtype")) { //通过获取cookie mdtype  即 报名类型  进行操作
                type = cook.getValue();
            }
        }
        //查询产权信息 返回并录入数据库
        result = renderingService.returnMiddleAreaAndMdtype(wid, type);
        return result;
    }

}
