package com.fszn.integrationframework.utils;

import org.springframework.stereotype.Component;

@Component
public class Result {

    private Object content;
    private String code;
    private String msg;

    public Object getContent() {
        return content;
    }

    public void setContent(Object content) {
        this.content = content;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    @Override
    public String toString() {
        return "Result{" +
                "content=" + content +
                ", code='" + code + '\'' +
                ", msg='" + msg + '\'' +
                '}';
    }
}
