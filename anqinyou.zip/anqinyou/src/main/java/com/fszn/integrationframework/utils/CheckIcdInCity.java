package com.fszn.integrationframework.utils;

public class CheckIcdInCity {
    //通过API获取是否是城区户籍
    public static final String[] array={"安徽省安庆市市辖区","安徽省安庆市迎江区","安徽省安庆市宜秀区","安徽省安庆市大观区"};
    public static boolean returnCity(String qu1,String qu2){
        Boolean flag1=false;
        //判断单个小孩  或2个小孩的身份证区县代码符合本地户籍验证
/**
 安徽省安庆市市辖区
 安徽省安庆市迎江区
 安徽省安庆市宜秀区
 安徽省安庆市大观区
 安徽省安庆地区
 安徽省桐城县
 安徽省枞阳县
 安徽省宿松县
 安徽省岳西县
 安徽省太湖县
 安徽省安庆市
 安徽省怀宁县
 安徽省望江县
 安徽省潜山县
 安徽省桐城市
 * */

        if(qu2==null){  //单孩情况
                for(int  i=0;i<array.length;i++){
                    if(array[i].equals(qu1)){
                        flag1= true;
                    }
                }
        }else{//多孩情况
                boolean flag=false;
                for(int  i=0;i<array.length;i++){
                    if(array[i].equals(qu1)){
                        flag=true;
                    }
                }
                if(flag){
                    for(int  i=0;i<array.length;i++){
                        if(array[i].equals(qu2)){
                            flag1= true;
                        }
                    }
                }
            }


        return flag1;
    }
}
