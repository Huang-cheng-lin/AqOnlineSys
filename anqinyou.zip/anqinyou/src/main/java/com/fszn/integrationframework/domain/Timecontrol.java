package com.fszn.integrationframework.domain;

import java.util.Date;

public class Timecontrol {
    private Integer sn;

    private String bcode;

    private String timeclass;

    private Date btime;

    private Date etime;

    private Integer syear;

    public Integer getSn() {
        return sn;
    }

    public void setSn(Integer sn) {
        this.sn = sn;
    }

    public String getBcode() {
        return bcode;
    }

    public void setBcode(String bcode) {
        this.bcode = bcode == null ? null : bcode.trim();
    }

    public String getTimeclass() {
        return timeclass;
    }

    public void setTimeclass(String timeclass) {
        this.timeclass = timeclass == null ? null : timeclass.trim();
    }

    public Date getBtime() {
        return btime;
    }

    public void setBtime(Date btime) {
        this.btime = btime;
    }

    public Date getEtime() {
        return etime;
    }

    public void setEtime(Date etime) {
        this.etime = etime;
    }

    public Integer getSyear() {
        return syear;
    }

    public void setSyear(Integer syear) {
        this.syear = syear;
    }
}