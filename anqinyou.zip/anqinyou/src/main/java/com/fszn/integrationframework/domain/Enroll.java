package com.fszn.integrationframework.domain;

import java.util.Date;

public class Enroll {
    private Long esn;

    private String wid;

    private Integer childsn;

    private String bcode;

    private Date edt;

    private Integer step;

    private Integer mrdtype;

    private Integer binfoIsright;

    private Integer materialIsright;

    private Integer preaudit;

    private String school1;

    private String school2;

    private String note;

    private Long uidSchool;

    private Date shTime;

    private Integer flag;

    private Long uidGl;

    private Date shTimeGl;

    private String from1;

    private Integer dflag;

    private Integer lqflag;

    private Integer jzflag;

    private Integer report1;

    private Integer report2;

    private Long uidFirstsbr;

    private Date firstSbsj;

    private Long uidSecondsbr;

    private Date secondSbsj;

    public Long getEsn() {
        return esn;
    }

    public void setEsn(Long esn) {
        this.esn = esn;
    }

    public String getWid() {
        return wid;
    }

    public void setWid(String wid) {
        this.wid = wid == null ? null : wid.trim();
    }

    public Integer getChildsn() {
        return childsn;
    }

    public void setChildsn(Integer childsn) {
        this.childsn = childsn;
    }

    public String getBcode() {
        return bcode;
    }

    public void setBcode(String bcode) {
        this.bcode = bcode == null ? null : bcode.trim();
    }

    public Date getEdt() {
        return edt;
    }

    public void setEdt(Date edt) {
        this.edt = edt;
    }

    public Integer getStep() {
        return step;
    }

    public void setStep(Integer step) {
        this.step = step;
    }

    public Integer getMrdtype() {
        return mrdtype;
    }

    public void setMrdtype(Integer mrdtype) {
        this.mrdtype = mrdtype;
    }

    public Integer getBinfoIsright() {
        return binfoIsright;
    }

    public void setBinfoIsright(Integer binfoIsright) {
        this.binfoIsright = binfoIsright;
    }

    public Integer getMaterialIsright() {
        return materialIsright;
    }

    public void setMaterialIsright(Integer materialIsright) {
        this.materialIsright = materialIsright;
    }

    public Integer getPreaudit() {
        return preaudit;
    }

    public void setPreaudit(Integer preaudit) {
        this.preaudit = preaudit;
    }

    public String getSchool1() {
        return school1;
    }

    public void setSchool1(String school1) {
        this.school1 = school1 == null ? null : school1.trim();
    }

    public String getSchool2() {
        return school2;
    }

    public void setSchool2(String school2) {
        this.school2 = school2 == null ? null : school2.trim();
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note == null ? null : note.trim();
    }

    public Long getUidSchool() {
        return uidSchool;
    }

    public void setUidSchool(Long uidSchool) {
        this.uidSchool = uidSchool;
    }

    public Date getShTime() {
        return shTime;
    }

    public void setShTime(Date shTime) {
        this.shTime = shTime;
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }

    public Long getUidGl() {
        return uidGl;
    }

    public void setUidGl(Long uidGl) {
        this.uidGl = uidGl;
    }

    public Date getShTimeGl() {
        return shTimeGl;
    }

    public void setShTimeGl(Date shTimeGl) {
        this.shTimeGl = shTimeGl;
    }

    public String getFrom1() {
        return from1;
    }

    public void setFrom1(String from1) {
        this.from1 = from1 == null ? null : from1.trim();
    }

    public Integer getDflag() {
        return dflag;
    }

    public void setDflag(Integer dflag) {
        this.dflag = dflag;
    }

    public Integer getLqflag() {
        return lqflag;
    }

    public void setLqflag(Integer lqflag) {
        this.lqflag = lqflag;
    }

    public Integer getJzflag() {
        return jzflag;
    }

    public void setJzflag(Integer jzflag) {
        this.jzflag = jzflag;
    }

    public Integer getReport1() {
        return report1;
    }

    public void setReport1(Integer report1) {
        this.report1 = report1;
    }

    public Integer getReport2() {
        return report2;
    }

    public void setReport2(Integer report2) {
        this.report2 = report2;
    }

    public Long getUidFirstsbr() {
        return uidFirstsbr;
    }

    public void setUidFirstsbr(Long uidFirstsbr) {
        this.uidFirstsbr = uidFirstsbr;
    }

    public Date getFirstSbsj() {
        return firstSbsj;
    }

    public void setFirstSbsj(Date firstSbsj) {
        this.firstSbsj = firstSbsj;
    }

    public Long getUidSecondsbr() {
        return uidSecondsbr;
    }

    public void setUidSecondsbr(Long uidSecondsbr) {
        this.uidSecondsbr = uidSecondsbr;
    }

    public Date getSecondSbsj() {
        return secondSbsj;
    }

    public void setSecondSbsj(Date secondSbsj) {
        this.secondSbsj = secondSbsj;
    }
}