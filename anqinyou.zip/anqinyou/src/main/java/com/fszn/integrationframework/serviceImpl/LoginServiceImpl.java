package com.fszn.integrationframework.serviceImpl;

import com.fszn.integrationframework.dao.EnrollMapper;
import com.fszn.integrationframework.dao.UserRollMapper;
import com.fszn.integrationframework.domain.EnrollExample;
import com.fszn.integrationframework.domain.UserRoll;
import com.fszn.integrationframework.domain.UserRollExample;
import com.fszn.integrationframework.service.LoginService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.Date;

@Service
@Slf4j

public class LoginServiceImpl implements LoginService {
    @Autowired
    private UserRollMapper userRollMapper;
    @Autowired
    private EnrollMapper enrollMapper;
    @Override
    public void token(String[] str) {
        Date date = new Date();
        Timestamp timeStamep = new Timestamp(date.getTime());
        //输出结果： 2016-09-22 10:38:14.964
        UserRoll userRoll = new UserRoll();
        UserRollExample userRollExample =new UserRollExample();
        UserRollExample.Criteria criteria=userRollExample.createCriteria();
        criteria.andIdEqualTo(str[4]);  //通过查询数据库中是否有相关记录--身份证
        userRoll.setWid(str[0]);
        userRoll.setRealname(str[1]);
        userRoll.setSex(str[2]);
        userRoll.setDt(timeStamep);
        log.info(String.valueOf(timeStamep));
        userRoll.setId(str[4]);
        userRoll.setPhone(str[5]);
        //判断 是否为二次登录 如果是二次登录则不再进行录入数据库
        try{
            if (userRollMapper.countByExample(userRollExample)==0) {
                userRollMapper.insertSelective(userRoll);
                log.info("往数据库增添userRoll数据正常");
            }

        }catch (Exception e){
            log.error("往数据库增添userRoll数据错误，错误时间"+String.valueOf(timeStamep));
        }

    }

    @Override//判断是否该用户名下是否有已完成的报名信息
    public boolean hasStepChild(String wid) {
        EnrollExample example=new EnrollExample();
        Boolean flag=true;//默认有
        example.createCriteria().andWidEqualTo(wid).andStepIsNotNull();
        try {
            if(enrollMapper.selectByExample(example).size()==0){
                flag=false;  //没有
            }
            log.info("查询该用户名下是否有已完成的报名信息成功");
        }catch (Exception e){
            log.error("查询该用户名下是否有已完成的报名信息异常");
        }

        return  flag;

    }
}
