package com.fszn.integrationframework.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class UserRollExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public UserRollExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andWidIsNull() {
            addCriterion("wid is null");
            return (Criteria) this;
        }

        public Criteria andWidIsNotNull() {
            addCriterion("wid is not null");
            return (Criteria) this;
        }

        public Criteria andWidEqualTo(String value) {
            addCriterion("wid =", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidNotEqualTo(String value) {
            addCriterion("wid <>", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidGreaterThan(String value) {
            addCriterion("wid >", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidGreaterThanOrEqualTo(String value) {
            addCriterion("wid >=", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidLessThan(String value) {
            addCriterion("wid <", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidLessThanOrEqualTo(String value) {
            addCriterion("wid <=", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidLike(String value) {
            addCriterion("wid like", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidNotLike(String value) {
            addCriterion("wid not like", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidIn(List<String> values) {
            addCriterion("wid in", values, "wid");
            return (Criteria) this;
        }

        public Criteria andWidNotIn(List<String> values) {
            addCriterion("wid not in", values, "wid");
            return (Criteria) this;
        }

        public Criteria andWidBetween(String value1, String value2) {
            addCriterion("wid between", value1, value2, "wid");
            return (Criteria) this;
        }

        public Criteria andWidNotBetween(String value1, String value2) {
            addCriterion("wid not between", value1, value2, "wid");
            return (Criteria) this;
        }

        public Criteria andAsnIsNull() {
            addCriterion("asn is null");
            return (Criteria) this;
        }

        public Criteria andAsnIsNotNull() {
            addCriterion("asn is not null");
            return (Criteria) this;
        }

        public Criteria andAsnEqualTo(Integer value) {
            addCriterion("asn =", value, "asn");
            return (Criteria) this;
        }

        public Criteria andAsnNotEqualTo(Integer value) {
            addCriterion("asn <>", value, "asn");
            return (Criteria) this;
        }

        public Criteria andAsnGreaterThan(Integer value) {
            addCriterion("asn >", value, "asn");
            return (Criteria) this;
        }

        public Criteria andAsnGreaterThanOrEqualTo(Integer value) {
            addCriterion("asn >=", value, "asn");
            return (Criteria) this;
        }

        public Criteria andAsnLessThan(Integer value) {
            addCriterion("asn <", value, "asn");
            return (Criteria) this;
        }

        public Criteria andAsnLessThanOrEqualTo(Integer value) {
            addCriterion("asn <=", value, "asn");
            return (Criteria) this;
        }

        public Criteria andAsnIn(List<Integer> values) {
            addCriterion("asn in", values, "asn");
            return (Criteria) this;
        }

        public Criteria andAsnNotIn(List<Integer> values) {
            addCriterion("asn not in", values, "asn");
            return (Criteria) this;
        }

        public Criteria andAsnBetween(Integer value1, Integer value2) {
            addCriterion("asn between", value1, value2, "asn");
            return (Criteria) this;
        }

        public Criteria andAsnNotBetween(Integer value1, Integer value2) {
            addCriterion("asn not between", value1, value2, "asn");
            return (Criteria) this;
        }

        public Criteria andRealnameIsNull() {
            addCriterion("realname is null");
            return (Criteria) this;
        }

        public Criteria andRealnameIsNotNull() {
            addCriterion("realname is not null");
            return (Criteria) this;
        }

        public Criteria andRealnameEqualTo(String value) {
            addCriterion("realname =", value, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameNotEqualTo(String value) {
            addCriterion("realname <>", value, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameGreaterThan(String value) {
            addCriterion("realname >", value, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameGreaterThanOrEqualTo(String value) {
            addCriterion("realname >=", value, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameLessThan(String value) {
            addCriterion("realname <", value, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameLessThanOrEqualTo(String value) {
            addCriterion("realname <=", value, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameLike(String value) {
            addCriterion("realname like", value, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameNotLike(String value) {
            addCriterion("realname not like", value, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameIn(List<String> values) {
            addCriterion("realname in", values, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameNotIn(List<String> values) {
            addCriterion("realname not in", values, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameBetween(String value1, String value2) {
            addCriterion("realname between", value1, value2, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameNotBetween(String value1, String value2) {
            addCriterion("realname not between", value1, value2, "realname");
            return (Criteria) this;
        }

        public Criteria andSexIsNull() {
            addCriterion("sex is null");
            return (Criteria) this;
        }

        public Criteria andSexIsNotNull() {
            addCriterion("sex is not null");
            return (Criteria) this;
        }

        public Criteria andSexEqualTo(String value) {
            addCriterion("sex =", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexNotEqualTo(String value) {
            addCriterion("sex <>", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexGreaterThan(String value) {
            addCriterion("sex >", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexGreaterThanOrEqualTo(String value) {
            addCriterion("sex >=", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexLessThan(String value) {
            addCriterion("sex <", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexLessThanOrEqualTo(String value) {
            addCriterion("sex <=", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexLike(String value) {
            addCriterion("sex like", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexNotLike(String value) {
            addCriterion("sex not like", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexIn(List<String> values) {
            addCriterion("sex in", values, "sex");
            return (Criteria) this;
        }

        public Criteria andSexNotIn(List<String> values) {
            addCriterion("sex not in", values, "sex");
            return (Criteria) this;
        }

        public Criteria andSexBetween(String value1, String value2) {
            addCriterion("sex between", value1, value2, "sex");
            return (Criteria) this;
        }

        public Criteria andSexNotBetween(String value1, String value2) {
            addCriterion("sex not between", value1, value2, "sex");
            return (Criteria) this;
        }

        public Criteria andDtIsNull() {
            addCriterion("dt is null");
            return (Criteria) this;
        }

        public Criteria andDtIsNotNull() {
            addCriterion("dt is not null");
            return (Criteria) this;
        }

        public Criteria andDtEqualTo(Date value) {
            addCriterion("dt =", value, "dt");
            return (Criteria) this;
        }

        public Criteria andDtNotEqualTo(Date value) {
            addCriterion("dt <>", value, "dt");
            return (Criteria) this;
        }

        public Criteria andDtGreaterThan(Date value) {
            addCriterion("dt >", value, "dt");
            return (Criteria) this;
        }

        public Criteria andDtGreaterThanOrEqualTo(Date value) {
            addCriterion("dt >=", value, "dt");
            return (Criteria) this;
        }

        public Criteria andDtLessThan(Date value) {
            addCriterion("dt <", value, "dt");
            return (Criteria) this;
        }

        public Criteria andDtLessThanOrEqualTo(Date value) {
            addCriterion("dt <=", value, "dt");
            return (Criteria) this;
        }

        public Criteria andDtIn(List<Date> values) {
            addCriterion("dt in", values, "dt");
            return (Criteria) this;
        }

        public Criteria andDtNotIn(List<Date> values) {
            addCriterion("dt not in", values, "dt");
            return (Criteria) this;
        }

        public Criteria andDtBetween(Date value1, Date value2) {
            addCriterion("dt between", value1, value2, "dt");
            return (Criteria) this;
        }

        public Criteria andDtNotBetween(Date value1, Date value2) {
            addCriterion("dt not between", value1, value2, "dt");
            return (Criteria) this;
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(String value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(String value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(String value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(String value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(String value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(String value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLike(String value) {
            addCriterion("id like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotLike(String value) {
            addCriterion("id not like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<String> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<String> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(String value1, String value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(String value1, String value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andPhoneIsNull() {
            addCriterion("phone is null");
            return (Criteria) this;
        }

        public Criteria andPhoneIsNotNull() {
            addCriterion("phone is not null");
            return (Criteria) this;
        }

        public Criteria andPhoneEqualTo(String value) {
            addCriterion("phone =", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneNotEqualTo(String value) {
            addCriterion("phone <>", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneGreaterThan(String value) {
            addCriterion("phone >", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("phone >=", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneLessThan(String value) {
            addCriterion("phone <", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneLessThanOrEqualTo(String value) {
            addCriterion("phone <=", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneLike(String value) {
            addCriterion("phone like", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneNotLike(String value) {
            addCriterion("phone not like", value, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneIn(List<String> values) {
            addCriterion("phone in", values, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneNotIn(List<String> values) {
            addCriterion("phone not in", values, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneBetween(String value1, String value2) {
            addCriterion("phone between", value1, value2, "phone");
            return (Criteria) this;
        }

        public Criteria andPhoneNotBetween(String value1, String value2) {
            addCriterion("phone not between", value1, value2, "phone");
            return (Criteria) this;
        }

        public Criteria andDuohaiIsNull() {
            addCriterion("duohai is null");
            return (Criteria) this;
        }

        public Criteria andDuohaiIsNotNull() {
            addCriterion("duohai is not null");
            return (Criteria) this;
        }

        public Criteria andDuohaiEqualTo(String value) {
            addCriterion("duohai =", value, "duohai");
            return (Criteria) this;
        }

        public Criteria andDuohaiNotEqualTo(String value) {
            addCriterion("duohai <>", value, "duohai");
            return (Criteria) this;
        }

        public Criteria andDuohaiGreaterThan(String value) {
            addCriterion("duohai >", value, "duohai");
            return (Criteria) this;
        }

        public Criteria andDuohaiGreaterThanOrEqualTo(String value) {
            addCriterion("duohai >=", value, "duohai");
            return (Criteria) this;
        }

        public Criteria andDuohaiLessThan(String value) {
            addCriterion("duohai <", value, "duohai");
            return (Criteria) this;
        }

        public Criteria andDuohaiLessThanOrEqualTo(String value) {
            addCriterion("duohai <=", value, "duohai");
            return (Criteria) this;
        }

        public Criteria andDuohaiLike(String value) {
            addCriterion("duohai like", value, "duohai");
            return (Criteria) this;
        }

        public Criteria andDuohaiNotLike(String value) {
            addCriterion("duohai not like", value, "duohai");
            return (Criteria) this;
        }

        public Criteria andDuohaiIn(List<String> values) {
            addCriterion("duohai in", values, "duohai");
            return (Criteria) this;
        }

        public Criteria andDuohaiNotIn(List<String> values) {
            addCriterion("duohai not in", values, "duohai");
            return (Criteria) this;
        }

        public Criteria andDuohaiBetween(String value1, String value2) {
            addCriterion("duohai between", value1, value2, "duohai");
            return (Criteria) this;
        }

        public Criteria andDuohaiNotBetween(String value1, String value2) {
            addCriterion("duohai not between", value1, value2, "duohai");
            return (Criteria) this;
        }

        public Criteria andIsyhIsNull() {
            addCriterion("isyh is null");
            return (Criteria) this;
        }

        public Criteria andIsyhIsNotNull() {
            addCriterion("isyh is not null");
            return (Criteria) this;
        }

        public Criteria andIsyhEqualTo(String value) {
            addCriterion("isyh =", value, "isyh");
            return (Criteria) this;
        }

        public Criteria andIsyhNotEqualTo(String value) {
            addCriterion("isyh <>", value, "isyh");
            return (Criteria) this;
        }

        public Criteria andIsyhGreaterThan(String value) {
            addCriterion("isyh >", value, "isyh");
            return (Criteria) this;
        }

        public Criteria andIsyhGreaterThanOrEqualTo(String value) {
            addCriterion("isyh >=", value, "isyh");
            return (Criteria) this;
        }

        public Criteria andIsyhLessThan(String value) {
            addCriterion("isyh <", value, "isyh");
            return (Criteria) this;
        }

        public Criteria andIsyhLessThanOrEqualTo(String value) {
            addCriterion("isyh <=", value, "isyh");
            return (Criteria) this;
        }

        public Criteria andIsyhLike(String value) {
            addCriterion("isyh like", value, "isyh");
            return (Criteria) this;
        }

        public Criteria andIsyhNotLike(String value) {
            addCriterion("isyh not like", value, "isyh");
            return (Criteria) this;
        }

        public Criteria andIsyhIn(List<String> values) {
            addCriterion("isyh in", values, "isyh");
            return (Criteria) this;
        }

        public Criteria andIsyhNotIn(List<String> values) {
            addCriterion("isyh not in", values, "isyh");
            return (Criteria) this;
        }

        public Criteria andIsyhBetween(String value1, String value2) {
            addCriterion("isyh between", value1, value2, "isyh");
            return (Criteria) this;
        }

        public Criteria andIsyhNotBetween(String value1, String value2) {
            addCriterion("isyh not between", value1, value2, "isyh");
            return (Criteria) this;
        }

        public Criteria andSbtflagIsNull() {
            addCriterion("Sbtflag is null");
            return (Criteria) this;
        }

        public Criteria andSbtflagIsNotNull() {
            addCriterion("Sbtflag is not null");
            return (Criteria) this;
        }

        public Criteria andSbtflagEqualTo(Integer value) {
            addCriterion("Sbtflag =", value, "sbtflag");
            return (Criteria) this;
        }

        public Criteria andSbtflagNotEqualTo(Integer value) {
            addCriterion("Sbtflag <>", value, "sbtflag");
            return (Criteria) this;
        }

        public Criteria andSbtflagGreaterThan(Integer value) {
            addCriterion("Sbtflag >", value, "sbtflag");
            return (Criteria) this;
        }

        public Criteria andSbtflagGreaterThanOrEqualTo(Integer value) {
            addCriterion("Sbtflag >=", value, "sbtflag");
            return (Criteria) this;
        }

        public Criteria andSbtflagLessThan(Integer value) {
            addCriterion("Sbtflag <", value, "sbtflag");
            return (Criteria) this;
        }

        public Criteria andSbtflagLessThanOrEqualTo(Integer value) {
            addCriterion("Sbtflag <=", value, "sbtflag");
            return (Criteria) this;
        }

        public Criteria andSbtflagIn(List<Integer> values) {
            addCriterion("Sbtflag in", values, "sbtflag");
            return (Criteria) this;
        }

        public Criteria andSbtflagNotIn(List<Integer> values) {
            addCriterion("Sbtflag not in", values, "sbtflag");
            return (Criteria) this;
        }

        public Criteria andSbtflagBetween(Integer value1, Integer value2) {
            addCriterion("Sbtflag between", value1, value2, "sbtflag");
            return (Criteria) this;
        }

        public Criteria andSbtflagNotBetween(Integer value1, Integer value2) {
            addCriterion("Sbtflag not between", value1, value2, "sbtflag");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}