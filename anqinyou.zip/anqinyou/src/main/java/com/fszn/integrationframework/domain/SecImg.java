package com.fszn.integrationframework.domain;

public class SecImg {
    private String jsonImgSec11;
    private String jsonImgSec12;
    private String jsonImgSec13;
    private String jsonImgSec21;
    private String jsonImgSec22;
    private String jsonImgSec23;

    public String getJsonImgSec11() {
        return jsonImgSec11;
    }

    public void setJsonImgSec11(String jsonImgSec11) {
        this.jsonImgSec11 = jsonImgSec11;
    }

    public String getJsonImgSec12() {
        return jsonImgSec12;
    }

    public void setJsonImgSec12(String jsonImgSec12) {
        this.jsonImgSec12 = jsonImgSec12;
    }

    public String getJsonImgSec13() {
        return jsonImgSec13;
    }

    public void setJsonImgSec13(String jsonImgSec13) {
        this.jsonImgSec13 = jsonImgSec13;
    }

    public String getJsonImgSec21() {
        return jsonImgSec21;
    }

    public void setJsonImgSec21(String jsonImgSec21) {
        this.jsonImgSec21 = jsonImgSec21;
    }

    public String getJsonImgSec22() {
        return jsonImgSec22;
    }

    public void setJsonImgSec22(String jsonImgSec22) {
        this.jsonImgSec22 = jsonImgSec22;
    }

    public String getJsonImgSec23() {
        return jsonImgSec23;
    }

    public void setJsonImgSec231(String jsonImgSec23) {
        this.jsonImgSec23 = jsonImgSec23;
    }
}
