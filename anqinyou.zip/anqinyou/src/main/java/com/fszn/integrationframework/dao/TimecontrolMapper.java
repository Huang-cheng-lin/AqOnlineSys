package com.fszn.integrationframework.dao;

import com.fszn.integrationframework.domain.Timecontrol;
import com.fszn.integrationframework.domain.TimecontrolExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TimecontrolMapper {
    long countByExample(TimecontrolExample example);

    int deleteByExample(TimecontrolExample example);

    int deleteByPrimaryKey(Integer sn);

    int insert(Timecontrol record);

    int insertSelective(Timecontrol record);

    List<Timecontrol> selectByExample(TimecontrolExample example);

    Timecontrol selectByPrimaryKey(Integer sn);

    int updateByExampleSelective(@Param("record") Timecontrol record, @Param("example") TimecontrolExample example);

    int updateByExample(@Param("record") Timecontrol record, @Param("example") TimecontrolExample example);

    int updateByPrimaryKeySelective(Timecontrol record);

    int updateByPrimaryKey(Timecontrol record);
}