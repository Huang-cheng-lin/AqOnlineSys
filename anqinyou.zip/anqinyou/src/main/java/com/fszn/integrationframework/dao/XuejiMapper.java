package com.fszn.integrationframework.dao;

import com.fszn.integrationframework.domain.Xueji;
import com.fszn.integrationframework.domain.XuejiExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface XuejiMapper {
    long countByExample(XuejiExample example);

    int deleteByExample(XuejiExample example);

    int deleteByPrimaryKey(Integer xsn);

    int insert(Xueji record);

    int insertSelective(Xueji record);

    List<Xueji> selectByExample(XuejiExample example);

    Xueji selectByPrimaryKey(Integer xsn);

    int updateByExampleSelective(@Param("record") Xueji record, @Param("example") XuejiExample example);

    int updateByExample(@Param("record") Xueji record, @Param("example") XuejiExample example);

    int updateByPrimaryKeySelective(Xueji record);

    int updateByPrimaryKey(Xueji record);
}