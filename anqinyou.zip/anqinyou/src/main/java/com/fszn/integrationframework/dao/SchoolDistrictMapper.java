package com.fszn.integrationframework.dao;

import com.fszn.integrationframework.domain.SchoolDistrict;
import com.fszn.integrationframework.domain.SchoolDistrictExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SchoolDistrictMapper {
    long countByExample(SchoolDistrictExample example);

    int deleteByExample(SchoolDistrictExample example);

    int deleteByPrimaryKey(Integer dsn);

    int insert(SchoolDistrict record);

    int insertSelective(SchoolDistrict record);

    List<SchoolDistrict> selectByExample(SchoolDistrictExample example);

    SchoolDistrict selectByPrimaryKey(Integer dsn);

    int updateByExampleSelective(@Param("record") SchoolDistrict record, @Param("example") SchoolDistrictExample example);

    int updateByExample(@Param("record") SchoolDistrict record, @Param("example") SchoolDistrictExample example);

    int updateByPrimaryKeySelective(SchoolDistrict record);

    int updateByPrimaryKey(SchoolDistrict record);
}