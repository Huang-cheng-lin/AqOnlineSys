package com.fszn.integrationframework.utils;

import com.google.gson.Gson;


public class JsonTool {

    public static String turnToJson(Object obj) {
        Gson gson = new Gson();
        return gson.toJson(obj);
    }

    public static <T> T parseJsonWithGson(String jsonData, Class<T> type) {
        Gson gson = new Gson();
        return gson.fromJson(jsonData, type);
    }
}

   
   

