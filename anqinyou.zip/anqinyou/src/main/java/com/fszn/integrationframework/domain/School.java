package com.fszn.integrationframework.domain;

public class School {
    private Integer scsn;

    private Integer asn;

    private Integer dsn;

    private String scname;

    private String sctype;

    private String scaddress;

    private String person;

    private String phone;

    private Integer cnt;

    private String note;

    public Integer getScsn() {
        return scsn;
    }

    public void setScsn(Integer scsn) {
        this.scsn = scsn;
    }

    public Integer getAsn() {
        return asn;
    }

    public void setAsn(Integer asn) {
        this.asn = asn;
    }

    public Integer getDsn() {
        return dsn;
    }

    public void setDsn(Integer dsn) {
        this.dsn = dsn;
    }

    public String getScname() {
        return scname;
    }

    public void setScname(String scname) {
        this.scname = scname == null ? null : scname.trim();
    }

    public String getSctype() {
        return sctype;
    }

    public void setSctype(String sctype) {
        this.sctype = sctype == null ? null : sctype.trim();
    }

    public String getScaddress() {
        return scaddress;
    }

    public void setScaddress(String scaddress) {
        this.scaddress = scaddress == null ? null : scaddress.trim();
    }

    public String getPerson() {
        return person;
    }

    public void setPerson(String person) {
        this.person = person == null ? null : person.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public Integer getCnt() {
        return cnt;
    }

    public void setCnt(Integer cnt) {
        this.cnt = cnt;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note == null ? null : note.trim();
    }
}