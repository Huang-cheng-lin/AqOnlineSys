package com.fszn.integrationframework.serviceImpl;

import com.fszn.integrationframework.dao.*;
import com.fszn.integrationframework.domain.*;
import com.fszn.integrationframework.service.ChooseService;
import com.fszn.integrationframework.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Service
@Slf4j

public class ChooseServiceImpl implements ChooseService {
    @Autowired
    private FamilyMapper familyMapper;
    @Autowired
    private StudentMapper studentMapper;
    @Autowired
    private XuejiMapper xuejiMapper;
    @Autowired
    private EnrollMapper enrollMapper;
    @Autowired
    private UserRollMapper userRollMapper;
    @Autowired
    private Result result;
    @Autowired
    private MaterialMapper materialMapper;
    @Autowired
    private  PorpertyMapper porpertyMapper;
    @Autowired
    private  HouseholdMapper householdMapper;
    @Override
    public Result primaryTomiddle(String type, String wid, int childsn, String schoolname,String selecttypevalue) {  //选择报名类型 并录入数据库
        Enroll enroll = new Enroll();
        enroll.setBcode(type.replace("'", ""));
        enroll.setWid(wid);
        enroll.setChildsn(childsn);
        enroll.setSchool1(schoolname);
        enroll.setMrdtype(Integer.parseInt(selecttypevalue));
        Date date = new Date();
        Timestamp timeStamep = new Timestamp(date.getTime());
        enroll.setEdt(timeStamep);
        try {
            EnrollExample enrollExample = new EnrollExample();
            EnrollExample.Criteria criteria = enrollExample.createCriteria();
            criteria.andWidEqualTo(wid);
            criteria.andChildsnEqualTo(childsn);
            criteria.andBcodeEqualTo(type);
            if (enrollMapper.selectByExample(enrollExample).size() == 0) {
                //报名类型数据录入
                enrollMapper.insertSelective(enroll);
                log.info("报名类型数据录入成功");
                result.setCode("200");
            } else {
                //报名类型数据修改
                enroll.setWid(null);
                enrollMapper.updateByExampleSelective(enroll, enrollExample);
                log.info("报名类型数据修改成功");
            }
        } catch (Exception e) {
            log.error("报名数据录入失败，皖氏通id：" + wid);
            result.setCode("500");
        }
        return result;
    }

    @Override   //根据家长的选区  将选区信息存入数据库中  user_roll表中
    public Result choosearea(String type, String wid) {
        UserRoll userRoll = new UserRoll();
        userRoll.setAsn(Integer.parseInt(type));
        UserRollExample example = new UserRollExample();
        UserRollExample.Criteria criteria = example.createCriteria();
        criteria.andWidEqualTo(wid);
        try {
            userRollMapper.updateByExampleSelective(userRoll, example);
            log.info("选区类型数据录入成功");
            result.setCode("200");
        } catch (Exception e) {
            result.setCode("500");
            log.error("选区类型数据录入失败，皖氏通id：" + wid);
        }
        return result;
    }

    @Override//房产资料认证更新
    public Result updatemrdtype(int mrdtype, String wid, String type) {
        Enroll enroll = new Enroll();
        enroll.setMrdtype(mrdtype);
        try {
            EnrollExample enrollExample = new EnrollExample();
            EnrollExample.Criteria criteria = enrollExample.createCriteria();
            criteria.andWidEqualTo(wid);
            criteria.andBcodeEqualTo(type);
            //资料认证修改
            enrollMapper.updateByExampleSelective(enroll, enrollExample);
            log.info("资料认证数据修改成功");
        } catch (Exception e) {
            log.error("资料认证数据修改失败，皖氏通id：" + wid);
            result.setCode("500");
        }
        return result;
    }

    @Override//确认提交认真信息 且修改Step状态
    public Result submitSecMsg(SecImg secImg, String wid, int childsn, String type) {
        //证明材料的录入
        //SecMsg中存储了   6张图片属性
        //对material数据表进行维护  即材料文件存储到本地数据库   总个流程：  通过wid  childsn   获取esn
        //材料类型  通过判断字段名 来生成对应的材料类型   材料名称    上传时间   将文件写入文件 并存到服务器物理地址
        //返回物理地址、文件大小    存入数据库
        //esn 通过查询 enroll数据表 通过wid  进行查询
        EnrollExample example1 = new EnrollExample();
        EnrollExample.Criteria criteria1 = example1.createCriteria();
        criteria1.andWidEqualTo(wid);
        criteria1.andChildsnEqualTo(childsn);
        criteria1.andBcodeEqualTo(type);
        List<Enroll> list = enrollMapper.selectByExample(example1);
        Long esn = list.get(0).getEsn();   //获取esn报名编号
        Class<?> clazz = secImg.getClass();
        //通过判断属性是否为null 进行判断
        //java中遍历实体类，获取属性名和属性值
        String path = "src/main/resources/static/uploadFile/";
        FileAttribute fileAttribute;
        Material material = new Material();
        material.setGuid(new RandomGUID().toString());
        List<Material> list1;
        try {
            for (Field field : secImg.getClass().getDeclaredFields()) {
                field.setAccessible(true);////AccessibleTest类中的成员变量为private,故必须进行此操作
                //field.getName()  属性名   field.get(houseMsg)属性值

                if (field.getName().contains("jsonImgSec") && field.get(secImg) != null) {
                    switch (field.getName().charAt(10)) {
                        case '1':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(secImg), path + esn, field.getName());
                            material.setMtype("出生材料证明图片");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                log.info(fileAttribute.getMname());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '2':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(secImg), path + esn, field.getName());
                            material.setMtype("接种材料证明图片");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                    }


                }
            }
            //往enroll表中修改step信息
            Enroll enroll = new Enroll();
            enroll.setStep(1);
            enrollMapper.updateByExampleSelective(enroll, example1);
            log.info("成功修改step标签");
            result.setCode("200");
            log.info("材料数据表维护成功 皖氏通id：" + wid);
        } catch (Exception e) {
            log.error("遍历SecImg属性字段出错或存入数据库出错   ---- 皖氏通id：" + wid);
            result.setCode("500");
        }


        return result;
    }

    @Override //修改单孩多孩、摇号方式    user-roll数据表
    public void addIsyh(String phone,String selectchild, String gettype, String wid) {
        UserRoll userRoll = new UserRoll();
        userRoll.setDuohai(selectchild);
        userRoll.setPhone(phone);
        if (gettype.equals("2")) {
            userRoll.setIsyh("true");
        } else {
            userRoll.setIsyh("false");
        }
        UserRollExample example = new UserRollExample();
        example.createCriteria().andWidEqualTo(wid);
        try {
            userRollMapper.updateByExampleSelective(userRoll, example);
            log.info("修改摇号方式成功");
        } catch (Exception e) {
            log.error("修改摇号方式失败");
        }
    }

    @Override
    public int getChildsn(String type, String wid) {
        EnrollExample example = new EnrollExample();
        int size = 3;//默认报错
        example.createCriteria().andWidEqualTo(wid).andStepIsNotNull().andBcodeEqualTo(type);
        try {
            size = enrollMapper.selectByExample(example).size();


            log.info("查询该用户名下是否有已完成的报名信息成功");
        } catch (Exception e) {
            log.error("查询该用户名下是否有已完成的报名信息异常");
        }

        return size;
    }

    @Override  // 提交认证信息、但是不修改step字段即 不确认提交
    public Result temporarySecMsg(SecImg secImg, String wid, int childsn, String type) {
        //证明材料的录入
        //SecMsg中存储了   6张图片属性
        //对material数据表进行维护  即材料文件存储到本地数据库   总个流程：  通过wid  childsn   获取esn
        //材料类型  通过判断字段名 来生成对应的材料类型   材料名称    上传时间   将文件写入文件 并存到服务器物理地址
        //返回物理地址、文件大小    存入数据库
        //esn 通过查询 enroll数据表 通过wid  进行查询
        EnrollExample example1 = new EnrollExample();
        EnrollExample.Criteria criteria1 = example1.createCriteria();
        criteria1.andWidEqualTo(wid);
        criteria1.andChildsnEqualTo(childsn);
        criteria1.andBcodeEqualTo(type);
        List<Enroll> list = enrollMapper.selectByExample(example1);
        Long esn = list.get(0).getEsn();   //获取esn报名编号
        Class<?> clazz = secImg.getClass();
        //通过判断属性是否为null 进行判断
        //java中遍历实体类，获取属性名和属性值
        String path = "src/main/resources/static/uploadFile/";
        FileAttribute fileAttribute;
        Material material = new Material();
        material.setGuid(new RandomGUID().toString());
        //直接清空数据库
        MaterialExample example3 = new MaterialExample();
        example3.createCriteria().andEsnEqualTo(esn).andMnameLike("jsonImgSec%");
        List<Material> list1;
        try {
            materialMapper.deleteByExample(example3);
            for (Field field : secImg.getClass().getDeclaredFields()) {
                field.setAccessible(true);////AccessibleTest类中的成员变量为private,故必须进行此操作
                //field.getName()  属性名   field.get(houseMsg)属性值

                if (field.getName().contains("jsonImgSec") && field.get(secImg) != null) {
                    switch (field.getName().charAt(10)) {
                        case '1':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(secImg), path + esn, field.getName());
                            material.setMtype("出生材料证明图片");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                log.info(fileAttribute.getMname());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '2':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(secImg), path + esn, field.getName());
                            material.setMtype("接种材料证明图片");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                    }


                }
            }
            result.setCode("200");
            log.info("材料数据表维护成功 皖氏通id：" + wid);
        } catch (Exception e) {
            log.error("遍历SecImg属性字段出错或存入数据库出错   ---- 皖氏通id：" + wid);
            result.setCode("500");
        }
        return result;
    }

    @Override//返回尚未提交的报名信息
    public int getChildsn1(String type, String wid) {
        EnrollExample example = new EnrollExample();
        int size = 3;//默认报错
        example.createCriteria().andWidEqualTo(wid).andBcodeEqualTo(type);
        try {
            size = enrollMapper.selectByExample(example).size();


            log.info("查询该用户名下是否有已完成的报名信息成功");
        } catch (Exception e) {
            log.error("查询该用户名下是否有已完成的报名信息异常");
        }

        return size;
    }

    @Override
    public int getChildsn2(String type, String wid) {
        EnrollExample example = new EnrollExample();
        int size = 3;//默认报错
        example.createCriteria().andWidEqualTo(wid).andStepIsNull().andBcodeEqualTo(type);
        try {
            size = enrollMapper.selectByExample(example).size();
            log.error(size+"");

            log.info("查询该用户名下是否有未完成的报名信息成功");
        } catch (Exception e) {
            log.error("查询该用户名下是否未已完成的报名信息异常");
        }

        return size;
    }

    @Override//清空测试数据
    public Result delete() {
        try{
            porpertyMapper.deleteByExample(new PorpertyExample());
            materialMapper.deleteByExample(new MaterialExample());
            familyMapper.deleteByExample(new FamilyExample());
            studentMapper.deleteByExample(new StudentExample());
            enrollMapper.deleteByExample(new EnrollExample());
            UserRollExample example=new UserRollExample();
            UserRoll userRoll=new UserRoll();
            userRoll.setDuohai("0");
            example.createCriteria().andIsyhIsNotNull();
            userRollMapper.updateByExampleSelective(userRoll,example);
            result.setCode("200");
            log.info("删除测试数据成功");
        }catch (Exception e){
            result.setCode("500");
            log.error("删除测试数据失败");
        }
        return result;
    }

    @Override
    public Result submitxuejiDuo(Student student, Student student1, String wid, int childsn, String gettype, String type) {
        //修改eroll表中的childsn的孩子标识
        //进行修改user——enroll 表中的监护人信息
//        XuejiExample example1 = new XuejiExample();
//        XuejiExample.Criteria criteria2 = example1.createCriteria();
//        criteria2.andSnEqualTo(student.getSn());
        EnrollExample example = new EnrollExample();
        EnrollExample.Criteria criteria = example.createCriteria();
        criteria.andWidEqualTo(wid);
        criteria.andBcodeEqualTo(type);
        List<Enroll> list = enrollMapper.selectByExample(example);
        Long esn = list.get(0).getEsn();   //获取esn报名编号
        //进行多孩报名时需先将enroll表中的孩子标识码改为3或4
        Enroll enroll=new Enroll();
        enroll.setEsn(esn);
        if(gettype =="true"){
            enroll.setChildsn(4);
        }else{
            enroll.setChildsn(3);
        }
        enrollMapper.updateByPrimaryKeySelective(enroll);
        student.setEsn(esn);
        student1.setEsn(esn);
        StudentExample studentExample = new StudentExample();
        StudentExample.Criteria criteria1 = studentExample.createCriteria();
        criteria1.andEsnEqualTo(student.getEsn());
        String icd = student.getId();//通过身份证 获取性别以及出生年月
        String icd1 = student1.getId();//通过身份证 获取性别以及出生年月
        //进行户籍表信息的插入


        try {
            log.info("进入try块");
            student.setBirth(StringToTimestamp.formatTime(IDCardUtil.getBirthday(icd)));//XXXX年XX月XX日的格式
            log.info("日期转换成功");
            student.setSex(IDCardUtil.getSex(icd));
            student1.setBirth(StringToTimestamp.formatTime(IDCardUtil.getBirthday(icd1)));//XXXX年XX月XX日的格式
            log.info("日期转换成功");
            student1.setSex(IDCardUtil.getSex(icd1));
            //判断是否是第一次登录注册过
            if (studentMapper.selectByExample(studentExample).size() == 0) {
                studentMapper.insertSelective(student);//第一次登录该页面为插入操作
                studentMapper.insertSelective(student1);//第一次登录该页面为插入操作
                log.info("学生表信息插入成功");
                //进行学籍表信息插入
//                xuejiMapper.insertSelective(xueji);
                log.info("学籍、学生表维护正常------第一次登录  插入操作");
                result.setCode("200");
            } else {
//                xueji.setSn(null);
//                xuejiMapper.updateByExampleSelective(xueji, example1);
                log.info("学籍、学生表维护正常------第二次登录   修改操作");

                criteria1.andIdEqualTo(student.getId());
                studentMapper.updateByExampleSelective(student, studentExample);
                StudentExample studentExample1=new StudentExample();
                studentExample1.createCriteria().andEsnEqualTo(esn).andIdEqualTo(student1.getId());
                studentMapper.updateByExampleSelective(student1, studentExample1);
                //因为非第一次登录进行修改操作
                //进行学籍表修改操作
                result.setCode("200");
            }
        } catch (Exception e) {
            log.error("日期转化错误或者身份证录入不正确或学籍表、学生表维护失败  请查看数据库异常");
            result.setCode("500");
        }

        return result;
    }

    @Override
    public Result deleteByEsn(String wid, String type) {
        EnrollExample example = new EnrollExample();
        EnrollExample.Criteria criteria = example.createCriteria();
        criteria.andWidEqualTo(wid);
        criteria.andBcodeEqualTo(type);
        List<Enroll> list = enrollMapper.selectByExample(example);
        try {
           if(list.size()!=0){
               Long esn = list.get(0).getEsn();   //获取esn报名编号
               HouseholdExample householdExample=new HouseholdExample();
               householdExample.createCriteria().andEsnEqualTo(esn);
               householdMapper.deleteByExample(householdExample);
               PorpertyExample porpertyExample=new PorpertyExample();
               porpertyExample.createCriteria().andEsnEqualTo(esn);
               porpertyMapper.deleteByExample(porpertyExample);
               MaterialExample materialExample=new MaterialExample();
               materialExample.createCriteria().andEsnEqualTo(esn);
               materialMapper.deleteByExample(materialExample);
               FamilyExample familyExample=new FamilyExample();
               familyExample.createCriteria().andEsnEqualTo(esn);
               familyMapper.deleteByExample(familyExample);
               StudentExample studentExample=new StudentExample();
               studentExample.createCriteria().andEsnEqualTo(esn);
               studentMapper.deleteByExample(studentExample);
               enrollMapper.deleteByExample(example);
               UserRollExample example1=new UserRollExample();
               UserRoll userRoll=new UserRoll();
               userRoll.setDuohai("0");
               example1.createCriteria().andWidEqualTo(wid);
               userRollMapper.updateByExampleSelective(userRoll,example1);
               result.setCode("200");
           }else{
               result.setCode("500");
           }
        }catch ( Exception e){
            result.setCode("500");
            log.error("删除未提交的报名失败");
        }




        return result;
    }

    @Override
    public void notAddIsyh(String phone, String wid) {
        UserRoll userRoll = new UserRoll();
        userRoll.setPhone(phone);
        UserRollExample example = new UserRollExample();
        example.createCriteria().andWidEqualTo(wid);
        try {
            userRollMapper.updateByExampleSelective(userRoll, example);
            log.info("修改手机号码成功");
        } catch (Exception e) {
            log.error("修改手机号码失败");
        }
    }

    @Override//双一致且可提供房产原件
    public Result submitHouseMsgMdtype1(MiddleHouseMsg1 houseMsg, String wid, String type) {
        //通过调用相关接口   对porperty数据表进行维护  相关字段   报名编号、房产证号、产权人、房产地址、房产证办理时间
        //对material数据表进行维护  即材料文件存储到本地数据库   总个流程：  通过wid  childsn   获取esn
        //材料类型  通过判断字段名 来生成对应的材料类型   材料名称    上传时间   将文件写入文件 并存到服务器物理地址
        //返回物理地址、文件大小    存入数据库
        //esn 通过查询 enroll数据表 通过wid  进行查询
        EnrollExample example1 = new EnrollExample();
        EnrollExample.Criteria criteria1 = example1.createCriteria();
        criteria1.andWidEqualTo(wid);
        criteria1.andBcodeEqualTo(type);
        List<Enroll> list = enrollMapper.selectByExample(example1);
        Long esn = list.get(0).getEsn();   //获取esn报名编号
        //对应接口时再进行编写-------基本数据录入
        Porperty porperty=new Porperty();
        porperty.setEsn(esn);
        Class<?> clazz = houseMsg.getClass();
        //通过判断属性是否为null 进行判断
        //java中遍历实体类，获取属性名和属性值
        String path = "src/main/resources/static/uploadFile/";
        FileAttribute fileAttribute;
        Material material = new Material();
        //直接清空数据库  后续再改
        MaterialExample example3 = new MaterialExample();
        example3.createCriteria().andEsnEqualTo(esn).andMnameNotLike("jsonImgSec%");
        List<Material> list1;
        try {
            materialMapper.deleteByExample(example3);
            for (Field field : houseMsg.getClass().getDeclaredFields()) {
                field.setAccessible(true);////AccessibleTest类中的成员变量为private,故必须进行此操作
                //field.getName()  属性名   field.get(houseMsg)属性值
                if (field.getName().contains("pno") && field.get(houseMsg) != null) {
                    porperty.setPno((String) field.get(houseMsg));
                    continue;
                }
                if (field.getName().contains("address") && field.get(houseMsg) != null) {
                    porperty.setPaddress((String) field.get(houseMsg));
                    continue;
                }

                if (field.getName().contains("icd") && field.get(houseMsg) != null) {
                    porperty.setIcd((String) field.get(houseMsg));
                    continue;
                }

                if (field.getName().contains("jsonImg") && field.get(houseMsg) != null) {
                    switch (field.getName().charAt(7)) {
                        case '1':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("1");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setGuid(new RandomGUID().toString());
                                material.setMname(fileAttribute.getMname());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                log.info(fileAttribute.getMname());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '2':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("2");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setGuid(new RandomGUID().toString());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                    }
                }
            }
            result.setCode("200");
            log.info("材料数据表维护成功 皖氏通id：" + wid);
            //进行产权表的维护
            PorpertyExample porpertyExample=new PorpertyExample();
            porpertyExample.createCriteria().andEsnEqualTo(esn);
            if(porpertyMapper.selectByExample(porpertyExample).size()==0){
                porpertyMapper.insert(porperty);
            }else{
                porperty.setEsn(null);
                porpertyMapper.updateByExampleSelective(porperty,porpertyExample);
            }
        } catch (Exception e) {
            log.error("遍历HouseMsg属性字段出错或存入数据库出错   ---- 皖氏通id：" + wid);
            result.setCode("500");
        }


        return result;
    }

    @Override
    public Result submitHouseMsgNonMdtype1(MiddleHouseMsgNon1 houseMsg, String wid, String type) {
        //通过调用相关接口   对porperty数据表进行维护  相关字段   报名编号、房产证号、产权人、房产地址、房产证办理时间
        //对material数据表进行维护  即材料文件存储到本地数据库   总个流程：  通过wid  childsn   获取esn
        //材料类型  通过判断字段名 来生成对应的材料类型   材料名称    上传时间   将文件写入文件 并存到服务器物理地址
        //返回物理地址、文件大小    存入数据库
        //esn 通过查询 enroll数据表 通过wid  进行查询
        EnrollExample example1 = new EnrollExample();
        EnrollExample.Criteria criteria1 = example1.createCriteria();
        criteria1.andWidEqualTo(wid);
        criteria1.andBcodeEqualTo(type);
        List<Enroll> list = enrollMapper.selectByExample(example1);
        Long esn = list.get(0).getEsn();   //获取esn报名编号
        //对应接口时再进行编写-------基本数据录入
        Porperty porperty=new Porperty();
        porperty.setEsn(esn);
        Class<?> clazz = houseMsg.getClass();
        //通过判断属性是否为null 进行判断
        //java中遍历实体类，获取属性名和属性值
        String path = "src/main/resources/static/uploadFile/";
        FileAttribute fileAttribute;
        Material material = new Material();
        //直接清空数据库  后续再改
        MaterialExample example3 = new MaterialExample();
        example3.createCriteria().andEsnEqualTo(esn).andMnameNotLike("jsonImgSec%");
        List<Material> list1;
        try {
            materialMapper.deleteByExample(example3);
            for (Field field : houseMsg.getClass().getDeclaredFields()) {
                field.setAccessible(true);////AccessibleTest类中的成员变量为private,故必须进行此操作
                //field.getName()  属性名   field.get(houseMsg)属性值
                if (field.getName().contains("pno") && field.get(houseMsg) != null) {
                    porperty.setPno((String) field.get(houseMsg));
                    continue;
                }
                if (field.getName().contains("address") && field.get(houseMsg) != null) {
                    porperty.setPaddress((String) field.get(houseMsg));
                    continue;
                }

                if (field.getName().contains("icd") && field.get(houseMsg) != null) {
                    porperty.setIcd((String) field.get(houseMsg));
                    continue;
                }

                if (field.getName().contains("jsonImg") && field.get(houseMsg) != null) {
                    switch (field.getName().charAt(7)) {
                        case '1':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("3");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setGuid(new RandomGUID().toString());
                                material.setMname(fileAttribute.getMname());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                log.info(fileAttribute.getMname());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '3':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("4");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setGuid(new RandomGUID().toString());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '4':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("5");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setMsize(fileAttribute.getMsize());
                                material.setGuid(new RandomGUID().toString());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '5':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("6");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setMsize(fileAttribute.getMsize());
                                material.setGuid(new RandomGUID().toString());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '6':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("7");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setMsize(fileAttribute.getMsize());
                                material.setGuid(new RandomGUID().toString());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                    }


                }
            }
            result.setCode("200");
            log.info("材料数据表维护成功 皖氏通id：" + wid);
            //进行产权表的维护
            PorpertyExample porpertyExample=new PorpertyExample();
            porpertyExample.createCriteria().andEsnEqualTo(esn);
            if(porpertyMapper.selectByExample(porpertyExample).size()==0){
                porpertyMapper.insert(porperty);
            }else{
                porperty.setEsn(null);
                porpertyMapper.updateByExampleSelective(porperty,porpertyExample);
            }
        } catch (Exception e) {
            log.error("遍历HouseMsg属性字段出错或存入数据库出错   ---- 皖氏通id：" + wid);
            result.setCode("500");
        }


        return result;
    }

    @Override//独立房产
    public Result submitHouseMsgMdtype2(MiddleHouseMsg2 houseMsg, String wid, String type) {
        //通过调用相关接口   对porperty数据表进行维护  相关字段   报名编号、房产证号、产权人、房产地址、房产证办理时间
        //对material数据表进行维护  即材料文件存储到本地数据库   总个流程：  通过wid  childsn   获取esn
        //材料类型  通过判断字段名 来生成对应的材料类型   材料名称    上传时间   将文件写入文件 并存到服务器物理地址
        //返回物理地址、文件大小    存入数据库
        //esn 通过查询 enroll数据表 通过wid  进行查询
        EnrollExample example1 = new EnrollExample();
        EnrollExample.Criteria criteria1 = example1.createCriteria();
        criteria1.andWidEqualTo(wid);
        criteria1.andBcodeEqualTo(type);
        List<Enroll> list = enrollMapper.selectByExample(example1);
        Long esn = list.get(0).getEsn();   //获取esn报名编号
        //对应接口时再进行编写-------基本数据录入
        Porperty porperty=new Porperty();
        porperty.setEsn(esn);
        Class<?> clazz = houseMsg.getClass();
        //通过判断属性是否为null 进行判断
        //java中遍历实体类，获取属性名和属性值
        String path = "src/main/resources/static/uploadFile/";
        FileAttribute fileAttribute;
        Material material = new Material();
        //直接清空数据库  后续再改
        MaterialExample example3 = new MaterialExample();
        example3.createCriteria().andEsnEqualTo(esn).andMnameNotLike("jsonImgSec%");
        List<Material> list1;
        try {
            materialMapper.deleteByExample(example3);
            for (Field field : houseMsg.getClass().getDeclaredFields()) {
                field.setAccessible(true);////AccessibleTest类中的成员变量为private,故必须进行此操作
                //field.getName()  属性名   field.get(houseMsg)属性值
                if (field.getName().contains("pno") && field.get(houseMsg) != null) {
                    porperty.setPno((String) field.get(houseMsg));
                    continue;
                }
                if (field.getName().contains("address") && field.get(houseMsg) != null) {
                    porperty.setPaddress((String) field.get(houseMsg));
                    continue;
                }

                if (field.getName().contains("icd") && field.get(houseMsg) != null) {
                    porperty.setIcd((String) field.get(houseMsg));
                    continue;
                }

                if (field.getName().contains("jsonImg") && field.get(houseMsg) != null) {
                    switch (field.getName().charAt(7)) {
                        case '1':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("9");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setGuid(new RandomGUID().toString());
                                material.setMname(fileAttribute.getMname());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                log.info(fileAttribute.getMname());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '2':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("8");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setGuid(new RandomGUID().toString());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                    }
                }
            }
            result.setCode("200");
            log.info("材料数据表维护成功 皖氏通id：" + wid);
            //进行产权表的维护
            PorpertyExample porpertyExample=new PorpertyExample();
            porpertyExample.createCriteria().andEsnEqualTo(esn);
            if(porpertyMapper.selectByExample(porpertyExample).size()==0){
                porpertyMapper.insert(porperty);
            }else{
                porperty.setEsn(null);
                porpertyMapper.updateByExampleSelective(porperty,porpertyExample);
            }
        } catch (Exception e) {
            log.error("遍历HouseMsg属性字段出错或存入数据库出错   ---- 皖氏通id：" + wid);
            result.setCode("500");
        }


        return result;
    }

    @Override//爷孙户
    public Result submitHouseMsgMdtype3(MiddleHouseMsg3 houseMsg, String wid, String type) {
        //通过调用相关接口   对porperty数据表进行维护  相关字段   报名编号、房产证号、产权人、房产地址、房产证办理时间
        //对material数据表进行维护  即材料文件存储到本地数据库   总个流程：  通过wid  childsn   获取esn
        //材料类型  通过判断字段名 来生成对应的材料类型   材料名称    上传时间   将文件写入文件 并存到服务器物理地址
        //返回物理地址、文件大小    存入数据库
        //esn 通过查询 enroll数据表 通过wid  进行查询
        EnrollExample example1 = new EnrollExample();
        EnrollExample.Criteria criteria1 = example1.createCriteria();
        criteria1.andWidEqualTo(wid);
        criteria1.andBcodeEqualTo(type);
        List<Enroll> list = enrollMapper.selectByExample(example1);
        Long esn = list.get(0).getEsn();   //获取esn报名编号
        //对应接口时再进行编写-------基本数据录入
        Porperty porperty=new Porperty();
        porperty.setEsn(esn);
        Class<?> clazz = houseMsg.getClass();
        //通过判断属性是否为null 进行判断
        //java中遍历实体类，获取属性名和属性值
        String path = "src/main/resources/static/uploadFile/";
        FileAttribute fileAttribute;
        Material material = new Material();
        //直接清空数据库  后续再改
        MaterialExample example3 = new MaterialExample();
        example3.createCriteria().andEsnEqualTo(esn).andMnameNotLike("jsonImgSec%");
        List<Material> list1;
        try {
            materialMapper.deleteByExample(example3);
            for (Field field : houseMsg.getClass().getDeclaredFields()) {
                field.setAccessible(true);////AccessibleTest类中的成员变量为private,故必须进行此操作
                //field.getName()  属性名   field.get(houseMsg)属性值
                if (field.getName().contains("pno") && field.get(houseMsg) != null) {
                    porperty.setPno((String) field.get(houseMsg));
                    continue;
                }
                if (field.getName().contains("address") && field.get(houseMsg) != null) {
                    porperty.setPaddress((String) field.get(houseMsg));
                    continue;
                }

                if (field.getName().contains("icd") && field.get(houseMsg) != null) {
                    porperty.setIcd((String) field.get(houseMsg));
                    continue;
                }

                if (field.getName().contains("jsonImg") && field.get(houseMsg) != null) {
                    switch (field.getName().charAt(7)) {
                        case '1':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("10");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setGuid(new RandomGUID().toString());
                                material.setMname(fileAttribute.getMname());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                log.info(fileAttribute.getMname());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '2':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("11");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setGuid(new RandomGUID().toString());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '3':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("12");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setGuid(new RandomGUID().toString());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                    }
                }
            }
            result.setCode("200");
            log.info("材料数据表维护成功 皖氏通id：" + wid);
            //进行产权表的维护
            PorpertyExample porpertyExample=new PorpertyExample();
            porpertyExample.createCriteria().andEsnEqualTo(esn);
            if(porpertyMapper.selectByExample(porpertyExample).size()==0){
                porpertyMapper.insert(porperty);
            }else{
                porperty.setEsn(null);
                porpertyMapper.updateByExampleSelective(porperty,porpertyExample);
            }
        } catch (Exception e) {
            log.error("遍历HouseMsg属性字段出错或存入数据库出错   ---- 皖氏通id：" + wid);
            result.setCode("500");
        }


        return result;
    }

    @Override
    public Result submitHouseMsgMdtype4(MiddleHouseMsg4 houseMsg, String wid, String type) {
        //通过调用相关接口   对porperty数据表进行维护  相关字段   报名编号、房产证号、产权人、房产地址、房产证办理时间
        //对material数据表进行维护  即材料文件存储到本地数据库   总个流程：  通过wid  childsn   获取esn
        //材料类型  通过判断字段名 来生成对应的材料类型   材料名称    上传时间   将文件写入文件 并存到服务器物理地址
        //返回物理地址、文件大小    存入数据库
        //esn 通过查询 enroll数据表 通过wid  进行查询
        EnrollExample example1 = new EnrollExample();
        EnrollExample.Criteria criteria1 = example1.createCriteria();
        criteria1.andWidEqualTo(wid);
        criteria1.andBcodeEqualTo(type);
        List<Enroll> list = enrollMapper.selectByExample(example1);
        Long esn = list.get(0).getEsn();   //获取esn报名编号
        //对应接口时再进行编写-------基本数据录入
        Porperty porperty=new Porperty();
        porperty.setEsn(esn);
        Class<?> clazz = houseMsg.getClass();
        //通过判断属性是否为null 进行判断
        //java中遍历实体类，获取属性名和属性值
        String path = "src/main/resources/static/uploadFile/";
        FileAttribute fileAttribute;
        Material material = new Material();
        //直接清空数据库  后续再改
        MaterialExample example3 = new MaterialExample();
        example3.createCriteria().andEsnEqualTo(esn).andMnameNotLike("jsonImgSec%");
        List<Material> list1;
        try {
            materialMapper.deleteByExample(example3);
            for (Field field : houseMsg.getClass().getDeclaredFields()) {
                field.setAccessible(true);////AccessibleTest类中的成员变量为private,故必须进行此操作
                //field.getName()  属性名   field.get(houseMsg)属性值
                if (field.getName().contains("pno") && field.get(houseMsg) != null) {
                    porperty.setPno((String) field.get(houseMsg));
                    continue;
                }
                if (field.getName().contains("address") && field.get(houseMsg) != null) {
                    porperty.setPaddress((String) field.get(houseMsg));
                    continue;
                }

                if (field.getName().contains("icd") && field.get(houseMsg) != null) {
                    porperty.setIcd((String) field.get(houseMsg));
                    continue;
                }

                if (field.getName().contains("jsonImg") && field.get(houseMsg) != null) {
                    switch (field.getName().charAt(7)) {
                        case '1':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("13");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setGuid(new RandomGUID().toString());
                                material.setMname(fileAttribute.getMname());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                log.info(fileAttribute.getMname());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '2':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("14");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setGuid(new RandomGUID().toString());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '3':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("15");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setMsize(fileAttribute.getMsize());
                                material.setGuid(new RandomGUID().toString());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '4':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("16");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setMsize(fileAttribute.getMsize());
                                material.setGuid(new RandomGUID().toString());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '5':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("17");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setMsize(fileAttribute.getMsize());
                                material.setGuid(new RandomGUID().toString());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                    }


                }
            }
            result.setCode("200");
            log.info("材料数据表维护成功 皖氏通id：" + wid);
            PorpertyExample porpertyExample=new PorpertyExample();
            porpertyExample.createCriteria().andEsnEqualTo(esn);
            if(porpertyMapper.selectByExample(porpertyExample).size()==0){
                porpertyMapper.insert(porperty);
            }else{
                porperty.setEsn(null);
                porpertyMapper.updateByExampleSelective(porperty,porpertyExample);
            }
        } catch (Exception e) {
            log.error("遍历HouseMsg属性字段出错或存入数据库出错   ---- 皖氏通id：" + wid);
            result.setCode("500");
        }


        return result;
    }

    @Override//进行双选学校的录入、即确认信息的flag更新
    public Result submitShuangXuan(String schoolname, String wid, String type) {
        try{
            EnrollExample example = new EnrollExample();
            EnrollExample.Criteria criteria = example.createCriteria();
            criteria.andWidEqualTo(wid);
            criteria.andBcodeEqualTo(type);
            Enroll enroll = enrollMapper.selectByExample(example).get(0);
            enroll.setSchool2(schoolname);
            enroll.setJzflag(1);
            enrollMapper.updateByExampleSelective(enroll,example);
            result.setCode("200");
            log.info("双选去确认信息成功");
        }catch (Exception e){
            result.setCode("500");
            log.error("双选区确认信息失败");
        }
       return  result;
    }

    @Override
    public int getErollChildsn(String wid, String type) {
        EnrollExample example = new EnrollExample();
        int size=4;
        example.createCriteria().andWidEqualTo(wid).andBcodeEqualTo(type);
        try {
            List<Enroll> list= enrollMapper.selectByExample(example);
            if(list.size()==0){
                size=1;//给childsn赋值初值
            }else{
                size=list.get(0).getChildsn();
            }
            log.info("查询该用户名下是否有报名信息的childsn");
        } catch (Exception e) {
            log.error("查询该用户名下是否有报名信息的childsn异常");
        }

        return size;
    }

    @Override
    public Result submitHouseMsgYSH(HouseMsgYSH houseMsg, String wid, String type) {

        //通过调用相关接口   对porperty数据表进行维护  相关字段   报名编号、房产证号、产权人、房产地址、房产证办理时间
        //对material数据表进行维护  即材料文件存储到本地数据库   总个流程：  通过wid  childsn   获取esn
        //材料类型  通过判断字段名 来生成对应的材料类型   材料名称    上传时间   将文件写入文件 并存到服务器物理地址
        //返回物理地址、文件大小    存入数据库
        //esn 通过查询 enroll数据表 通过wid  进行查询
        EnrollExample example1 = new EnrollExample();
        EnrollExample.Criteria criteria1 = example1.createCriteria();
        criteria1.andWidEqualTo(wid);
        criteria1.andBcodeEqualTo(type);
        List<Enroll> list = enrollMapper.selectByExample(example1);
        Long esn = list.get(0).getEsn();   //获取esn报名编号
        //对应接口时再进行编写-------基本数据录入
        Porperty porperty=new Porperty();
        porperty.setEsn(esn);
        Class<?> clazz = houseMsg.getClass();
        //通过判断属性是否为null 进行判断
        //java中遍历实体类，获取属性名和属性值
        String path = "src/main/resources/static/uploadFile/";
        FileAttribute fileAttribute;
        Material material = new Material();
        //直接清空数据库  后续再改
        MaterialExample example3 = new MaterialExample();
        example3.createCriteria().andEsnEqualTo(esn).andMnameNotLike("jsonImgSec%");
        List<Material> list1;
        try {
            materialMapper.deleteByExample(example3);
            for (Field field : houseMsg.getClass().getDeclaredFields()) {
                field.setAccessible(true);////AccessibleTest类中的成员变量为private,故必须进行此操作
                //field.getName()  属性名   field.get(houseMsg)属性值
                if (field.getName().contains("pno") && field.get(houseMsg) != null) {
                    porperty.setPno((String) field.get(houseMsg));
                    continue;
                }
                if (field.getName().contains("address") && field.get(houseMsg) != null) {
                    porperty.setPaddress((String) field.get(houseMsg));
                    continue;
                }

                if (field.getName().contains("icd") && field.get(houseMsg) != null) {
                    porperty.setIcd((String) field.get(houseMsg));
                    continue;
                }

                if (field.getName().contains("jsonImg") && field.get(houseMsg) != null) {
                    switch (field.getName().charAt(7)) {
                        case '1':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("户口簿材料证明图片");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setGuid(new RandomGUID().toString());
                                material.setMname(fileAttribute.getMname());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                log.info(fileAttribute.getMname());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '2':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("房产证材料证明图片");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setGuid(new RandomGUID().toString());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '3':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("无房证明材料图片");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setGuid(new RandomGUID().toString());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '4':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("出生医学证明");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setGuid(new RandomGUID().toString());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                    }
                }
            }
            result.setCode("200");
            log.info("材料数据表维护成功 皖氏通id：" + wid);
            //进行产权表的维护
            PorpertyExample porpertyExample=new PorpertyExample();
            porpertyExample.createCriteria().andEsnEqualTo(esn);
            if(porpertyMapper.selectByExample(porpertyExample).size()==0){
                porpertyMapper.insert(porperty);
            }else{
                porperty.setEsn(null);
                porpertyMapper.updateByExampleSelective(porperty,porpertyExample);
            }
        } catch (Exception e) {
            log.error("遍历HouseMsg属性字段出错或存入数据库出错   ---- 皖氏通id：" + wid);
            result.setCode("500");
        }


        return result;
    }


    @Override
    //根据表单 填充 student表以及学籍表 并通过wid获取报名编号  并通过身份证 获取  性别 、生日
    public Result submitxueji(Student student, String wid, int childsn, String type) {
        //进行修改user——enroll 表中的监护人信息
//        XuejiExample example1 = new XuejiExample();
//        XuejiExample.Criteria criteria2 = example1.createCriteria();
//        criteria2.andSnEqualTo(student.getSn());
        EnrollExample example = new EnrollExample();
        EnrollExample.Criteria criteria = example.createCriteria();
        criteria.andWidEqualTo(wid);
        criteria.andChildsnEqualTo(childsn);
        criteria.andBcodeEqualTo(type);
        List<Enroll> list = enrollMapper.selectByExample(example);
        Long esn = list.get(0).getEsn();   //获取esn报名编号
        student.setEsn(esn);
        StudentExample studentExample = new StudentExample();
        StudentExample.Criteria criteria1 = studentExample.createCriteria();
        criteria1.andEsnEqualTo(student.getEsn());
        String icd = student.getId();//通过身份证 获取性别以及出生年月
        //进行户籍表信息的插入


        try {
            log.info("进入try块");
            student.setBirth(StringToTimestamp.formatTime(IDCardUtil.getBirthday(icd)));//XXXX年XX月XX日的格式
            log.info("日期转换成功");
            student.setSex(IDCardUtil.getSex(icd));
            //判断是否是第一次登录注册过
            if (studentMapper.selectByExample(studentExample).size() == 0) {
                studentMapper.insertSelective(student);//第一次登录该页面为插入操作
                log.info("学生表信息插入成功");
                //进行学籍表信息插入
//                xuejiMapper.insertSelective(xueji);
                log.info("学籍、学生表维护正常------第一次登录  插入操作");
                result.setCode("200");
            } else {
//                xueji.setSn(null);
//                xuejiMapper.updateByExampleSelective(xueji, example1);
                log.info("学籍、学生表维护正常------第二次登录   修改操作");
                student.setEsn(null);
                studentMapper.updateByExampleSelective(student, studentExample);
                //因为非第一次登录进行修改操作
                //进行学籍表修改操作
                result.setCode("200");
            }
        } catch (Exception e) {
            log.error("日期转化错误或者身份证录入不正确或学籍表、学生表维护失败  请查看数据库异常");
            result.setCode("500");
        }


        return result;
    }

    @Override
    //家长信息的录入、关系、监护人信息的录入
    public Result submitfamily(Family family1, Family family2, String wid, String type) {
        //esn 通过查询 enroll数据表 通过wid  进行查询
        EnrollExample example1 = new EnrollExample();
        EnrollExample.Criteria criteria1 = example1.createCriteria();
        criteria1.andWidEqualTo(wid);
        criteria1.andBcodeEqualTo(type);
        List<Enroll> list = enrollMapper.selectByExample(example1);
        Long esn = list.get(0).getEsn();   //获取esn报名编号
        family1.setEsn(esn);
        family2.setEsn(esn);
        family1.setIsjhr(1);//是否为监护人标志
        family2.setIsjhr(1);
        FamilyExample example = new FamilyExample();
        FamilyExample.Criteria criteria = example.createCriteria();
        criteria.andEsnEqualTo(esn);
        List<Family> list1 = familyMapper.selectByExample(example);
        try {
            if (list1.size() == 0) {//判断是否是第一次登录  插入操作
                familyMapper.insertSelective(family1);
                familyMapper.insertSelective(family2);
                log.info("家属、监护人信息录入成功  皖氏通id:" + wid);
                result.setCode("200");
            } else {//对family数据表进行修改
                family1.setFsn(list1.get(0).getFsn());
                family2.setFsn(list1.get(1).getFsn());
                familyMapper.updateByPrimaryKey(family1);
                familyMapper.updateByPrimaryKey(family2);
                log.info("家属、监护人信息修改成功  皖氏通id:" + wid);
                result.setCode("200");
            }
        } catch (Exception e) {
            result.setCode("500");
            log.error("家属、监护人信息录入失败  皖氏通id:" + wid);
        }


        return result;
    }

    //房产信息的录入、证明材料的录入
    @Override   //houseMsg中存储了   11张图片属性    加    房产号及房产地址      而且   还存储了  双选学校信息
    public Result submitHouseMsg(HouseMsg houseMsg, String wid, String type) {
        //通过调用相关接口   对porperty数据表进行维护  相关字段   报名编号、房产证号、产权人、房产地址、房产证办理时间
        //对material数据表进行维护  即材料文件存储到本地数据库   总个流程：  通过wid  childsn   获取esn
        //材料类型  通过判断字段名 来生成对应的材料类型   材料名称    上传时间   将文件写入文件 并存到服务器物理地址
        //返回物理地址、文件大小    存入数据库
        //esn 通过查询 enroll数据表 通过wid  进行查询
        EnrollExample example1 = new EnrollExample();
        EnrollExample.Criteria criteria1 = example1.createCriteria();
        criteria1.andWidEqualTo(wid);
        criteria1.andBcodeEqualTo(type);
        List<Enroll> list = enrollMapper.selectByExample(example1);
        Long esn = list.get(0).getEsn();   //获取esn报名编号
        //对应接口时再进行编写-------基本数据录入
        Porperty porperty=new Porperty();
        porperty.setEsn(esn);
        Class<?> clazz = houseMsg.getClass();
        //通过判断属性是否为null 进行判断
        //java中遍历实体类，获取属性名和属性值
        String path = "src/main/resources/static/uploadFile/";
        FileAttribute fileAttribute;
        Material material = new Material();
        //直接清空数据库  后续再改
        MaterialExample example3 = new MaterialExample();
        example3.createCriteria().andEsnEqualTo(esn).andMnameNotLike("jsonImgSec%");
        List<Material> list1;
        try {
            materialMapper.deleteByExample(example3);
            for (Field field : houseMsg.getClass().getDeclaredFields()) {
                field.setAccessible(true);////AccessibleTest类中的成员变量为private,故必须进行此操作
                //field.getName()  属性名   field.get(houseMsg)属性值
                if (field.getName().contains("pno") && field.get(houseMsg) != null) {
                    porperty.setPno((String) field.get(houseMsg));
                    continue;
                }
                if (field.getName().contains("address") && field.get(houseMsg) != null) {
                    porperty.setPaddress((String) field.get(houseMsg));
                    continue;
                }

                if (field.getName().contains("icd") && field.get(houseMsg) != null) {
                    porperty.setIcd((String) field.get(houseMsg));
                    continue;
                }

                if (field.getName().contains("jsonImg") && field.get(houseMsg) != null) {
                    switch (field.getName().charAt(7)) {
                        case '1':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("户口簿材料证明图片");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setGuid(new RandomGUID().toString());
                                material.setMname(fileAttribute.getMname());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                log.info(fileAttribute.getMname());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '2':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("出生医学证明");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setGuid(new RandomGUID().toString());
                                material.setMsize(fileAttribute.getMsize());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '3':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("房产证材料证明图片");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setMsize(fileAttribute.getMsize());
                                material.setGuid(new RandomGUID().toString());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                        case '4':
                            fileAttribute = FiletoGetAbs.filetoGetAbs((String) field.get(houseMsg), path + esn, field.getName());
                            material.setMtype("居住证明材料证明图片");
                            //执行存入数据库操作
                            if (fileAttribute.getCode() == 200) {
                                material.setAddress(fileAttribute.getAddress());
                                material.setEsn(esn);
                                material.setMname(fileAttribute.getMname());
                                material.setMsize(fileAttribute.getMsize());
                                material.setGuid(new RandomGUID().toString());
                                material.setUptime(fileAttribute.getUptime());
                                MaterialExample example = new MaterialExample();
                                MaterialExample.Criteria criteria;
                                criteria = example.createCriteria();
                                log.info(fileAttribute.getMname());
                                criteria.andMnameEqualTo(fileAttribute.getMname());
                                criteria.andEsnEqualTo(esn);
                                list1 = materialMapper.selectByExample(example);
                                log.info(String.valueOf(list1.size()));
                                if (list1.size() == 0) {//如果数据库没有该文件则进行插入
                                    materialMapper.insertSelective(material);//进行材料数据表的插入操作
                                    log.info("材料数据表维护成功 --插入操作 材料名称：" + fileAttribute.getMname());
                                } else {
                                    //更新数据库
                                    material.setMname(null);
                                    material.setEsn(null);
                                    if (fileAttribute.getMsize() != list1.get(0).getMsize()) {
                                        materialMapper.updateByExampleSelective(material, example);//进行材料表的更新
                                        log.info("材料数据表维护成功 --更新操作 材料名称：" + fileAttribute.getMname());
                                    }


                                }

                            }
                            break;
                    }


                }
            }
            result.setCode("200");
            log.info("材料数据表维护成功 皖氏通id：" + wid);
            //进行产权表的维护
            PorpertyExample porpertyExample=new PorpertyExample();
            porpertyExample.createCriteria().andEsnEqualTo(esn);
            if(porpertyMapper.selectByExample(porpertyExample).size()==0){
                porpertyMapper.insert(porperty);
            }else{
                porperty.setEsn(null);
                porpertyMapper.updateByExampleSelective(porperty,porpertyExample);
            }
        } catch (Exception e) {
            log.error("遍历HouseMsg属性字段出错或存入数据库出错   ---- 皖氏通id：" + wid);
            result.setCode("500");
        }


        return result;
    }

    @Override ////修改个人信息、  手机号、所在区、家庭孩子数、孩子是单体摇号还是整体摇号
    public Result checkfirst(UserRoll userRoll, String wid) {
        UserRollExample example = new UserRollExample();
        example.createCriteria().andWidEqualTo(wid);
        try {
            userRollMapper.updateByExampleSelective(userRoll, example);
            log.info("修改个人信息成功   皖氏通id：" + wid);
            result.setCode("200");
        } catch (Exception e) {
            log.info("修改个人信息失败   皖氏通id：" + wid);
            result.setCode("500");
        }

        return result;
    }


}
