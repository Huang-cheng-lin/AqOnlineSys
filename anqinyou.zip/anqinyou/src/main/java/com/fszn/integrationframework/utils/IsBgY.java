package com.fszn.integrationframework.utils;

public class IsBgY {
    public static final String[] array={"迎江御墅","钻石郡小区","山水云间","1号公园","秦潭凤舞小区"};
    public static boolean returnflag(String s) {
        Boolean flag1 = false;
        if (s != null) {
            for (int i = 0; i < array.length; i++) {
                if (s.contains(array[i])) {
                    flag1 = true;
                    break;
                }
            }
        }
        return flag1;
    }
}
