package com.fszn.integrationframework.domain;

import java.util.ArrayList;
import java.util.List;

public class SchoolDistrictExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public SchoolDistrictExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andDsnIsNull() {
            addCriterion("dsn is null");
            return (Criteria) this;
        }

        public Criteria andDsnIsNotNull() {
            addCriterion("dsn is not null");
            return (Criteria) this;
        }

        public Criteria andDsnEqualTo(Integer value) {
            addCriterion("dsn =", value, "dsn");
            return (Criteria) this;
        }

        public Criteria andDsnNotEqualTo(Integer value) {
            addCriterion("dsn <>", value, "dsn");
            return (Criteria) this;
        }

        public Criteria andDsnGreaterThan(Integer value) {
            addCriterion("dsn >", value, "dsn");
            return (Criteria) this;
        }

        public Criteria andDsnGreaterThanOrEqualTo(Integer value) {
            addCriterion("dsn >=", value, "dsn");
            return (Criteria) this;
        }

        public Criteria andDsnLessThan(Integer value) {
            addCriterion("dsn <", value, "dsn");
            return (Criteria) this;
        }

        public Criteria andDsnLessThanOrEqualTo(Integer value) {
            addCriterion("dsn <=", value, "dsn");
            return (Criteria) this;
        }

        public Criteria andDsnIn(List<Integer> values) {
            addCriterion("dsn in", values, "dsn");
            return (Criteria) this;
        }

        public Criteria andDsnNotIn(List<Integer> values) {
            addCriterion("dsn not in", values, "dsn");
            return (Criteria) this;
        }

        public Criteria andDsnBetween(Integer value1, Integer value2) {
            addCriterion("dsn between", value1, value2, "dsn");
            return (Criteria) this;
        }

        public Criteria andDsnNotBetween(Integer value1, Integer value2) {
            addCriterion("dsn not between", value1, value2, "dsn");
            return (Criteria) this;
        }

        public Criteria andDnameIsNull() {
            addCriterion("dname is null");
            return (Criteria) this;
        }

        public Criteria andDnameIsNotNull() {
            addCriterion("dname is not null");
            return (Criteria) this;
        }

        public Criteria andDnameEqualTo(String value) {
            addCriterion("dname =", value, "dname");
            return (Criteria) this;
        }

        public Criteria andDnameNotEqualTo(String value) {
            addCriterion("dname <>", value, "dname");
            return (Criteria) this;
        }

        public Criteria andDnameGreaterThan(String value) {
            addCriterion("dname >", value, "dname");
            return (Criteria) this;
        }

        public Criteria andDnameGreaterThanOrEqualTo(String value) {
            addCriterion("dname >=", value, "dname");
            return (Criteria) this;
        }

        public Criteria andDnameLessThan(String value) {
            addCriterion("dname <", value, "dname");
            return (Criteria) this;
        }

        public Criteria andDnameLessThanOrEqualTo(String value) {
            addCriterion("dname <=", value, "dname");
            return (Criteria) this;
        }

        public Criteria andDnameLike(String value) {
            addCriterion("dname like", value, "dname");
            return (Criteria) this;
        }

        public Criteria andDnameNotLike(String value) {
            addCriterion("dname not like", value, "dname");
            return (Criteria) this;
        }

        public Criteria andDnameIn(List<String> values) {
            addCriterion("dname in", values, "dname");
            return (Criteria) this;
        }

        public Criteria andDnameNotIn(List<String> values) {
            addCriterion("dname not in", values, "dname");
            return (Criteria) this;
        }

        public Criteria andDnameBetween(String value1, String value2) {
            addCriterion("dname between", value1, value2, "dname");
            return (Criteria) this;
        }

        public Criteria andDnameNotBetween(String value1, String value2) {
            addCriterion("dname not between", value1, value2, "dname");
            return (Criteria) this;
        }

        public Criteria andDescriptionIsNull() {
            addCriterion("description is null");
            return (Criteria) this;
        }

        public Criteria andDescriptionIsNotNull() {
            addCriterion("description is not null");
            return (Criteria) this;
        }

        public Criteria andDescriptionEqualTo(String value) {
            addCriterion("description =", value, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionNotEqualTo(String value) {
            addCriterion("description <>", value, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionGreaterThan(String value) {
            addCriterion("description >", value, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionGreaterThanOrEqualTo(String value) {
            addCriterion("description >=", value, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionLessThan(String value) {
            addCriterion("description <", value, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionLessThanOrEqualTo(String value) {
            addCriterion("description <=", value, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionLike(String value) {
            addCriterion("description like", value, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionNotLike(String value) {
            addCriterion("description not like", value, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionIn(List<String> values) {
            addCriterion("description in", values, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionNotIn(List<String> values) {
            addCriterion("description not in", values, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionBetween(String value1, String value2) {
            addCriterion("description between", value1, value2, "description");
            return (Criteria) this;
        }

        public Criteria andDescriptionNotBetween(String value1, String value2) {
            addCriterion("description not between", value1, value2, "description");
            return (Criteria) this;
        }

        public Criteria andDyearIsNull() {
            addCriterion("dyear is null");
            return (Criteria) this;
        }

        public Criteria andDyearIsNotNull() {
            addCriterion("dyear is not null");
            return (Criteria) this;
        }

        public Criteria andDyearEqualTo(Integer value) {
            addCriterion("dyear =", value, "dyear");
            return (Criteria) this;
        }

        public Criteria andDyearNotEqualTo(Integer value) {
            addCriterion("dyear <>", value, "dyear");
            return (Criteria) this;
        }

        public Criteria andDyearGreaterThan(Integer value) {
            addCriterion("dyear >", value, "dyear");
            return (Criteria) this;
        }

        public Criteria andDyearGreaterThanOrEqualTo(Integer value) {
            addCriterion("dyear >=", value, "dyear");
            return (Criteria) this;
        }

        public Criteria andDyearLessThan(Integer value) {
            addCriterion("dyear <", value, "dyear");
            return (Criteria) this;
        }

        public Criteria andDyearLessThanOrEqualTo(Integer value) {
            addCriterion("dyear <=", value, "dyear");
            return (Criteria) this;
        }

        public Criteria andDyearIn(List<Integer> values) {
            addCriterion("dyear in", values, "dyear");
            return (Criteria) this;
        }

        public Criteria andDyearNotIn(List<Integer> values) {
            addCriterion("dyear not in", values, "dyear");
            return (Criteria) this;
        }

        public Criteria andDyearBetween(Integer value1, Integer value2) {
            addCriterion("dyear between", value1, value2, "dyear");
            return (Criteria) this;
        }

        public Criteria andDyearNotBetween(Integer value1, Integer value2) {
            addCriterion("dyear not between", value1, value2, "dyear");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}