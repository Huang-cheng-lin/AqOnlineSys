package com.fszn.integrationframework.dao;

import com.fszn.integrationframework.domain.EnrollType;
import com.fszn.integrationframework.domain.EnrollTypeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface EnrollTypeMapper {
    long countByExample(EnrollTypeExample example);

    int deleteByExample(EnrollTypeExample example);

    int deleteByPrimaryKey(String bcode);

    int insert(EnrollType record);

    int insertSelective(EnrollType record);

    List<EnrollType> selectByExample(EnrollTypeExample example);

    EnrollType selectByPrimaryKey(String bcode);

    int updateByExampleSelective(@Param("record") EnrollType record, @Param("example") EnrollTypeExample example);

    int updateByExample(@Param("record") EnrollType record, @Param("example") EnrollTypeExample example);

    int updateByPrimaryKeySelective(EnrollType record);

    int updateByPrimaryKey(EnrollType record);
}