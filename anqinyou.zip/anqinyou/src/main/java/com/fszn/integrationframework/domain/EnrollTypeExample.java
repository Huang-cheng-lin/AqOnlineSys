package com.fszn.integrationframework.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EnrollTypeExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public EnrollTypeExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andBcodeIsNull() {
            addCriterion("bcode is null");
            return (Criteria) this;
        }

        public Criteria andBcodeIsNotNull() {
            addCriterion("bcode is not null");
            return (Criteria) this;
        }

        public Criteria andBcodeEqualTo(String value) {
            addCriterion("bcode =", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeNotEqualTo(String value) {
            addCriterion("bcode <>", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeGreaterThan(String value) {
            addCriterion("bcode >", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeGreaterThanOrEqualTo(String value) {
            addCriterion("bcode >=", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeLessThan(String value) {
            addCriterion("bcode <", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeLessThanOrEqualTo(String value) {
            addCriterion("bcode <=", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeLike(String value) {
            addCriterion("bcode like", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeNotLike(String value) {
            addCriterion("bcode not like", value, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeIn(List<String> values) {
            addCriterion("bcode in", values, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeNotIn(List<String> values) {
            addCriterion("bcode not in", values, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeBetween(String value1, String value2) {
            addCriterion("bcode between", value1, value2, "bcode");
            return (Criteria) this;
        }

        public Criteria andBcodeNotBetween(String value1, String value2) {
            addCriterion("bcode not between", value1, value2, "bcode");
            return (Criteria) this;
        }

        public Criteria andBtypeIsNull() {
            addCriterion("btype is null");
            return (Criteria) this;
        }

        public Criteria andBtypeIsNotNull() {
            addCriterion("btype is not null");
            return (Criteria) this;
        }

        public Criteria andBtypeEqualTo(String value) {
            addCriterion("btype =", value, "btype");
            return (Criteria) this;
        }

        public Criteria andBtypeNotEqualTo(String value) {
            addCriterion("btype <>", value, "btype");
            return (Criteria) this;
        }

        public Criteria andBtypeGreaterThan(String value) {
            addCriterion("btype >", value, "btype");
            return (Criteria) this;
        }

        public Criteria andBtypeGreaterThanOrEqualTo(String value) {
            addCriterion("btype >=", value, "btype");
            return (Criteria) this;
        }

        public Criteria andBtypeLessThan(String value) {
            addCriterion("btype <", value, "btype");
            return (Criteria) this;
        }

        public Criteria andBtypeLessThanOrEqualTo(String value) {
            addCriterion("btype <=", value, "btype");
            return (Criteria) this;
        }

        public Criteria andBtypeLike(String value) {
            addCriterion("btype like", value, "btype");
            return (Criteria) this;
        }

        public Criteria andBtypeNotLike(String value) {
            addCriterion("btype not like", value, "btype");
            return (Criteria) this;
        }

        public Criteria andBtypeIn(List<String> values) {
            addCriterion("btype in", values, "btype");
            return (Criteria) this;
        }

        public Criteria andBtypeNotIn(List<String> values) {
            addCriterion("btype not in", values, "btype");
            return (Criteria) this;
        }

        public Criteria andBtypeBetween(String value1, String value2) {
            addCriterion("btype between", value1, value2, "btype");
            return (Criteria) this;
        }

        public Criteria andBtypeNotBetween(String value1, String value2) {
            addCriterion("btype not between", value1, value2, "btype");
            return (Criteria) this;
        }

        public Criteria andBtimeIsNull() {
            addCriterion("btime is null");
            return (Criteria) this;
        }

        public Criteria andBtimeIsNotNull() {
            addCriterion("btime is not null");
            return (Criteria) this;
        }

        public Criteria andBtimeEqualTo(Date value) {
            addCriterion("btime =", value, "btime");
            return (Criteria) this;
        }

        public Criteria andBtimeNotEqualTo(Date value) {
            addCriterion("btime <>", value, "btime");
            return (Criteria) this;
        }

        public Criteria andBtimeGreaterThan(Date value) {
            addCriterion("btime >", value, "btime");
            return (Criteria) this;
        }

        public Criteria andBtimeGreaterThanOrEqualTo(Date value) {
            addCriterion("btime >=", value, "btime");
            return (Criteria) this;
        }

        public Criteria andBtimeLessThan(Date value) {
            addCriterion("btime <", value, "btime");
            return (Criteria) this;
        }

        public Criteria andBtimeLessThanOrEqualTo(Date value) {
            addCriterion("btime <=", value, "btime");
            return (Criteria) this;
        }

        public Criteria andBtimeIn(List<Date> values) {
            addCriterion("btime in", values, "btime");
            return (Criteria) this;
        }

        public Criteria andBtimeNotIn(List<Date> values) {
            addCriterion("btime not in", values, "btime");
            return (Criteria) this;
        }

        public Criteria andBtimeBetween(Date value1, Date value2) {
            addCriterion("btime between", value1, value2, "btime");
            return (Criteria) this;
        }

        public Criteria andBtimeNotBetween(Date value1, Date value2) {
            addCriterion("btime not between", value1, value2, "btime");
            return (Criteria) this;
        }

        public Criteria andEtimeIsNull() {
            addCriterion("etime is null");
            return (Criteria) this;
        }

        public Criteria andEtimeIsNotNull() {
            addCriterion("etime is not null");
            return (Criteria) this;
        }

        public Criteria andEtimeEqualTo(Date value) {
            addCriterion("etime =", value, "etime");
            return (Criteria) this;
        }

        public Criteria andEtimeNotEqualTo(Date value) {
            addCriterion("etime <>", value, "etime");
            return (Criteria) this;
        }

        public Criteria andEtimeGreaterThan(Date value) {
            addCriterion("etime >", value, "etime");
            return (Criteria) this;
        }

        public Criteria andEtimeGreaterThanOrEqualTo(Date value) {
            addCriterion("etime >=", value, "etime");
            return (Criteria) this;
        }

        public Criteria andEtimeLessThan(Date value) {
            addCriterion("etime <", value, "etime");
            return (Criteria) this;
        }

        public Criteria andEtimeLessThanOrEqualTo(Date value) {
            addCriterion("etime <=", value, "etime");
            return (Criteria) this;
        }

        public Criteria andEtimeIn(List<Date> values) {
            addCriterion("etime in", values, "etime");
            return (Criteria) this;
        }

        public Criteria andEtimeNotIn(List<Date> values) {
            addCriterion("etime not in", values, "etime");
            return (Criteria) this;
        }

        public Criteria andEtimeBetween(Date value1, Date value2) {
            addCriterion("etime between", value1, value2, "etime");
            return (Criteria) this;
        }

        public Criteria andEtimeNotBetween(Date value1, Date value2) {
            addCriterion("etime not between", value1, value2, "etime");
            return (Criteria) this;
        }

        public Criteria andBtime1IsNull() {
            addCriterion("btime1 is null");
            return (Criteria) this;
        }

        public Criteria andBtime1IsNotNull() {
            addCriterion("btime1 is not null");
            return (Criteria) this;
        }

        public Criteria andBtime1EqualTo(Date value) {
            addCriterion("btime1 =", value, "btime1");
            return (Criteria) this;
        }

        public Criteria andBtime1NotEqualTo(Date value) {
            addCriterion("btime1 <>", value, "btime1");
            return (Criteria) this;
        }

        public Criteria andBtime1GreaterThan(Date value) {
            addCriterion("btime1 >", value, "btime1");
            return (Criteria) this;
        }

        public Criteria andBtime1GreaterThanOrEqualTo(Date value) {
            addCriterion("btime1 >=", value, "btime1");
            return (Criteria) this;
        }

        public Criteria andBtime1LessThan(Date value) {
            addCriterion("btime1 <", value, "btime1");
            return (Criteria) this;
        }

        public Criteria andBtime1LessThanOrEqualTo(Date value) {
            addCriterion("btime1 <=", value, "btime1");
            return (Criteria) this;
        }

        public Criteria andBtime1In(List<Date> values) {
            addCriterion("btime1 in", values, "btime1");
            return (Criteria) this;
        }

        public Criteria andBtime1NotIn(List<Date> values) {
            addCriterion("btime1 not in", values, "btime1");
            return (Criteria) this;
        }

        public Criteria andBtime1Between(Date value1, Date value2) {
            addCriterion("btime1 between", value1, value2, "btime1");
            return (Criteria) this;
        }

        public Criteria andBtime1NotBetween(Date value1, Date value2) {
            addCriterion("btime1 not between", value1, value2, "btime1");
            return (Criteria) this;
        }

        public Criteria andEtime1IsNull() {
            addCriterion("etime1 is null");
            return (Criteria) this;
        }

        public Criteria andEtime1IsNotNull() {
            addCriterion("etime1 is not null");
            return (Criteria) this;
        }

        public Criteria andEtime1EqualTo(Date value) {
            addCriterion("etime1 =", value, "etime1");
            return (Criteria) this;
        }

        public Criteria andEtime1NotEqualTo(Date value) {
            addCriterion("etime1 <>", value, "etime1");
            return (Criteria) this;
        }

        public Criteria andEtime1GreaterThan(Date value) {
            addCriterion("etime1 >", value, "etime1");
            return (Criteria) this;
        }

        public Criteria andEtime1GreaterThanOrEqualTo(Date value) {
            addCriterion("etime1 >=", value, "etime1");
            return (Criteria) this;
        }

        public Criteria andEtime1LessThan(Date value) {
            addCriterion("etime1 <", value, "etime1");
            return (Criteria) this;
        }

        public Criteria andEtime1LessThanOrEqualTo(Date value) {
            addCriterion("etime1 <=", value, "etime1");
            return (Criteria) this;
        }

        public Criteria andEtime1In(List<Date> values) {
            addCriterion("etime1 in", values, "etime1");
            return (Criteria) this;
        }

        public Criteria andEtime1NotIn(List<Date> values) {
            addCriterion("etime1 not in", values, "etime1");
            return (Criteria) this;
        }

        public Criteria andEtime1Between(Date value1, Date value2) {
            addCriterion("etime1 between", value1, value2, "etime1");
            return (Criteria) this;
        }

        public Criteria andEtime1NotBetween(Date value1, Date value2) {
            addCriterion("etime1 not between", value1, value2, "etime1");
            return (Criteria) this;
        }

        public Criteria andLuquwayIsNull() {
            addCriterion("luquway is null");
            return (Criteria) this;
        }

        public Criteria andLuquwayIsNotNull() {
            addCriterion("luquway is not null");
            return (Criteria) this;
        }

        public Criteria andLuquwayEqualTo(String value) {
            addCriterion("luquway =", value, "luquway");
            return (Criteria) this;
        }

        public Criteria andLuquwayNotEqualTo(String value) {
            addCriterion("luquway <>", value, "luquway");
            return (Criteria) this;
        }

        public Criteria andLuquwayGreaterThan(String value) {
            addCriterion("luquway >", value, "luquway");
            return (Criteria) this;
        }

        public Criteria andLuquwayGreaterThanOrEqualTo(String value) {
            addCriterion("luquway >=", value, "luquway");
            return (Criteria) this;
        }

        public Criteria andLuquwayLessThan(String value) {
            addCriterion("luquway <", value, "luquway");
            return (Criteria) this;
        }

        public Criteria andLuquwayLessThanOrEqualTo(String value) {
            addCriterion("luquway <=", value, "luquway");
            return (Criteria) this;
        }

        public Criteria andLuquwayLike(String value) {
            addCriterion("luquway like", value, "luquway");
            return (Criteria) this;
        }

        public Criteria andLuquwayNotLike(String value) {
            addCriterion("luquway not like", value, "luquway");
            return (Criteria) this;
        }

        public Criteria andLuquwayIn(List<String> values) {
            addCriterion("luquway in", values, "luquway");
            return (Criteria) this;
        }

        public Criteria andLuquwayNotIn(List<String> values) {
            addCriterion("luquway not in", values, "luquway");
            return (Criteria) this;
        }

        public Criteria andLuquwayBetween(String value1, String value2) {
            addCriterion("luquway between", value1, value2, "luquway");
            return (Criteria) this;
        }

        public Criteria andLuquwayNotBetween(String value1, String value2) {
            addCriterion("luquway not between", value1, value2, "luquway");
            return (Criteria) this;
        }

        public Criteria andNoteIsNull() {
            addCriterion("note is null");
            return (Criteria) this;
        }

        public Criteria andNoteIsNotNull() {
            addCriterion("note is not null");
            return (Criteria) this;
        }

        public Criteria andNoteEqualTo(String value) {
            addCriterion("note =", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotEqualTo(String value) {
            addCriterion("note <>", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteGreaterThan(String value) {
            addCriterion("note >", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteGreaterThanOrEqualTo(String value) {
            addCriterion("note >=", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteLessThan(String value) {
            addCriterion("note <", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteLessThanOrEqualTo(String value) {
            addCriterion("note <=", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteLike(String value) {
            addCriterion("note like", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotLike(String value) {
            addCriterion("note not like", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteIn(List<String> values) {
            addCriterion("note in", values, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotIn(List<String> values) {
            addCriterion("note not in", values, "note");
            return (Criteria) this;
        }

        public Criteria andNoteBetween(String value1, String value2) {
            addCriterion("note between", value1, value2, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotBetween(String value1, String value2) {
            addCriterion("note not between", value1, value2, "note");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}