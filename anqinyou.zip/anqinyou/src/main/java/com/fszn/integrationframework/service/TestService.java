package com.fszn.integrationframework.service;

import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface TestService {
    void testFlag();
}
