package com.fszn.integrationframework.dao;

import com.fszn.integrationframework.domain.Enroll;
import com.fszn.integrationframework.domain.EnrollExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface EnrollMapper {
    long countByExample(EnrollExample example);

    int deleteByExample(EnrollExample example);

    int deleteByPrimaryKey(Long esn);

    int insert(Enroll record);

    int insertSelective(Enroll record);

    List<Enroll> selectByExample(EnrollExample example);

    Enroll selectByPrimaryKey(Long esn);

    int updateByExampleSelective(@Param("record") Enroll record, @Param("example") EnrollExample example);

    int updateByExample(@Param("record") Enroll record, @Param("example") EnrollExample example);

    int updateByPrimaryKeySelective(Enroll record);

    int updateByPrimaryKey(Enroll record);
}