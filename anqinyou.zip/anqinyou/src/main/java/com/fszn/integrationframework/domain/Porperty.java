package com.fszn.integrationframework.domain;

import java.util.Date;

public class Porperty {
    private Long psn;

    private Long esn;

    private String pno;

    private String owners;

    private String paddress;

    private Date pdt;

    private String icd;

    public Long getPsn() {
        return psn;
    }

    public void setPsn(Long psn) {
        this.psn = psn;
    }

    public Long getEsn() {
        return esn;
    }

    public void setEsn(Long esn) {
        this.esn = esn;
    }

    public String getPno() {
        return pno;
    }

    public void setPno(String pno) {
        this.pno = pno == null ? null : pno.trim();
    }

    public String getOwners() {
        return owners;
    }

    public void setOwners(String owners) {
        this.owners = owners == null ? null : owners.trim();
    }

    public String getPaddress() {
        return paddress;
    }

    public void setPaddress(String paddress) {
        this.paddress = paddress == null ? null : paddress.trim();
    }

    public Date getPdt() {
        return pdt;
    }

    public void setPdt(Date pdt) {
        this.pdt = pdt;
    }

    public String getIcd() {
        return icd;
    }

    public void setIcd(String icd) {
        this.icd = icd == null ? null : icd.trim();
    }
}