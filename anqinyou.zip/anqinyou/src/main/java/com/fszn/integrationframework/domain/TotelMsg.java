package com.fszn.integrationframework.domain;

import java.util.ArrayList;
import java.util.List;

public class TotelMsg {
    private String aname;//选区
    private Enroll enroll;//孩子的报名信息
    private List<Student> student;

    public String getAname() {
        return aname;
    }

    public void setAname(String aname) {
        this.aname = aname;
    }

    public Enroll getEnroll() {
        return enroll;
    }

    public void setEnroll(Enroll enroll) {
        this.enroll = enroll;
    }

    public List<Student> getStudent() {
        return student;
    }

    public void setStudent(List<Student> student) {
        this.student = student;
    }
}
