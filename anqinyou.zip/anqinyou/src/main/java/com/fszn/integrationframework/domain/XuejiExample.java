package com.fszn.integrationframework.domain;

import java.util.ArrayList;
import java.util.List;

public class XuejiExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public XuejiExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andXsnIsNull() {
            addCriterion("xsn is null");
            return (Criteria) this;
        }

        public Criteria andXsnIsNotNull() {
            addCriterion("xsn is not null");
            return (Criteria) this;
        }

        public Criteria andXsnEqualTo(Integer value) {
            addCriterion("xsn =", value, "xsn");
            return (Criteria) this;
        }

        public Criteria andXsnNotEqualTo(Integer value) {
            addCriterion("xsn <>", value, "xsn");
            return (Criteria) this;
        }

        public Criteria andXsnGreaterThan(Integer value) {
            addCriterion("xsn >", value, "xsn");
            return (Criteria) this;
        }

        public Criteria andXsnGreaterThanOrEqualTo(Integer value) {
            addCriterion("xsn >=", value, "xsn");
            return (Criteria) this;
        }

        public Criteria andXsnLessThan(Integer value) {
            addCriterion("xsn <", value, "xsn");
            return (Criteria) this;
        }

        public Criteria andXsnLessThanOrEqualTo(Integer value) {
            addCriterion("xsn <=", value, "xsn");
            return (Criteria) this;
        }

        public Criteria andXsnIn(List<Integer> values) {
            addCriterion("xsn in", values, "xsn");
            return (Criteria) this;
        }

        public Criteria andXsnNotIn(List<Integer> values) {
            addCriterion("xsn not in", values, "xsn");
            return (Criteria) this;
        }

        public Criteria andXsnBetween(Integer value1, Integer value2) {
            addCriterion("xsn between", value1, value2, "xsn");
            return (Criteria) this;
        }

        public Criteria andXsnNotBetween(Integer value1, Integer value2) {
            addCriterion("xsn not between", value1, value2, "xsn");
            return (Criteria) this;
        }

        public Criteria andSnIsNull() {
            addCriterion("sn is null");
            return (Criteria) this;
        }

        public Criteria andSnIsNotNull() {
            addCriterion("sn is not null");
            return (Criteria) this;
        }

        public Criteria andSnEqualTo(Long value) {
            addCriterion("sn =", value, "sn");
            return (Criteria) this;
        }

        public Criteria andSnNotEqualTo(Long value) {
            addCriterion("sn <>", value, "sn");
            return (Criteria) this;
        }

        public Criteria andSnGreaterThan(Long value) {
            addCriterion("sn >", value, "sn");
            return (Criteria) this;
        }

        public Criteria andSnGreaterThanOrEqualTo(Long value) {
            addCriterion("sn >=", value, "sn");
            return (Criteria) this;
        }

        public Criteria andSnLessThan(Long value) {
            addCriterion("sn <", value, "sn");
            return (Criteria) this;
        }

        public Criteria andSnLessThanOrEqualTo(Long value) {
            addCriterion("sn <=", value, "sn");
            return (Criteria) this;
        }

        public Criteria andSnIn(List<Long> values) {
            addCriterion("sn in", values, "sn");
            return (Criteria) this;
        }

        public Criteria andSnNotIn(List<Long> values) {
            addCriterion("sn not in", values, "sn");
            return (Criteria) this;
        }

        public Criteria andSnBetween(Long value1, Long value2) {
            addCriterion("sn between", value1, value2, "sn");
            return (Criteria) this;
        }

        public Criteria andSnNotBetween(Long value1, Long value2) {
            addCriterion("sn not between", value1, value2, "sn");
            return (Criteria) this;
        }

        public Criteria andXareaIsNull() {
            addCriterion("xarea is null");
            return (Criteria) this;
        }

        public Criteria andXareaIsNotNull() {
            addCriterion("xarea is not null");
            return (Criteria) this;
        }

        public Criteria andXareaEqualTo(String value) {
            addCriterion("xarea =", value, "xarea");
            return (Criteria) this;
        }

        public Criteria andXareaNotEqualTo(String value) {
            addCriterion("xarea <>", value, "xarea");
            return (Criteria) this;
        }

        public Criteria andXareaGreaterThan(String value) {
            addCriterion("xarea >", value, "xarea");
            return (Criteria) this;
        }

        public Criteria andXareaGreaterThanOrEqualTo(String value) {
            addCriterion("xarea >=", value, "xarea");
            return (Criteria) this;
        }

        public Criteria andXareaLessThan(String value) {
            addCriterion("xarea <", value, "xarea");
            return (Criteria) this;
        }

        public Criteria andXareaLessThanOrEqualTo(String value) {
            addCriterion("xarea <=", value, "xarea");
            return (Criteria) this;
        }

        public Criteria andXareaLike(String value) {
            addCriterion("xarea like", value, "xarea");
            return (Criteria) this;
        }

        public Criteria andXareaNotLike(String value) {
            addCriterion("xarea not like", value, "xarea");
            return (Criteria) this;
        }

        public Criteria andXareaIn(List<String> values) {
            addCriterion("xarea in", values, "xarea");
            return (Criteria) this;
        }

        public Criteria andXareaNotIn(List<String> values) {
            addCriterion("xarea not in", values, "xarea");
            return (Criteria) this;
        }

        public Criteria andXareaBetween(String value1, String value2) {
            addCriterion("xarea between", value1, value2, "xarea");
            return (Criteria) this;
        }

        public Criteria andXareaNotBetween(String value1, String value2) {
            addCriterion("xarea not between", value1, value2, "xarea");
            return (Criteria) this;
        }

        public Criteria andXschoolIsNull() {
            addCriterion("xschool is null");
            return (Criteria) this;
        }

        public Criteria andXschoolIsNotNull() {
            addCriterion("xschool is not null");
            return (Criteria) this;
        }

        public Criteria andXschoolEqualTo(String value) {
            addCriterion("xschool =", value, "xschool");
            return (Criteria) this;
        }

        public Criteria andXschoolNotEqualTo(String value) {
            addCriterion("xschool <>", value, "xschool");
            return (Criteria) this;
        }

        public Criteria andXschoolGreaterThan(String value) {
            addCriterion("xschool >", value, "xschool");
            return (Criteria) this;
        }

        public Criteria andXschoolGreaterThanOrEqualTo(String value) {
            addCriterion("xschool >=", value, "xschool");
            return (Criteria) this;
        }

        public Criteria andXschoolLessThan(String value) {
            addCriterion("xschool <", value, "xschool");
            return (Criteria) this;
        }

        public Criteria andXschoolLessThanOrEqualTo(String value) {
            addCriterion("xschool <=", value, "xschool");
            return (Criteria) this;
        }

        public Criteria andXschoolLike(String value) {
            addCriterion("xschool like", value, "xschool");
            return (Criteria) this;
        }

        public Criteria andXschoolNotLike(String value) {
            addCriterion("xschool not like", value, "xschool");
            return (Criteria) this;
        }

        public Criteria andXschoolIn(List<String> values) {
            addCriterion("xschool in", values, "xschool");
            return (Criteria) this;
        }

        public Criteria andXschoolNotIn(List<String> values) {
            addCriterion("xschool not in", values, "xschool");
            return (Criteria) this;
        }

        public Criteria andXschoolBetween(String value1, String value2) {
            addCriterion("xschool between", value1, value2, "xschool");
            return (Criteria) this;
        }

        public Criteria andXschoolNotBetween(String value1, String value2) {
            addCriterion("xschool not between", value1, value2, "xschool");
            return (Criteria) this;
        }

        public Criteria andGradeclassIsNull() {
            addCriterion("gradeclass is null");
            return (Criteria) this;
        }

        public Criteria andGradeclassIsNotNull() {
            addCriterion("gradeclass is not null");
            return (Criteria) this;
        }

        public Criteria andGradeclassEqualTo(String value) {
            addCriterion("gradeclass =", value, "gradeclass");
            return (Criteria) this;
        }

        public Criteria andGradeclassNotEqualTo(String value) {
            addCriterion("gradeclass <>", value, "gradeclass");
            return (Criteria) this;
        }

        public Criteria andGradeclassGreaterThan(String value) {
            addCriterion("gradeclass >", value, "gradeclass");
            return (Criteria) this;
        }

        public Criteria andGradeclassGreaterThanOrEqualTo(String value) {
            addCriterion("gradeclass >=", value, "gradeclass");
            return (Criteria) this;
        }

        public Criteria andGradeclassLessThan(String value) {
            addCriterion("gradeclass <", value, "gradeclass");
            return (Criteria) this;
        }

        public Criteria andGradeclassLessThanOrEqualTo(String value) {
            addCriterion("gradeclass <=", value, "gradeclass");
            return (Criteria) this;
        }

        public Criteria andGradeclassLike(String value) {
            addCriterion("gradeclass like", value, "gradeclass");
            return (Criteria) this;
        }

        public Criteria andGradeclassNotLike(String value) {
            addCriterion("gradeclass not like", value, "gradeclass");
            return (Criteria) this;
        }

        public Criteria andGradeclassIn(List<String> values) {
            addCriterion("gradeclass in", values, "gradeclass");
            return (Criteria) this;
        }

        public Criteria andGradeclassNotIn(List<String> values) {
            addCriterion("gradeclass not in", values, "gradeclass");
            return (Criteria) this;
        }

        public Criteria andGradeclassBetween(String value1, String value2) {
            addCriterion("gradeclass between", value1, value2, "gradeclass");
            return (Criteria) this;
        }

        public Criteria andGradeclassNotBetween(String value1, String value2) {
            addCriterion("gradeclass not between", value1, value2, "gradeclass");
            return (Criteria) this;
        }

        public Criteria andXnoIsNull() {
            addCriterion("xno is null");
            return (Criteria) this;
        }

        public Criteria andXnoIsNotNull() {
            addCriterion("xno is not null");
            return (Criteria) this;
        }

        public Criteria andXnoEqualTo(String value) {
            addCriterion("xno =", value, "xno");
            return (Criteria) this;
        }

        public Criteria andXnoNotEqualTo(String value) {
            addCriterion("xno <>", value, "xno");
            return (Criteria) this;
        }

        public Criteria andXnoGreaterThan(String value) {
            addCriterion("xno >", value, "xno");
            return (Criteria) this;
        }

        public Criteria andXnoGreaterThanOrEqualTo(String value) {
            addCriterion("xno >=", value, "xno");
            return (Criteria) this;
        }

        public Criteria andXnoLessThan(String value) {
            addCriterion("xno <", value, "xno");
            return (Criteria) this;
        }

        public Criteria andXnoLessThanOrEqualTo(String value) {
            addCriterion("xno <=", value, "xno");
            return (Criteria) this;
        }

        public Criteria andXnoLike(String value) {
            addCriterion("xno like", value, "xno");
            return (Criteria) this;
        }

        public Criteria andXnoNotLike(String value) {
            addCriterion("xno not like", value, "xno");
            return (Criteria) this;
        }

        public Criteria andXnoIn(List<String> values) {
            addCriterion("xno in", values, "xno");
            return (Criteria) this;
        }

        public Criteria andXnoNotIn(List<String> values) {
            addCriterion("xno not in", values, "xno");
            return (Criteria) this;
        }

        public Criteria andXnoBetween(String value1, String value2) {
            addCriterion("xno between", value1, value2, "xno");
            return (Criteria) this;
        }

        public Criteria andXnoNotBetween(String value1, String value2) {
            addCriterion("xno not between", value1, value2, "xno");
            return (Criteria) this;
        }

        public Criteria andXjhrPhoneIsNull() {
            addCriterion("xjhr_phone is null");
            return (Criteria) this;
        }

        public Criteria andXjhrPhoneIsNotNull() {
            addCriterion("xjhr_phone is not null");
            return (Criteria) this;
        }

        public Criteria andXjhrPhoneEqualTo(String value) {
            addCriterion("xjhr_phone =", value, "xjhrPhone");
            return (Criteria) this;
        }

        public Criteria andXjhrPhoneNotEqualTo(String value) {
            addCriterion("xjhr_phone <>", value, "xjhrPhone");
            return (Criteria) this;
        }

        public Criteria andXjhrPhoneGreaterThan(String value) {
            addCriterion("xjhr_phone >", value, "xjhrPhone");
            return (Criteria) this;
        }

        public Criteria andXjhrPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("xjhr_phone >=", value, "xjhrPhone");
            return (Criteria) this;
        }

        public Criteria andXjhrPhoneLessThan(String value) {
            addCriterion("xjhr_phone <", value, "xjhrPhone");
            return (Criteria) this;
        }

        public Criteria andXjhrPhoneLessThanOrEqualTo(String value) {
            addCriterion("xjhr_phone <=", value, "xjhrPhone");
            return (Criteria) this;
        }

        public Criteria andXjhrPhoneLike(String value) {
            addCriterion("xjhr_phone like", value, "xjhrPhone");
            return (Criteria) this;
        }

        public Criteria andXjhrPhoneNotLike(String value) {
            addCriterion("xjhr_phone not like", value, "xjhrPhone");
            return (Criteria) this;
        }

        public Criteria andXjhrPhoneIn(List<String> values) {
            addCriterion("xjhr_phone in", values, "xjhrPhone");
            return (Criteria) this;
        }

        public Criteria andXjhrPhoneNotIn(List<String> values) {
            addCriterion("xjhr_phone not in", values, "xjhrPhone");
            return (Criteria) this;
        }

        public Criteria andXjhrPhoneBetween(String value1, String value2) {
            addCriterion("xjhr_phone between", value1, value2, "xjhrPhone");
            return (Criteria) this;
        }

        public Criteria andXjhrPhoneNotBetween(String value1, String value2) {
            addCriterion("xjhr_phone not between", value1, value2, "xjhrPhone");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}