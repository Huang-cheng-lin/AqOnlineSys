package com.fszn.integrationframework.service;

import com.fszn.integrationframework.utils.Result;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface RenderingService {
    Result index();

    Result primaryTomiddle();

    Result submitMsg(String wid, String type);

    Result getStep(Long esn);

    Result getSchoolName(String bcode, String wid, int childsn);

    Result returnStuMsg(String wid, String type);

    Result returnFamilyMsg(String wid, String type);

    Result returnHouseMsg(String wid, String type);

    Result returnSecMsg(String wid, int childsn, String type);

    Result updateSubMsg(String wid, String type);

    Result returnAdult(String wid, String type);


    Result updateAdult(String phone, Integer selectid, String wid, int childsn);

    Result returnSchool(String wid, String type);

    Result sureUpdate(String wid, String type);

    Result returnFamily(String wid, String type);

    Result checkStuMsg(String id);

    Result returnRenZhen(String wid, String type);

    Result returnHuJi(String wid, String type);

    Result returnChanQuan(String wid, String number, String icd, String type);

    Result changeSchool(String wid, String schoolname, String type);

    Result returnMiddleAdult(String wid, String type);

    Result middleSureUpdate(String wid, String type);
    Result returnMiddleHouseMsg(String wid, String type);

    Result familySureMessageReturn(Integer bcode, String wid, String type);

    Result returnTime(Integer sn, String wid, String type);

    Result returnChanQuanYSH(String wid, String number, String icd, String type);


    Result returnMiddleSchoolName(String wid, String type);

    Result returnFamilyYSH(String wid, String type);

    Result getSchoolNamePrimary(String bcode, String wid);

    Result checkStuMsgByBaoMing(String id);

    Result returnMiddleAreaAndMdtype(String wid, String type);
}
