package com.fszn.integrationframework.domain;

public class MiddleHouseMsg4 {//公租房
    //户籍信息*3
    private String jsonImg11;
    private String jsonImg12;
    private String jsonImg13;
    //公租房租赁凭证*2
    private String jsonImg21;
    private String jsonImg22;
    //父母无房证明*2
    private String jsonImg31;
    private String jsonImg32;
    //租金缴纳凭证*2
    private String jsonImg41;
    private String jsonImg42;
    //水电气等缴费凭证*2
    private String jsonImg51;
    private String jsonImg52;
    private String picd;//产权身份证
    private String pno;//产权号
    private String paddress;//房产地址

    public String getJsonImg11() {
        return jsonImg11;
    }

    public void setJsonImg11(String jsonImg11) {
        this.jsonImg11 = jsonImg11;
    }

    public String getJsonImg12() {
        return jsonImg12;
    }

    public void setJsonImg12(String jsonImg12) {
        this.jsonImg12 = jsonImg12;
    }

    public String getJsonImg13() {
        return jsonImg13;
    }

    public void setJsonImg13(String jsonImg13) {
        this.jsonImg13 = jsonImg13;
    }

    public String getJsonImg21() {
        return jsonImg21;
    }

    public void setJsonImg21(String jsonImg21) {
        this.jsonImg21 = jsonImg21;
    }

    public String getJsonImg22() {
        return jsonImg22;
    }

    public void setJsonImg22(String jsonImg22) {
        this.jsonImg22 = jsonImg22;
    }

    public String getJsonImg31() {
        return jsonImg31;
    }

    public void setJsonImg31(String jsonImg31) {
        this.jsonImg31 = jsonImg31;
    }

    public String getJsonImg32() {
        return jsonImg32;
    }

    public void setJsonImg32(String jsonImg32) {
        this.jsonImg32 = jsonImg32;
    }

    public String getJsonImg41() {
        return jsonImg41;
    }

    public void setJsonImg41(String jsonImg41) {
        this.jsonImg41 = jsonImg41;
    }

    public String getJsonImg42() {
        return jsonImg42;
    }

    public void setJsonImg42(String jsonImg42) {
        this.jsonImg42 = jsonImg42;
    }

    public String getJsonImg51() {
        return jsonImg51;
    }

    public void setJsonImg51(String jsonImg51) {
        this.jsonImg51 = jsonImg51;
    }

    public String getJsonImg52() {
        return jsonImg52;
    }

    public void setJsonImg52(String jsonImg52) {
        this.jsonImg52 = jsonImg52;
    }

    public String getPicd() {
        return picd;
    }

    public void setPicd(String picd) {
        this.picd = picd;
    }

    public String getPno() {
        return pno;
    }

    public void setPno(String pno) {
        this.pno = pno;
    }

    public String getPaddress() {
        return paddress;
    }

    public void setPaddress(String paddress) {
        this.paddress = paddress;
    }
}
