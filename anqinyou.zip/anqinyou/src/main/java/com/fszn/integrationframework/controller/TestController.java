package com.fszn.integrationframework.controller;

import com.fszn.integrationframework.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@RestController
public class TestController {
    @Autowired
    private TestService testService;


    @RequestMapping("test")
    @ResponseBody
    public void  test(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("test");
        request.getRequestDispatcher("welcome.html").forward(request,response);
    }
    @RequestMapping("/test.do")
    @ResponseBody
    public ModelAndView Test(HttpServletRequest request) throws Exception {
        ModelAndView mv = new ModelAndView();
        String token = "";
        if (request.getParameter("token") != null) {
            token = request.getParameter("token");
            mv.addObject("token", token);
            mv.setViewName("welcome");
        } else {
            mv.setViewName("error");
        }
        return mv;
    }
    @RequestMapping("/testFlag")
    @ResponseBody
    public void  testFlag(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     //进行对未过报名记录的校验
        testService.testFlag();
    }
}
