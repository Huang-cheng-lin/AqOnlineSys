package com.fszn.integrationframework.domain;

import java.util.Date;

public class Material {
    private Long msn;

    private Long esn;

    private String guid;

    private String mtype;

    private String mname;

    private Date uptime;

    private String address;

    private Integer msize;

    public Long getMsn() {
        return msn;
    }

    public void setMsn(Long msn) {
        this.msn = msn;
    }

    public Long getEsn() {
        return esn;
    }

    public void setEsn(Long esn) {
        this.esn = esn;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid == null ? null : guid.trim();
    }

    public String getMtype() {
        return mtype;
    }

    public void setMtype(String mtype) {
        this.mtype = mtype == null ? null : mtype.trim();
    }

    public String getMname() {
        return mname;
    }

    public void setMname(String mname) {
        this.mname = mname == null ? null : mname.trim();
    }

    public Date getUptime() {
        return uptime;
    }

    public void setUptime(Date uptime) {
        this.uptime = uptime;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    public Integer getMsize() {
        return msize;
    }

    public void setMsize(Integer msize) {
        this.msize = msize;
    }
}