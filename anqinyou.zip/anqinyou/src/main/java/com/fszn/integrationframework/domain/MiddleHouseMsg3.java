package com.fszn.integrationframework.domain;

public class MiddleHouseMsg3 {//爷孙户
    //户籍信息*3
    private String jsonImg11;
    private String jsonImg12;
    private String jsonImg13;
    //房产信息*3
    private String jsonImg21;
    private String jsonImg22;
    private String jsonImg23;
    //无房证明*2
    private String jsonImg31;
    private String jsonImg32;
    private String picd;//产权身份证
    private String pno;//产权号
    private String paddress;//房产地址

    public String getJsonImg11() {
        return jsonImg11;
    }

    public void setJsonImg11(String jsonImg11) {
        this.jsonImg11 = jsonImg11;
    }

    public String getJsonImg12() {
        return jsonImg12;
    }

    public void setJsonImg12(String jsonImg12) {
        this.jsonImg12 = jsonImg12;
    }

    public String getJsonImg13() {
        return jsonImg13;
    }

    public void setJsonImg13(String jsonImg13) {
        this.jsonImg13 = jsonImg13;
    }

    public String getJsonImg21() {
        return jsonImg21;
    }

    public void setJsonImg21(String jsonImg21) {
        this.jsonImg21 = jsonImg21;
    }

    public String getJsonImg22() {
        return jsonImg22;
    }

    public void setJsonImg22(String jsonImg22) {
        this.jsonImg22 = jsonImg22;
    }

    public String getJsonImg23() {
        return jsonImg23;
    }

    public void setJsonImg23(String jsonImg23) {
        this.jsonImg23 = jsonImg23;
    }

    public String getJsonImg31() {
        return jsonImg31;
    }

    public void setJsonImg31(String jsonImg31) {
        this.jsonImg31 = jsonImg31;
    }

    public String getJsonImg32() {
        return jsonImg32;
    }

    public void setJsonImg32(String jsonImg32) {
        this.jsonImg32 = jsonImg32;
    }

    public String getPicd() {
        return picd;
    }

    public void setPicd(String picd) {
        this.picd = picd;
    }

    public String getPno() {
        return pno;
    }

    public void setPno(String pno) {
        this.pno = pno;
    }

    public String getPaddress() {
        return paddress;
    }

    public void setPaddress(String paddress) {
        this.paddress = paddress;
    }
}
