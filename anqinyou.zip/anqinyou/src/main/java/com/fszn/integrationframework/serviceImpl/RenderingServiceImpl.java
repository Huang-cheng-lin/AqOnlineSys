package com.fszn.integrationframework.serviceImpl;

import com.fszn.integrationframework.dao.*;
import com.fszn.integrationframework.domain.*;
import com.fszn.integrationframework.service.RenderingService;
import com.fszn.integrationframework.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;

@Service
@Slf4j

public class RenderingServiceImpl implements RenderingService {
    @Autowired
    private AreaMapper areaMapper;
    @Autowired
    private EnrollTypeMapper enrollTypeMapper;
    @Autowired
    private Result result;
    @Autowired
    private EnrollMapper enrollMapper;
    @Autowired
    private UserRollMapper userRollMapper;
    @Autowired
    private StudentMapper studentMapper;
    @Autowired
    private SchoolMapper schoolMapper;
    @Autowired
    private FamilyMapper familyMapper;
    @Autowired
    private MaterialMapper materialMapper;
    @Autowired
    private PorpertyMapper porpertyMapper;
    @Autowired
    private HouseholdMapper householdMapper;
    @Autowired
    private TimecontrolMapper timecontrolMapper;

    @Override
    public Result index() {
        //进行查询enroll_type表 返回报名类型的数据
        EnrollTypeExample example = new EnrollTypeExample();
        EnrollTypeExample.Criteria criteria = example.createCriteria();
        List<EnrollType> list = null;
        try {
            list = enrollTypeMapper.selectByExample(example);
            log.info("index页面渲染成功，返回记录数：" + list.size());
            result.setCode("200");
            result.setContent(list);
        } catch (Exception e) {
            log.error("index页面渲染失败，查询数据库时失败");
            result.setCode("500");
        }

        return result;
    }

    @Override
    public Result primaryTomiddle() {
        //进行查询area表 返回选区类型的数据
        List<Area> list = null;
        try {
            list = areaMapper.selectByExample(new AreaExample());
            result.setContent(list);
            result.setCode("200");
            log.info("返回选区类型的数据正常");
        } catch (Exception e) {
            log.error("返回选区类型数据异常，查询数据库错误");
            result.setContent("500");
        }
        return result;
    }

    @Override//通过传递过来的wid  进行查询相关孩子的报名信息
    public Result submitMsg(String wid, String type) {
        //查询Enroll表获取孩子的报名编号：
        EnrollExample example = new EnrollExample();
        EnrollExample.Criteria criteria = example.createCriteria().andWidEqualTo(wid).andBcodeEqualTo(type).andStepIsNotNull();
        List<Enroll> list = enrollMapper.selectByExample(example);
        Long esn;//报名编号
        ArrayList<TotelMsg> list1 = new ArrayList<>();
        //获取小孩的选区  ----
        try {
            for (int i = 0; i < list.size(); i++) {
                esn = list.get(i).getEsn();//获取小孩的ESN号
                //进行查询小孩的姓名、身份证  student表
                StudentExample example1 = new StudentExample();
                example1.createCriteria().andEsnEqualTo(esn);
                List<Student> student = studentMapper.selectByExample(example1);
                TotelMsg totelMsg = new TotelMsg();
                totelMsg.setEnroll(list.get(i));
                totelMsg.setStudent(student);
                list1.add(totelMsg);
            }
            result.setCode("200");
            result.setContent(list1);
            log.info("submit页面数据返回成功");
        } catch (Exception e) {
            log.error("submit页面数据返回失败");
            result.setCode("500");
        }
        return result;
    }

    @Override
    public Result getStep(Long esn) {
        try {
            Enroll enroll = enrollMapper.selectByPrimaryKey(esn);
            result.setCode("200");
            result.setContent(enroll.getStep());
            result.setMsg(enroll.getBcode());
            log.info("进度情况查询成功");
        } catch (Exception e) {
            result.setCode("500");
            log.error("进度查询失败、数据库异常");
        }

        return result;
    }

    @Override//学校信息返回
    public Result getSchoolName(String bcode, String wid, int asn) {
        log.info(bcode);
        SchoolExample example1 = new SchoolExample();
        try {
            if (bcode.equals("01")) {//幼儿园
                example1.createCriteria().andSctypeEqualTo("幼儿园");
                result.setCode("200");
                result.setContent(schoolMapper.selectByExample(example1));
                log.info("返回学校名称数据成功------幼儿园分支");
            } else {//小学分支
                if (asn == 0) {
                    asn = userRollMapper.selectByPrimaryKey(wid).getAsn();
                }
                example1.createCriteria().andSctypeEqualTo("小学").andAsnEqualTo(asn);
                result.setCode("200");
                result.setContent(schoolMapper.selectByExample(example1));
                log.info("返回学校名称数据成功------小学分支");
            }
        } catch (Exception e) {
            log.error("返回学校名称数据失败");
            result.setCode("500");
        }
        return result;
    }

    @Override//StuMsg页面数据回调
    public Result returnStuMsg(String wid, String type) {
        EnrollExample example1 = new EnrollExample();
        EnrollExample.Criteria criteria1 = example1.createCriteria();
        criteria1.andWidEqualTo(wid);
        criteria1.andBcodeEqualTo(type);
        StudentExample studentExample = new StudentExample();
        //返回数据的  数组
        String[] str = new String[7];
        try {
            List<Enroll> list = enrollMapper.selectByExample(example1);
            Long esn = list.get(0).getEsn();   //获取esn报名编号
            studentExample.createCriteria().andEsnEqualTo(esn);
            List<Student> student = studentMapper.selectByExample(studentExample);
            if (student.size() == 2) {
                str[0] = student.get(0).getRealname();
                str[1] = student.get(0).getId();
                str[5] = student.get(1).getRealname();
                str[6] = student.get(1).getId();
            } else {
                str[0] = student.get(0).getRealname();
                str[1] = student.get(0).getId();
            }
            UserRoll userRoll = userRollMapper.selectByPrimaryKey(wid);
            str[4] = userRoll.getPhone();
            str[2] = student.size() + "";
            str[3] = userRoll.getIsyh();
            result.setContent(str);
            result.setCode("200");
        } catch (Exception e) {
            result.setCode("500");
            log.error("回调数据失败-------StuMsg页面");
        }
        return result;
    }

    @Override
    public Result returnFamilyMsg(String wid, String type) {
        EnrollExample example1 = new EnrollExample();
        EnrollExample.Criteria criteria1 = example1.createCriteria();
        criteria1.andWidEqualTo(wid);
        criteria1.andBcodeEqualTo(type);
        FamilyExample familyExample = new FamilyExample();
        try {
            List<Enroll> list = enrollMapper.selectByExample(example1);
            Long esn = list.get(0).getEsn();   //获取esn报名编号
            familyExample.createCriteria().andEsnEqualTo(esn);
            result.setContent(familyMapper.selectByExample(familyExample));
            result.setCode("200");
        } catch (Exception e) {
            result.setCode("500");
            log.error("回调数据失败-------FamilyMsg页面");
        }
        return result;
    }

    @Override
    public Result returnHouseMsg(String wid, String type) {
        EnrollExample example1 = new EnrollExample();
        EnrollExample.Criteria criteria1 = example1.createCriteria();
        criteria1.andWidEqualTo(wid);
        criteria1.andBcodeEqualTo(type);
        MaterialExample materialExample = new MaterialExample();
        try {
            List<Enroll> list = enrollMapper.selectByExample(example1);
            Long esn = list.get(0).getEsn();   //获取esn报名编号
            materialExample.createCriteria().andEsnEqualTo(esn).andMnameNotLike("jsonImgSec%");
            materialExample.setOrderByClause("mname");
            List<Material> list1 = materialMapper.selectByExample(materialExample);//获取到的所有图片信息
            String[][] str = new String[5][6];
            int a = 0;
            int b = 0;
            int c = 0;
            int d = 0;
            String base64 = "";
            for (int i = 0; i < list1.size(); i++) {//通过路劲地址查询
                //通过路劲地址依次放入到数组当中
                base64 = ReadFromFile.readTxt(list1.get(i).getAddress());
                if (list1.get(i).getMname().contains("jsonImg1")) {
                    str[0][a] = base64;
                    a = a + 1;
                } else if (list1.get(i).getMname().contains("jsonImg2")) {
                    str[1][b] = base64;
                    b = b + 1;
                } else if (list1.get(i).getMname().contains("jsonImg3")) {
                    str[2][c] = base64;
                    c = c + 1;
                } else {
                    str[3][d] = base64;
                    d = d + 1;
                }
            }
            //将产权信息回调放到str[4]中
            PorpertyExample porpertyExample = new PorpertyExample();
            porpertyExample.createCriteria().andEsnEqualTo(esn);
            List<Porperty> list2 = porpertyMapper.selectByExample(porpertyExample);
            if (list2.size() == 0) {
                //返回数据为空
            } else {

                str[4][0] = list2.get(0).getPno();
                str[4][1] = list2.get(0).getIcd();
                str[4][2] = list2.get(0).getPaddress();
            }
            result.setContent(str);
            result.setCode("200");
        } catch (Exception e) {
            result.setCode("500");
            log.error("回调数据失败-------HouseMsg页面");
        }
        return result;
    }

    @Override
    public Result returnSecMsg(String wid, int childsn, String type) {
        EnrollExample example1 = new EnrollExample();
        EnrollExample.Criteria criteria1 = example1.createCriteria();
        criteria1.andWidEqualTo(wid);
        criteria1.andChildsnEqualTo(childsn);
        criteria1.andBcodeEqualTo(type);
        MaterialExample materialExample = new MaterialExample();
        try {
            List<Enroll> list = enrollMapper.selectByExample(example1);
            Long esn = list.get(0).getEsn();   //获取esn报名编号
            materialExample.createCriteria().andEsnEqualTo(esn).andMnameLike("jsonImgSec%");
            materialExample.setOrderByClause("mname");
            List<Material> list1 = materialMapper.selectByExample(materialExample);//获取到的所有图片信息
            String[][] str = new String[2][3];
            int a = 0;
            int b = 0;
            String base64 = "";
            for (int i = 0; i < list1.size(); i++) {//通过路劲地址查询
                //通过路劲地址依次放入到数组当中
                base64 = ReadFromFile.readTxt(list1.get(i).getAddress());
                if (list1.get(i).getMname().contains("jsonImgSec1")) {
                    str[0][a] = base64;
                    a++;
                } else {
                    str[1][b] = base64;
                    b++;
                }
            }
            result.setContent(str);
            result.setCode("200");
        } catch (Exception e) {
            result.setCode("500");
            log.error("回调数据失败-------SecMsg页面");
        }
        return result;
    }

    @Override//通过wid查询报名列表中的信息
    public Result updateSubMsg(String wid, String type) {
        //查询Enroll表获取孩子的报名编号：
        EnrollExample example = new EnrollExample();
        EnrollExample.Criteria criteria = example.createCriteria().andWidEqualTo(wid).andStepIsNull().andBcodeEqualTo(type);
        List<Enroll> list = enrollMapper.selectByExample(example);
        Long esn;//报名编号
        ArrayList<TotelMsg> list1 = new ArrayList<>();
        Student student;
        //获取小孩的选区  ----
        try {
            for (int i = 0; i < list.size(); i++) {
                esn = list.get(i).getEsn();//获取小孩的ESN号
                //进行查询小孩的姓名、身份证  student表
                StudentExample example1 = new StudentExample();
                example1.createCriteria().andEsnEqualTo(esn);
                List<Student> list2 = studentMapper.selectByExample(example1);
                TotelMsg totelMsg = new TotelMsg();
                totelMsg.setEnroll(list.get(i));
                if (list2.size() == 0) {
                    totelMsg.setStudent(null);
                } else {
                    totelMsg.setStudent(list2);
                }
                list1.add(totelMsg);
            }
            result.setCode("200");
            result.setContent(list1);
            log.info("修改页面数据返回成功");
        } catch (Exception e) {
            log.error("修改页面数据返回失败");
            result.setCode("500");
        }
        return result;
    }

    @Override//查询家长的手机号、选区信息  并返回
    public Result returnAdult(String wid, String type) {
        userRollMapper.selectByPrimaryKey(wid);
        try {
            result.setContent(userRollMapper.selectByPrimaryKey(wid));
            result.setCode("200");
        } catch (Exception e) {
            result.setCode("500");
            log.error("返回修改页面的adult回调错误");
        }
        return result;
    }

    @Override//对家长信息进行维护
    public Result updateAdult(String phone, Integer selectid, String wid, int childsn) {
        UserRoll userRoll = new UserRoll();
        userRoll.setAsn(selectid);
        userRoll.setPhone(phone);
        userRoll.setWid(wid);
        try {
            userRollMapper.updateByPrimaryKeySelective(userRoll);
            result.setCode("200");
        } catch (Exception e) {
            result.setCode("500");
            log.error("修改家长信息错误");
        }
        return result;
    }

    @Override
    public Result returnSchool(String wid, String type) {
        EnrollExample example = new EnrollExample();
        example.createCriteria().andWidEqualTo(wid).andBcodeEqualTo(type);
        try {
            result.setContent(enrollMapper.selectByExample(example).get(0));
            result.setCode("200");
        } catch (Exception e) {
            log.error("返回预选学校错误");
            result.setCode("500");
        }
        return result;
    }

    @Override
    public Result sureUpdate(String wid, String type) {
        Enroll enroll = new Enroll();
        EnrollExample example = new EnrollExample();
        example.createCriteria().andWidEqualTo(wid).andBcodeEqualTo(type);//更新提交状态
        EnrollExample example1 = new EnrollExample();
        UserRoll userRoll = new UserRoll();
        userRoll.setWid(wid);
        try {
            StudentExample studentExample = new StudentExample();
            String token = HttpUtilsGetToken.getMessage();  //获取APItoken
            //对flag属性配上标记 、根据出生年月/分多孩、单孩、整体摇号、分开摇号  户籍信息  产权信息 、双胞胎认证
            //获取ESN
            Enroll enroll1 = enrollMapper.selectByExample(example).get(0);
            Long esn = enroll1.getEsn();//获取ESN
            //获取报名选择的预选学校
            String schoolname = enroll1.getSchool1();
            int childsn = enroll1.getChildsn();
            int mrdtype = enroll1.getMrdtype();//获取认证资格
            String note = enroll.getNote();
            if ("null".equals(note) || note == null) {
                note = "";
            }
            //根据报名表中的报名认证资格  进行分别验证
            switch (mrdtype) {
                case 1:   //户籍信息认证
                    if (childsn == 1) {   //单孩情况   //进行户籍查询  如果查询不到  则给flag设定为0
                        String[] a = new String[8];
                        studentExample.createCriteria().andEsnEqualTo(esn);
                        String icd = studentMapper.selectByExample(studentExample).get(0).getId();
                        a = HttpUtilsGetToken.getHuJi(token, icd);
                        if (a[0] != null && CheckIcdInCity.returnCity(a[5], null)) {  //判断户籍返回信息 如果为空则说明查不到户籍信息
                            enroll.setFlag(1);
                        } else {
                            enroll.setFlag(0);
                            note = note + "户籍无法匹配；";
                            log.error("查询户籍API失败");
                        }
                    } else {//多孩情况
                        studentExample.createCriteria().andEsnEqualTo(esn);
                        List<Student> list = studentMapper.selectByExample(studentExample);
                        String[] a = HttpUtilsGetToken.getHuJi(token, list.get(0).getId());
                        String[] a1 = HttpUtilsGetToken.getHuJi(token, list.get(1).getId());
                        if (a[0] == null || a1[0] == null) {
                            enroll.setFlag(0);
                            note = note + "户籍无法匹配；";
                            log.error("查询户籍API失败");
                        } else {
                            if (a[4].equals(a1[4]) && CheckIcdInCity.returnCity(a[5], a1[5])) {  //2个小孩都能查到户籍信息且户籍信息相同
                                //判断出生年月日是否相差一天之内
                                String birthday = IDCardUtil.getBirthday(list.get(0).getId());  //年 -月 -日
                                String birthday1 = IDCardUtil.getBirthday(list.get(1).getId());
                                //将年月日转化成日期型数据 再进行比对
                                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                                Date date = sdf.parse(birthday);
                                Date date1 = sdf.parse(birthday1);
                                int day = IDCardUtil.differentDays(date, date1);  //双胞胎标识  符合户籍要求 且  年月日不相差一天
                                if (day <= 1) {//相差的天数
                                    // 进行修改userroll表中的双胞胎标识
                                    //户籍相同且双胞胎
                                    enroll.setFlag(1);
                                    enroll.setBinfoIsright(1);
                                    enroll.setMaterialIsright(1);
                                    userRoll.setSbtflag(1);
                                    userRollMapper.updateByPrimaryKeySelective(userRoll);
                                } else {
                                    enroll.setFlag(1);
                                    enroll.setBinfoIsright(1);
                                    enroll.setMaterialIsright(1);
                                    //户籍相同但非双胞胎
                                }
                            } else {//2个小孩都能查到户籍信息但监护人信息不相同
                                //户籍不相同  不进行判定双胞胎标识
                                enroll.setFlag(0);
                                note = note + "户籍无法匹配；";
                            }
                        }
                    }
                    //进行相关flag的修改----flag1
                    enroll.setStep(1);
                    break;
                case 2:
                    //首先先进行户籍验证-----只需要本市市区及县城  可查询户籍的
                    //进行房产认证资格验证
                    //房产信息验证
                    //进行产权认证   通过判断选择类型 只进行判断选了产权认证的人----如果产权拥有人 非监护人 不进行产权认证
                    PorpertyExample porpertyExample = new PorpertyExample();
                    porpertyExample.createCriteria().andEsnEqualTo(esn);
                    FamilyExample familyExample = new FamilyExample();
                    familyExample.createCriteria().andEsnEqualTo(esn);
                    List<Family> familyList = familyMapper.selectByExample(familyExample);
                    Porperty porperty = porpertyMapper.selectByExample(porpertyExample).get(0);
                    Boolean flag = false; //初步户籍校验成功标识
//                    进行校验**************************************************************************************************
                    if (childsn == 1) {   //单孩情况   //进行户籍查询  如果查询不到  则给flag设定为0
                        String[] a = new String[8];
                        studentExample.createCriteria().andEsnEqualTo(esn);
                        String icd = studentMapper.selectByExample(studentExample).get(0).getId();
                        a = HttpUtilsGetToken.getHuJi(token, icd);
                        if (a[0] != null) {  //判断户籍返回信息 如果为空则说明查不到户籍信息
                            flag = true;
                        } else {
                            note = note + "户籍无法匹配；";
                        }
                    } else {//多孩情况
                        studentExample.createCriteria().andEsnEqualTo(esn);
                        List<Student> list = studentMapper.selectByExample(studentExample);
                        String[] a = HttpUtilsGetToken.getHuJi(token, list.get(0).getId());
                        String[] a1 = HttpUtilsGetToken.getHuJi(token, list.get(1).getId());
                        if (a[0] == null || a1[0] == null) {
                            enroll.setFlag(0);
                            note = note + "户籍无法匹配；";
                            log.error("查询户籍API失败");
                        } else {
                            if (a[4].equals(a1[4])) {  //2个小孩都能查到户籍信息且户籍信息相同
                                //判断出生年月日是否相差一天之内
                                String birthday = IDCardUtil.getBirthday(list.get(0).getId());  //年 -月 -日
                                String birthday1 = IDCardUtil.getBirthday(list.get(1).getId());
                                //将年月日转化成日期型数据 再进行比对
                                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                                Date date = sdf.parse(birthday);
                                Date date1 = sdf.parse(birthday1);
                                int day = IDCardUtil.differentDays(date, date1);  //双胞胎标识  符合户籍要求 且  年月日不相差一天
                                if (day <= 1) {//相差的天数
                                    // 进行修改userroll表中的双胞胎标识
                                    //户籍相同且双胞胎
                                    flag = true;
                                    userRoll.setSbtflag(1);
                                    userRollMapper.updateByPrimaryKeySelective(userRoll);
                                } else {
                                    //户籍相同但非双胞胎
                                    flag = true;
                                }
                            } else {//2个小孩都能查到户籍信息但监护人信息不相同
                                //户籍不相同  不进行判定双胞胎标识
                                enroll.setFlag(0);
                                note = note + "户籍无法匹配；";
                            }
                        }
                    }
//                    进行校验**************************************************************************************************
                    if (flag) {   //如果初步户籍认证未通过、产权也不进行认证了
                        if (porperty.getIcd().equals(familyList.get(0).getId()) || porperty.getIcd().equals(familyList.get(1).getId())) {
                            String[] a = HttpUtilsGetToken.getChanQuan(token, porperty.getPno(), porperty.getIcd());
                            if (a[0] == null) { //查询产权信息  查询结果为空
                                enroll.setFlag(0);
                                note = note + "房产无法匹配；";
                            } else {
                                //判断产权地址是否属于碧桂园----需要进行该判断认证的  报名详细为预选学校选择了碧桂园配套幼儿园
                                if ("市政府机关幼儿园碧桂园分园".equals(schoolname)) { //相同时则进行匹配校验
                                    //判断地址是否在碧桂园所取小区中
                                    if (IsBgY.returnflag(a[3])) {
                                        enroll.setFlag(1);
                                        enroll.setBinfoIsright(1);
                                        enroll.setMaterialIsright(1);
                                        //将产权信息写入产权表中
                                        porperty.setOwners(a[1]);
                                        porperty.setEsn(null);
                                        porperty.setPaddress(a[3]);
                                        porperty.setPdt(StringToTimestamp.formatTime((a[4])));
                                        porpertyMapper.updateByExampleSelective(porperty, porpertyExample);
                                    } else {
                                        enroll.setFlag(0);
                                        note = note + "房产无法匹配；";
                                        //将产权信息写入产权表中
                                        porperty.setOwners(a[1]);
                                        porperty.setEsn(null);
                                        porperty.setPaddress(a[3]);
                                        porperty.setPdt(StringToTimestamp.formatTime((a[4])));
                                        porpertyMapper.updateByExampleSelective(porperty, porpertyExample);
                                    }
                                } else {
                                    enroll.setFlag(1);
                                    enroll.setBinfoIsright(1);
                                    enroll.setMaterialIsright(1);
                                    //将产权信息写入产权表中
                                    porperty.setOwners(a[1]);
                                    porperty.setEsn(null);
                                    porperty.setPaddress(a[3]);
                                    porperty.setPdt(StringToTimestamp.formatTime((a[4])));
                                    porpertyMapper.updateByExampleSelective(porperty, porpertyExample);
                                }

                            }
                            //进行房产、户籍资格认证  写入数据库 进行相关flag的修改----flag2
                        } else {
                            enroll.setFlag(0);
                            note = note + "房产无法匹配；";
                        }
                    } else {
                        if (porperty.getIcd().equals(familyList.get(0).getId()) || porperty.getIcd().equals(familyList.get(1).getId())) {
                            String[] a = HttpUtilsGetToken.getChanQuan(token, porperty.getPno(), porperty.getIcd());
                            if (a[0] == null) { //查询产权信息  查询结果为空
                                enroll.setFlag(0);
                                note = note + "房产无法匹配；";
                            } else {
                                enroll.setFlag(0);
                                //将产权信息写入产权表中
                                porperty.setOwners(a[1]);
                                porperty.setEsn(null);
                                porperty.setPaddress(a[3]);
                                porperty.setPdt(StringToTimestamp.formatTime((a[4])));
                                porpertyMapper.updateByExampleSelective(porperty, porpertyExample);
                            }
                            //进行房产、户籍资格认证  写入数据库 进行相关flag的修改----flag2
                        } else {
                            enroll.setFlag(0);
                            note = note + "房产无法匹配；";
                        }
                    }
                    enroll.setStep(1);
                    break;
                case 3:
                    //不进行任何验证  flag直接写入 0  即 验证不通过线下进行
                    enroll.setFlag(0);
                    note = note + "居住证线下验证；";
                    enroll.setStep(1);
                    break;
            }
            result.setCode("200");
            //将enroll写入数据库
            enroll.setNote(note);
            enrollMapper.updateByExampleSelective(enroll, example);
        } catch (Exception e) {
            result.setCode("500");
            log.error("错误提交");
        }
        return result;
    }

    @Override//通过调用API  进行返回户籍信息
    public Result returnFamily(String wid, String type) {
        return null;
    }

    @Override
    //先通过身份证查询学生表  然后 通过报名号查询是否已成功报名 如果成功报名 则返回icd重复
    public Result checkStuMsg(String id) {
        StudentExample example = new StudentExample();
        example.createCriteria().andIdEqualTo(id);
        try {
            List<Student> student = studentMapper.selectByExample(example);
            if (student.size() == 0) {
                result.setCode("200");
            } else if (student.size() == 1) {
                if (enrollMapper.selectByPrimaryKey(student.get(0).getEsn()).getStep() == null) {
                    result.setCode("200");
                } else {
                    result.setCode("500");
                }

            } else {
                result.setCode("500");
            }
        } catch (Exception e) {
            result.setCode("500");
            log.error("查询报名ID是否存在");
        }
        return result;
    }

    @Override
    //返回认证资格信息
    public Result returnRenZhen(String wid, String type) {
        EnrollExample enrollExample = new EnrollExample();
        enrollExample.createCriteria().andWidEqualTo(wid).andBcodeEqualTo(type);
        try {
            result.setContent(enrollMapper.selectByExample(enrollExample).get(0).getMrdtype());
            result.setMsg(userRollMapper.selectByPrimaryKey(wid).getId());
            result.setCode("200");
        } catch (Exception e) {
            log.error("返回认证信息失败");
            result.setCode("500");
        }

        return result;
    }

    @Override
    //进行家长信息的回显    家长数据的回显和比对   如果后续提交和查询API不同时标记异常状态
    //查询API失败时则直接标记异常状态
    public Result returnHuJi(String wid, String type) {
        EnrollExample example = new EnrollExample();
        StudentExample example1 = new StudentExample();
        Household household = new Household();
        Long esn;
        int childsn = 9;
        //通过childsn、wid  判断多孩单孩
        try {
            UserRoll userRoll = userRollMapper.selectByPrimaryKey(wid);
            example.createCriteria().andWidEqualTo(wid).andBcodeEqualTo(type);
            List<Enroll> list5 = enrollMapper.selectByExample(example);//获取ESN
            if (list5.size() == 1) {
                esn = list5.get(0).getEsn();
                childsn = list5.get(0).getChildsn();
                String token = HttpUtilsGetToken.getMessage();  //获取APItoken
                if (childsn == 1) {   //单孩情况
                    example1.createCriteria().andEsnEqualTo(esn);
                    String icd = studentMapper.selectByExample(example1).get(0).getId();
                    String[] a = HttpUtilsGetToken.getHuJi(token, icd);
                    if (a[0] == null) {
                        log.error(a[0]);
                        result.setCode("500");
                        log.error("查询户籍API失败");
                    } else {
                        //将户籍地址录入到户籍表当中
                        //判断household表当中是否存在记录 如果存在则说明输入正确
                        HouseholdExample householdExample = new HouseholdExample();
                        householdExample.createCriteria().andEsnEqualTo(esn);
                        if (householdMapper.countByExample(householdExample) == 0) {
                            household.setEsn(esn);
                            household.setAddress(a[4]);
                            household.setId(userRoll.getId());
                            household.setRealname(userRoll.getRealname());
                            householdMapper.insertSelective(household);//插入数据
                        } else {//查到了数据--可能是页面回退则进行修改
                            household.setEsn(null);
                            household.setAddress(a[4]);
                            household.setId(userRoll.getId());
                            household.setRealname(userRoll.getRealname());
                            householdMapper.updateByExampleSelective(household, householdExample);
                        }
                        result.setCode("200");
                        result.setContent(a);
                        result.setMsg(CheckIcdInCity.returnCity(a[5], null) + "");
                    }
                } else {//多孩情况
                    example1.createCriteria().andEsnEqualTo(esn);
                    List<Student> list = studentMapper.selectByExample(example1);
                    String[] a = HttpUtilsGetToken.getHuJi(token, list.get(0).getId());
                    String[] a1 = HttpUtilsGetToken.getHuJi(token, list.get(1).getId());
                    System.out.println(a.equals(a1));
                    if (a[0] != null && a1[0] != null && a[4].equals(a1[4])) {
                        //将户籍地址录入到户籍表当中
                        //判断household表当中是否存在记录 如果存在则说明输入正确
                        HouseholdExample householdExample = new HouseholdExample();
                        householdExample.createCriteria().andEsnEqualTo(esn);
                        if (householdMapper.countByExample(householdExample) == 0) {
                            household.setEsn(esn);
                            household.setAddress(a[4]);
                            household.setId(userRoll.getId());
                            household.setRealname(userRoll.getRealname());
                            householdMapper.insertSelective(household);//插入数据
                        } else {//查到了数据--可能是页面回退则进行修改
                            household.setEsn(null);
                            household.setAddress(a[4]);
                            household.setId(userRoll.getId());
                            household.setRealname(userRoll.getRealname());
                            householdMapper.updateByExampleSelective(household, householdExample);
                        }
                        result.setCode("200");
                        result.setContent(a);
                        result.setMsg(CheckIcdInCity.returnCity(a[5], a1[5]) + "");
                    } else {
                        result.setCode("500");
                    }
                }
            } else {
                result.setCode("500");
            }
        } catch (Exception e) {
            log.error("查询户籍API失败");
            result.setCode("500");

        }

        return result;
    }

    @Override  //返回产权信息、并录入数据库  并且比对产权人身份证是否是监护人其一
    public Result returnChanQuan(String wid, String number, String icd, String type) {
        EnrollExample example = new EnrollExample();
        example.createCriteria().andWidEqualTo(wid).andBcodeEqualTo(type);
        FamilyExample familyExample = new FamilyExample();
        try {
            Long esn = enrollMapper.selectByExample(example).get(0).getEsn();//拿到Esn
            familyExample.createCriteria().andEsnEqualTo(esn);
            List<Family> list = familyMapper.selectByExample(familyExample);
            if (icd.equals(list.get(0).getId()) || icd.equals(list.get(1).getId())) {
                String token = HttpUtilsGetToken.getMessage();
                String[] a = HttpUtilsGetToken.getChanQuan(token, number, icd);
                if (a[0] == null) {
                    result.setCode("500");
                } else {
                    result.setContent(a);
                    result.setCode("200");
                }
            } else {
                result.setCode("500");
            }
        } catch (Exception e) {
            log.error("查询产权信息失败");
            result.setCode("500");
        }
        return result;
    }

    @Override
    public Result changeSchool(String wid, String schoolname, String type) {
        EnrollExample example = new EnrollExample();
        Enroll enroll = new Enroll();
        enroll.setSchool1(schoolname);
        example.createCriteria().andWidEqualTo(wid).andBcodeEqualTo(type);
        try {
            enrollMapper.updateByExampleSelective(enroll, example);
        } catch (Exception e) {
            log.error("修改预选学校返回错误");
            result.setCode("500");
        }
        return result;
    }

    @Override
    public Result returnMiddleAdult(String wid, String type) {
        //查询该报名类型下的ESN-----student的数量并且返回家长手机号码
        EnrollExample example = new EnrollExample();
        example.createCriteria().andWidEqualTo(wid).andBcodeEqualTo(type).andStepIsNull();
        StudentExample studentExample = new StudentExample();

        try {
            List<Enroll> list = enrollMapper.selectByExample(example);//拿到Esn

            if (list.size() == 0) {//说明当前没有报名记录
                result.setCode("200");
                result.setMsg("0");
                result.setContent(userRollMapper.selectByPrimaryKey(wid).getPhone());//手机号
            } else {//当前有报名记录  通过ESN查询student的个体数量
                studentExample.createCriteria().andEsnEqualTo(list.get(0).getEsn());
                result.setMsg("" + studentMapper.countByExample(studentExample));
                result.setContent(userRollMapper.selectByPrimaryKey(wid).getPhone());//手机号
                result.setCode("200");
            }
        } catch (Exception e) {
            log.error("返回小学----报名类型下的学生数量失败");
            result.setCode("500");
        }
        return result;
    }

    @Override
    public Result middleSureUpdate(String wid, String type) {
        Enroll enroll = new Enroll();
        EnrollExample example = new EnrollExample();
        example.createCriteria().andWidEqualTo(wid).andBcodeEqualTo(type);//更新提交状态
        EnrollExample example1 = new EnrollExample();
        UserRoll userRoll = new UserRoll();
        userRoll.setWid(wid);
        //获取户籍地址进行判断----
        try {
            StudentExample studentExample = new StudentExample();
            String token = HttpUtilsGetToken.getMessage();  //获取APItoken
            //对flag属性配上标记 、根据出生年月/分多孩、单孩、整体摇号、分开摇号  户籍信息  产权信息 、双胞胎认证
            //获取ESN
            Enroll enroll1 = enrollMapper.selectByExample(example).get(0);
            Long esn = enroll1.getEsn();//获取ESN
            int childsn = enroll1.getChildsn();
            int mrdtype = enroll1.getMrdtype();//获取认证资格
            String note = enroll.getNote();
            if ("null".equals(note) || note == null) {
                note = "";
            }
//            //获取户籍地址进行判断----
//            HouseholdExample householdExample = new HouseholdExample();
//            householdExample.createCriteria().andEsnEqualTo(esn);
//            List<Household> householdList = householdMapper.selectByExample(householdExample);
            //根据报名表中的报名认证资格  进行分别验证
            switch (mrdtype) {
                case 4:   //户籍信息认证
//                    进行校验**************************************************************************************************
                    Boolean flag = false; //初步户籍校验成功标识
                    String[] arr1 = new String[8];
                    String[] arr2;
                    if (childsn == 1) {   //单孩情况   //进行户籍查询  如果查询不到  则给flag设定为0
                        studentExample.createCriteria().andEsnEqualTo(esn);
                        String icd = studentMapper.selectByExample(studentExample).get(0).getId();
                        arr1 = HttpUtilsGetToken.getHuJi(token, icd);
                        if (arr1[0] != null && CheckIcdInCity.returnCity(arr1[5], null)) {  //判断户籍返回信息 如果为空则说明查不到户籍信息
                            flag = true;
                        } else {
                            note = note + "户籍无法匹配；";
                        }
                    } else {//多孩情况
                        studentExample.createCriteria().andEsnEqualTo(esn);
                        List<Student> list = studentMapper.selectByExample(studentExample);
                        arr1 = HttpUtilsGetToken.getHuJi(token, list.get(0).getId());
                        arr2 = HttpUtilsGetToken.getHuJi(token, list.get(1).getId());
                        if (arr1[0] != null && arr2[0] != null) {
                            if (arr1[4].equals(arr2[4]) && CheckIcdInCity.returnCity(arr1[5], arr2[5])) {  //2个小孩都能查到户籍信息且户籍信息相同
                                flag = true;
                            } else {
                                note = note + "户籍无法匹配；";
                            }
                        }
                    }
//                    进行校验**************************************************************************************************
                    //进行相关flag的修改----flag1
                    PorpertyExample porpertyExample = new PorpertyExample();
                    porpertyExample.createCriteria().andEsnEqualTo(esn);
                    FamilyExample familyExample = new FamilyExample();
                    familyExample.createCriteria().andEsnEqualTo(esn);
                    List<Family> familyList = familyMapper.selectByExample(familyExample);
                    Porperty porperty = porpertyMapper.selectByExample(porpertyExample).get(0);
                    //查询产权拥有人是否为监护人其一
                    if (flag) {
                        if (porperty.getIcd().equals(familyList.get(0).getId()) || porperty.getIcd().equals(familyList.get(1).getId())) {
                            String[] a = HttpUtilsGetToken.getChanQuan(token, porperty.getPno(), porperty.getIcd());
                            if (a[0] == null) { //查询产权信息  查询结果为空
                                enroll.setFlag(0);
                                note = note + "产权无法匹配；";
                            } else {
                                if (arr1[4].equals(a[3])) { //进行户籍地址与产权地址进行比对  不同则为判定错误
                                    enroll.setFlag(1);
                                } else {
                                    enroll.setFlag(0);
                                    note = note + "产权无法匹配；";
                                }
                                //将产权信息写入产权表中
                                enroll.setFlag(0);
                                porperty.setOwners(a[1]);
                                porperty.setEsn(null);
                                porperty.setPaddress(a[3]);
                                porperty.setPdt(StringToTimestamp.formatTime((a[4])));
                                porpertyMapper.updateByExampleSelective(porperty, porpertyExample);
                            }
                            //进行房产、户籍资格认证  写入数据库 进行相关flag的修改----flag2
                        } else {
                            enroll.setFlag(0);
                            note = note + "产权无法匹配；";
                        }
                    } else {
                        if (porperty.getIcd().equals(familyList.get(0).getId()) || porperty.getIcd().equals(familyList.get(1).getId())) {
                            String[] a = HttpUtilsGetToken.getChanQuan(token, porperty.getPno(), porperty.getIcd());
                            if (a[0] == null) { //查询产权信息  查询结果为空
                                enroll.setFlag(0);
                                note = note + "产权无法匹配；";
                            } else {
                                if (arr1[4].equals(a[3])) { //进行户籍地址与产权地址进行比对  不同则为判定错误
                                    enroll.setFlag(0);
                                } else {
                                    enroll.setFlag(0);
                                    note = note + "产权无法匹配；";
                                }
                                //将产权信息写入产权表中
                                porperty.setOwners(a[1]);
                                porperty.setEsn(null);
                                porperty.setPaddress(a[3]);
                                porperty.setPdt(StringToTimestamp.formatTime((a[4])));
                                porpertyMapper.updateByExampleSelective(porperty, porpertyExample);
                            }
                            //进行房产、户籍资格认证  写入数据库 进行相关flag的修改----flag2
                        } else {
                            enroll.setFlag(0);
                            note = note + "产权无法匹配；";
                        }
                    }


                    enroll.setStep(1);
                    break;
                case 5:
                    //首先先进行户籍验证-----只需要本市市区及县城  可查询户籍的
                    //进行房产认证资格验证
                    //房产信息验证
                    //进行产权认证   通过判断选择类型 只进行判断选了产权认证的人----如果产权拥有人 非监护人 不进行产权认证

                    Boolean flag1 = false; //初步户籍校验成功标识
                    String[] a;
                    String[] a1;
//                    进行校验**************************************************************************************************
                    if (childsn == 1) {   //单孩情况   //进行户籍查询  如果查询不到  则给flag设定为0
                        studentExample.createCriteria().andEsnEqualTo(esn);
                        String icd = studentMapper.selectByExample(studentExample).get(0).getId();
                        a = HttpUtilsGetToken.getHuJi(token, icd);
                        if (a[0] != null) {  //判断户籍返回信息 如果为空则说明查不到户籍信息
                            flag1 = true;
                        } else {
                            note = note + "户籍无法匹配；";
                        }
                    } else {//多孩情况
                        studentExample.createCriteria().andEsnEqualTo(esn);
                        List<Student> list = studentMapper.selectByExample(studentExample);
                        a = HttpUtilsGetToken.getHuJi(token, list.get(0).getId());
                        a1 = HttpUtilsGetToken.getHuJi(token, list.get(1).getId());
                        if (a[4].equals(a1[4]) && a[0] != null) {  //2个小孩都能查到户籍信息且户籍信息相同
                            flag1 = true;
                        } else {
                            note = note + "户籍无法匹配；";
                        }

                    }
//                    进行校验**************************************************************************************************
                    PorpertyExample porpertyExample1 = new PorpertyExample();
                    porpertyExample1.createCriteria().andEsnEqualTo(esn);
                    FamilyExample familyExample1 = new FamilyExample();
                    familyExample1.createCriteria().andEsnEqualTo(esn);
                    List<Family> familyList1 = familyMapper.selectByExample(familyExample1);
                    Porperty porperty1 = porpertyMapper.selectByExample(porpertyExample1).get(0);
                    if (flag1) {
                        if (porperty1.getIcd().equals(familyList1.get(0).getId()) || porperty1.getIcd().equals(familyList1.get(1).getId())) {
                            String[] b = HttpUtilsGetToken.getChanQuan(token, porperty1.getPno(), porperty1.getIcd());
                            if (b[0] == null) { //查询产权信息  查询结果为空
                                enroll.setFlag(0);
                                note = note + "产权无法匹配；";
                            } else {
                                enroll.setFlag(1);
                                enroll.setBinfoIsright(1);
                                enroll.setMaterialIsright(1);
                                //将产权信息写入产权表中
                                porperty1.setOwners(b[1]);
                                porperty1.setEsn(null);
                                porperty1.setPaddress(a[3]);
                                porperty1.setPdt(StringToTimestamp.formatTime((b[4])));
                                porpertyMapper.updateByExampleSelective(porperty1, porpertyExample1);
                            }
                            //进行房产、户籍资格认证  写入数据库 进行相关flag的修改----flag2
                        } else {
                            enroll.setFlag(0);
                            note = note + "产权无法匹配；";
                        }
                    } else {
                        if (porperty1.getIcd().equals(familyList1.get(0).getId()) || porperty1.getIcd().equals(familyList1.get(1).getId())) {
                            String[] b = HttpUtilsGetToken.getChanQuan(token, porperty1.getPno(), porperty1.getIcd());
                            if (b[0] == null) { //查询产权信息  查询结果为空
                                enroll.setFlag(0);
                                note = note + "产权无法匹配；";
                            } else {
                                enroll.setFlag(0);
                                note = note + "产权无法匹配；";
                                //将产权信息写入产权表中
                                porperty1.setOwners(b[1]);
                                porperty1.setEsn(null);
                                porperty1.setPaddress(a[3]);
                                porperty1.setPdt(StringToTimestamp.formatTime((b[4])));
                                porpertyMapper.updateByExampleSelective(porperty1, porpertyExample1);
                            }
                            //进行房产、户籍资格认证  写入数据库 进行相关flag的修改----flag2
                        } else {
                            enroll.setFlag(0);
                            note = note + "产权无法匹配；";
                        }
                    }

                    enroll.setStep(1);
                    break;
                case 6:
                    //爷孙户认证资格判定   自填父母身份证、姓名     父母身份证+房产证号 无法查询到房产信息
                    //通过户籍查询、皖氏通登录icd需在户籍查询信息之中
                    //且能查到房产
                    //户籍查询时  身份证的icd中的任何一个应不在父母身份证集中
                    Boolean flag2 = false; //初步户籍校验成功标识
                    String[] a2 = new String[8];
                    String[] a3;
//                    进行校验**************************************************************************************************
                    if (childsn == 1) {   //单孩情况   //进行户籍查询  如果查询不到  则给flag设定为0
                        studentExample.createCriteria().andEsnEqualTo(esn);
                        String icd = studentMapper.selectByExample(studentExample).get(0).getId();
                        a2 = HttpUtilsGetToken.getHuJi(token, icd);
                        if (a2[0] != null && CheckIcdInCity.returnCity(a2[5], null)) {  //判断户籍返回信息 如果为空则说明查不到户籍信息
                            flag2 = true;
                        } else {
                            note = note + "户籍无法匹配；";
                        }
                    } else {//多孩情况
                        studentExample.createCriteria().andEsnEqualTo(esn);
                        List<Student> list = studentMapper.selectByExample(studentExample);
                        a2 = HttpUtilsGetToken.getHuJi(token, list.get(0).getId());
                        a3 = HttpUtilsGetToken.getHuJi(token, list.get(1).getId());
                        if (a2[0] != null || a3[0] != null) {
                            if (a2[4].equals(a3[4]) && a2[0] != null && CheckIcdInCity.returnCity(a2[5], a3[5])) {  //2个小孩都能查到户籍信息且户籍信息相同
                                flag2 = true;
                            } else {
                                note = note + "户籍无法匹配；";
                            }
                        } else {
                            note = note + "户籍无法匹配；";
                        }

                    }
                    //获取判断小孩是否拥有城区户籍--------flag2 即为判断
                    PorpertyExample porpertyExample2 = new PorpertyExample();
                    porpertyExample2.createCriteria().andEsnEqualTo(esn);
                    FamilyExample familyExample2 = new FamilyExample();
                    familyExample2.createCriteria().andEsnEqualTo(esn);
                    List<Family> familyList2 = familyMapper.selectByExample(familyExample2);
                    Porperty porperty2 = porpertyMapper.selectByExample(porpertyExample2).get(0);
                    if (flag2) {//小孩有城区户籍
                        if (!(familyList2.get(0).getId().equals(a2[1]) || familyList2.get(0).getId().equals(a2[3]) || familyList2.get(1).getId().equals(a2[1]) || familyList2.get(1).getId().equals(a2[3]))) {//判断父母身份证是否在户籍信息回调当中
                            String[] array = HttpUtilsGetToken.getChanQuan(token, porperty2.getPno(), porperty2.getIcd());//为监护人所调用的房产信息
                            if (array[0] != null) {//监护人信息中调的到房产信息、父母调不到房产信息
                                enroll.setFlag(0);
                                note = note + "产权无法匹配；";
                                //将产权信息写入产权表中
                                porperty2.setOwners(array[1]);
                                porperty2.setEsn(null);
                                porperty2.setPaddress(array[3]);
                                porperty2.setPdt(StringToTimestamp.formatTime((array[4])));
                                porpertyMapper.updateByExampleSelective(porperty2, porpertyExample2);

                            } else {
                                enroll.setFlag(0);
                                note = note + "产权无法匹配；";
                            }
                        } else {
                            enroll.setFlag(0);
                            note = note + "产权无法匹配；";
                        }
                    } else {
                        if (!(familyList2.get(0).getId().equals(a2[1]) || familyList2.get(0).getId().equals(a2[3]) || familyList2.get(1).getId().equals(a2[1]) || familyList2.get(1).getId().equals(a2[3]))) {//判断父母身份证是否在户籍信息回调当中
                            String[] array = HttpUtilsGetToken.getChanQuan(token, porperty2.getPno(), porperty2.getIcd());//为监护人所调用的房产信息
                            if (array[0] != null) {//监护人信息中调的到房产信息、父母调不到房产信息
                                enroll.setFlag(0);
                                note = note + "产权无法匹配；";
                                //将产权信息写入产权表中
                                porperty2.setOwners(array[1]);
                                porperty2.setEsn(null);
                                porperty2.setPaddress(array[3]);
                                porperty2.setPdt(StringToTimestamp.formatTime((array[4])));
                                porpertyMapper.updateByExampleSelective(porperty2, porpertyExample2);

                            } else {
                                enroll.setFlag(0);
                                note = note + "产权无法匹配；";
                            }
                        } else {
                            enroll.setFlag(0);
                            note = note + "产权无法匹配；";
                        }
                    }
                    enroll.setStep(1);
                    break;

                case 7:
                    //不进行任何验证  flag直接写入 0  即 验证不通过线下进行
                    enroll.setFlag(0);
                    note = note + "公租房线下验证；";
                    enroll.setStep(1);
                    break;
                case 8:
                    //不进行任何验证  flag直接写入 0  即 验证不通过线下进行
                    enroll.setFlag(0);
                    note = note + "独立房产无产权线下验证；";
                    enroll.setStep(1);
                    break;
            }

            result.setCode("200");
            enroll.setNote(note);
            //将enroll写入数据库
            enrollMapper.updateByExampleSelective(enroll, example);
        } catch (Exception e) {
            result.setCode("500");
            log.error("错误提交");
        }
        return result;
    }

    @Override//返回小学图片信息
    public Result returnMiddleHouseMsg(String wid, String type) {

        EnrollExample example1 = new EnrollExample();
        EnrollExample.Criteria criteria1 = example1.createCriteria();
        criteria1.andWidEqualTo(wid);
        criteria1.andBcodeEqualTo(type);
        MaterialExample materialExample = new MaterialExample();
        try {
            List<Enroll> list = enrollMapper.selectByExample(example1);
            Long esn = list.get(0).getEsn();   //获取esn报名编号
            materialExample.createCriteria().andEsnEqualTo(esn).andMnameNotLike("jsonImgSec%");
            materialExample.setOrderByClause("mname");
            List<Material> list1 = materialMapper.selectByExample(materialExample);//获取到的所有图片信息
            String[][] str = new String[7][6];
            int a = 0;
            int b = 0;
            int c = 0;
            int d = 0;
            int e = 0;
            int f = 0;
            String base64 = "";
            for (int i = 0; i < list1.size(); i++) {//通过路劲地址查询
                //通过路劲地址依次放入到数组当中
                base64 = ReadFromFile.readTxt(list1.get(i).getAddress());
                if (list1.get(i).getMname().contains("jsonImg1")) {
                    str[1][a] = base64;
                    a = a + 1;
                } else if (list1.get(i).getMname().contains("jsonImg2")) {
                    str[2][b] = base64;
                    b = b + 1;
                } else if (list1.get(i).getMname().contains("jsonImg3")) {
                    str[3][c] = base64;
                    c = c + 1;
                } else if (list1.get(i).getMname().contains("jsonImg4")) {
                    str[4][e] = base64;
                    e = e + 1;
                } else if (list1.get(i).getMname().contains("jsonImg5")) {
                    str[5][f] = base64;
                    f = f + 1;
                } else if (list1.get(i).getMname().contains("jsonImg6")) {
                    str[6][d] = base64;
                    d = d + 1;
                }
            }
            //将产权信息回调放到str[4]中
            PorpertyExample porpertyExample = new PorpertyExample();
            porpertyExample.createCriteria().andEsnEqualTo(esn);
            List<Porperty> list2 = porpertyMapper.selectByExample(porpertyExample);
            if (list2.size() == 0) {
                //返回数据为空
            } else {

                str[0][0] = list2.get(0).getPno();
                str[0][1] = list2.get(0).getIcd();
                str[0][2] = list2.get(0).getPaddress();
            }
            result.setContent(str);
            result.setCode("200");
        } catch (Exception e) {
            result.setCode("500");
            log.error("回调数据失败-------HouseMsg页面");
        }
        return result;
    }

    @Override//通过查询数据库----返回报名信息是否通过 --如未通过则将报名信息step修改至null
    public Result familySureMessageReturn(Integer sn, String wid, String type) {
        //先是判断当前时间符合二次修改时间。
        Date date = new Date();
        Date date1;
        Date date2;
        Calendar ca = Calendar.getInstance();
        ca.setTime(date);
        int year = ca.get(Calendar.YEAR);
        TimecontrolExample timecontrolExample = new TimecontrolExample();
        timecontrolExample.createCriteria().andSnEqualTo(sn).andSyearEqualTo(year);
        Timecontrol timecontrol = timecontrolMapper.selectByExample(timecontrolExample).get(0);
        //获取到时间
        //进行判断  如果在区间内执行
        date1 = timecontrol.getBtime();
        date2 = timecontrol.getEtime();
        if (date1.before(date) && date2.after(date)) {
            EnrollExample enrollExample = new EnrollExample();
            enrollExample.createCriteria().andBcodeEqualTo(type).andWidEqualTo(wid);
            Enroll enroll = enrollMapper.selectByExample(enrollExample).get(0);
            if (enroll.getFlag() == 0 || enroll.getFlag() == null) {     //审核未通过直接进入到修改页面   //||enroll.getFlag()==2
                enroll.setJzflag(1);
                result.setCode("300");//300为审核未通过标识符
                result.setMsg("false");
            } else {
                //直接修改家长确认标识
                //判断是否符合双选去选区标准  --如符合则进行
                if (enroll.getDflag() == 1) {   //1代表符合双学区
                    result.setCode("200");
                    result.setMsg("true");
                } else {  //不符合双学区资格 --直接将确认标志进行修改
                    enroll.setJzflag(1);
                    result.setCode("200");
                    result.setMsg("false");
                }

            }
            enrollMapper.updateByPrimaryKey(enroll);
        } else {
            result.setCode("500");
        }
        //进行回调
        return result;
    }

    @Override
    public Result returnTime(Integer sn, String wid, String type) {
        Date date = new Date();
        Date date1;
        Date date2;
        Calendar ca = Calendar.getInstance();
        ca.setTime(date);
        int year = ca.get(Calendar.YEAR);
        TimecontrolExample timecontrolExample = new TimecontrolExample();
        timecontrolExample.createCriteria().andSnEqualTo(sn).andSyearEqualTo(year);
        Timecontrol timecontrol = timecontrolMapper.selectByExample(timecontrolExample).get(0);
        //获取到时间
        //进行判断  如果在区间内执行
        date1 = timecontrol.getBtime();
        date2 = timecontrol.getEtime();
        if (date1.before(date) && date2.after(date)) {
            result.setContent(true);
        } else {
            result.setContent(false);
        }
        return result;
    }

    @Override
    public Result returnChanQuanYSH(String wid, String number, String icd, String type) {
        EnrollExample example = new EnrollExample();
        example.createCriteria().andWidEqualTo(wid).andBcodeEqualTo(type);
        FamilyExample familyExample = new FamilyExample();
        try {
            Long esn = enrollMapper.selectByExample(example).get(0).getEsn();//拿到Esn
            familyExample.createCriteria().andEsnEqualTo(esn);
            /*  List<Family> list = familyMapper.selectByExample(familyExample);*/
            String token = HttpUtilsGetToken.getMessage();
            String[] a = HttpUtilsGetToken.getChanQuan(token, number, icd);
            if (a[0] == null) {
                result.setCode("500");
            } else {
                result.setContent(a);
                result.setCode("200");
            }
        } catch (Exception e) {
            log.error("查询产权信息失败");
            result.setCode("500");
        }
        return result;
    }

    @Override
    public Result returnMiddleSchoolName(String wid, String type) {
        SchoolExample schoolExample = new SchoolExample();
        //根据wid查询用户分区----根据分区查询学校名称
        List<School> list;
        try {
            int asn = userRollMapper.selectByPrimaryKey(wid).getAsn();
            if ("02".equals(type)) {
                schoolExample.createCriteria().andAsnEqualTo(asn).andSctypeEqualTo("小学");
                list = schoolMapper.selectByExample(schoolExample);
            } else {
                schoolExample.createCriteria().andAsnEqualTo(asn).andSctypeEqualTo("幼儿园");
                list = schoolMapper.selectByExample(schoolExample);
            }
            result.setContent(list);
            result.setCode("200");
            log.info("返回双选学校成功");
        } catch (Exception e) {
            log.error("返回双选学校失败");
            result.setCode("500");
        }
        return result;

    }

    @Override//返回爷孙户监护人信息
    public Result returnFamilyYSH(String wid, String type) {
        EnrollExample example = new EnrollExample();
        example.createCriteria().andWidEqualTo(wid).andBcodeEqualTo(type);
        FamilyExample familyExample = new FamilyExample();
        try {
            Long esn = enrollMapper.selectByExample(example).get(0).getEsn();//拿到Esn
            familyExample.createCriteria().andEsnEqualTo(esn);
            List<Family> list = familyMapper.selectByExample(familyExample);
            if (list.size() == 0) {
                result.setCode("500");
            } else {
                result.setContent(list);
                result.setCode("200");
            }
        } catch (Exception e) {
            log.error("查询产权信息失败");
            result.setCode("500");
        }
        return result;
    }

    @Override
    public Result getSchoolNamePrimary(String bcode, String wid) {
        log.info(bcode);
        SchoolExample example1 = new SchoolExample();
        try {
            if (bcode.equals("01")) {//幼儿园
                example1.createCriteria().andSctypeEqualTo("幼儿园");
                result.setCode("200");
                result.setContent(schoolMapper.selectByExample(example1));
                log.info("返回学校名称数据成功------幼儿园分支");
            }
        } catch (Exception e) {
            log.error("返回学校名称数据失败");
            result.setCode("500");
        }
        return result;
    }

    @Override
    public Result checkStuMsgByBaoMing(String id) {
        StudentExample example = new StudentExample();
        example.createCriteria().andIdEqualTo(id);
        try {
            List<Student> student = studentMapper.selectByExample(example);
            if (student.size() == 0) {
                result.setCode("200");
            } else {
                result.setCode("500");
            }
        } catch (Exception e) {
            result.setCode("500");
            log.error("查询报名ID是否存在");
        }
        return result;
    }

    @Override  //返回选区、家长手机号、资格认证
    public Result returnMiddleAreaAndMdtype(String wid, String type) {
        EnrollExample example = new EnrollExample();
        example.createCriteria().andWidEqualTo(wid).andBcodeEqualTo(type);
        String[] strings = new String[3];
        try {
            strings[0] = enrollMapper.selectByExample(example).get(0).getMrdtype() + "";//拿到Esn
            UserRoll userRoll = userRollMapper.selectByPrimaryKey(wid);
            strings[1] = userRoll.getAsn() + "";
            strings[2] = userRoll.getPhone();
            result.setCode("200");
            result.setContent(strings);
        } catch (Exception e) {
            log.error("返回家长信息失败");
            result.setCode("500");
        }
        return result;
    }
}
