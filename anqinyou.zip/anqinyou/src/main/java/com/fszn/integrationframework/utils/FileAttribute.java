package com.fszn.integrationframework.utils;

import java.sql.Timestamp;

//转储的File文件属性   地址 大小  上传时间   材料类型  材料名称
public class FileAttribute {
    private Timestamp  uptime;
    private String address;
    private int msize;
    private String mname;
    private int code;  //标识文件是否写入成功

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public Timestamp getUptime() {
        return uptime;
    }

    public void setUptime(Timestamp uptime) {
        this.uptime = uptime;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getMsize() {
        return msize;
    }

    public void setMsize(int msize) {
        this.msize = msize;
    }

    public String getMname() {
        return mname;
    }

    public void setMname(String mname) {
        this.mname = mname;
    }


}
